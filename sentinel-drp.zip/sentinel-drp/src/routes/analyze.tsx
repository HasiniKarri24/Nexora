import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore } from "@/lib/store";
import { SAMPLE_APP, SAMPLE_SOCIAL } from "@/lib/demo-data";
import { EmptyState, List, Notice, PageHeader, Panel, PriorityBadge } from "@/components/drp/common";
import { EvidenceList } from "@/components/drp/EvidenceList";
import { CreateCaseDialog } from "@/components/drp/ReviewActions";

export const Route = createFileRoute("/analyze")({
  head: () => ({
    meta: [
      { title: "Quick Analyze — Sentinel DRP" },
      { name: "description", content: "Run a demo analysis on a social profile or mobile app listing." },
      { property: "og:title", content: "Quick Analyze — Sentinel DRP" },
      { property: "og:description", content: "Run a demo analysis on a social profile or mobile app listing." },
    ],
  }),
  component: Analyze,
});

type Result = { kind: "match"; id: string } | { kind: "unmatched" } | { kind: "error"; msg: string };

function ImageInput({ label, file, setFile }: { label: string; file: File | null; setFile: (f: File | null) => void }) {
  return (
    <div>
      <Label>{label} <span className="font-normal text-muted-foreground">(optional, not saved)</span></Label>
      {file ? (
        <div className="mt-1 flex items-center gap-3 rounded-md border p-2">
          <img src={URL.createObjectURL(file)} alt="Upload preview" className="h-14 w-14 rounded object-cover" />
          <span className="flex-1 truncate text-sm">{file.name}</span>
          <Button type="button" size="sm" variant="ghost" onClick={() => setFile(null)} aria-label="Remove image"><X className="h-4 w-4" /></Button>
        </div>
      ) : <input type="file" accept="image/*" className="mt-1 block text-sm" aria-label={label} onChange={(e) => setFile(e.target.files?.[0] ?? null)} />}
    </div>
  );
}

function Field({ id, label, value, onChange, error, multi, required }: { id: string; label: string; value: string; onChange: (v: string) => void; error?: string | undefined; multi?: boolean; required?: boolean }) {
  return (
    <div>
      <Label htmlFor={id}>{label}{required && <span className="text-danger"> *</span>}</Label>
      {multi ? <Textarea id={id} value={value} onChange={(e) => onChange(e.target.value)} aria-invalid={!!error} rows={3} />
        : <Input id={id} value={value} onChange={(e) => onChange(e.target.value)} aria-invalid={!!error} />}
      {error && <p className="mt-1 text-xs text-danger">{error}</p>}
    </div>
  );
}

function Analyze() {
  const { state, brandId } = useStore();
  const defBrand = brandId === "all" ? state.brands[0]?.id ?? "" : brandId;
  const [tab, setTab] = useState("social");
  const [s, setS] = useState({ brandId: defBrand, platform: "", username: "", displayName: "", bio: "", website: "" });
  const [a, setA] = useState({ brandId: defBrand, name: "", publisher: "", packageId: "", description: "", storeUrl: "", website: "" });
  const [img, setImg] = useState<File | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [caseOpen, setCaseOpen] = useState(false);

  function run(e: React.FormEvent) {
    e.preventDefault();
    const er: Record<string, string> = {};
    if (tab === "social") {
      if (!s.brandId) er["brandId"] = "Choose a brand.";
      if (!s.platform) er["platform"] = "Choose a platform.";
      if (!s.username.trim()) er["username"] = "Username is required.";
      if (s.website && !/^https?:\/\//.test(s.website)) er["website"] = "Use a full URL starting with https://";
    } else {
      if (!a.brandId) er["brandId"] = "Choose a brand.";
      if (!a.name.trim()) er["name"] = "App name is required.";
      if (!a.publisher.trim()) er["publisher"] = "Publisher is required.";
      if (a.storeUrl && !/^https?:\/\//.test(a.storeUrl)) er["storeUrl"] = "Use a full URL starting with https://";
    }
    setErrors(er);
    if (Object.keys(er).length) return;
    setLoading(true); setResult(null);
    setTimeout(() => {
      setLoading(false);
      try {
        if (tab === "social") setResult(s.username.trim().toLowerCase() === SAMPLE_SOCIAL.username ? { kind: "match", id: SAMPLE_SOCIAL.matchId } : { kind: "unmatched" });
        else setResult(a.packageId.trim() === SAMPLE_APP.packageId ? { kind: "match", id: SAMPLE_APP.matchId } : { kind: "unmatched" });
      } catch { setResult({ kind: "error", msg: "The demo analysis could not complete. Try again." }); }
    }, 900);
  }

  const rec = result?.kind === "match" ? (state.profiles.find((p) => p.id === result.id) ?? state.apps.find((x) => x.id === result.id)) : undefined;
  const brandSelect = (val: string, on: (v: string) => void) => (
    <div><Label>Brand <span className="text-danger">*</span></Label>
      <Select value={val} onValueChange={on}><SelectTrigger aria-label="Brand" aria-invalid={!!errors["brandId"]}><SelectValue placeholder="Select brand" /></SelectTrigger>
        <SelectContent>{state.brands.map((b) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent></Select>
      {errors["brandId"] && <p className="mt-1 text-xs text-danger">{errors["brandId"]}</p>}</div>
  );

  return (
    <>
      <PageHeader crumbs={[{ label: "Quick Analyze" }]} title="Quick Analyze"
        description="Check a single profile or app listing against your brand registry. Use “Load sample” to see a prepared result." />
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel>
          <Tabs value={tab} onValueChange={(v) => { setTab(v); setErrors({}); setResult(null); setImg(null); }}>
            <TabsList className="mb-4"><TabsTrigger value="social">Social Profile</TabsTrigger><TabsTrigger value="app">Mobile App</TabsTrigger></TabsList>
            <form onSubmit={run} noValidate>
              <TabsContent value="social" className="space-y-3">
                {brandSelect(s.brandId, (v) => setS({ ...s, brandId: v }))}
                <div><Label>Platform <span className="text-danger">*</span></Label>
                  <Select value={s.platform} onValueChange={(v) => setS({ ...s, platform: v })}><SelectTrigger aria-label="Platform" aria-invalid={!!errors["platform"]}><SelectValue placeholder="Select platform" /></SelectTrigger>
                    <SelectContent>{["X", "Instagram", "Facebook", "Telegram", "TikTok"].map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent></Select>
                  {errors["platform"] && <p className="mt-1 text-xs text-danger">{errors["platform"]}</p>}</div>
                <Field id="un" label="Username" required value={s.username} onChange={(v) => setS({ ...s, username: v })} error={errors["username"]} />
                <Field id="dn" label="Display name" value={s.displayName} onChange={(v) => setS({ ...s, displayName: v })} />
                <Field id="bio" label="Bio or message text" multi value={s.bio} onChange={(v) => setS({ ...s, bio: v })} />
                <Field id="web" label="Website link" value={s.website} onChange={(v) => setS({ ...s, website: v })} error={errors["website"]} />
                <ImageInput label="Screenshot" file={img} setFile={setImg} />
              </TabsContent>
              <TabsContent value="app" className="space-y-3">
                {brandSelect(a.brandId, (v) => setA({ ...a, brandId: v }))}
                <Field id="an" label="App name" required value={a.name} onChange={(v) => setA({ ...a, name: v })} error={errors["name"]} />
                <Field id="ap" label="Publisher" required value={a.publisher} onChange={(v) => setA({ ...a, publisher: v })} error={errors["publisher"]} />
                <Field id="pk" label="Package ID" value={a.packageId} onChange={(v) => setA({ ...a, packageId: v })} />
                <Field id="ad" label="App description" multi value={a.description} onChange={(v) => setA({ ...a, description: v })} />
                <Field id="su" label="Store URL" value={a.storeUrl} onChange={(v) => setA({ ...a, storeUrl: v })} error={errors["storeUrl"]} />
                <Field id="dw" label="Developer website" value={a.website} onChange={(v) => setA({ ...a, website: v })} />
                <ImageInput label="Icon or screenshot" file={img} setFile={setImg} />
              </TabsContent>
              <div className="mt-5 flex flex-wrap gap-2">
                <Button type="submit" disabled={loading}>{loading && <Loader2 className="h-4 w-4 animate-spin" />}Run demo analysis</Button>
                <Button type="button" variant="outline" onClick={() => {
                  setErrors({}); setResult(null);
                  if (tab === "social") setS({ brandId: SAMPLE_SOCIAL.brandId, platform: SAMPLE_SOCIAL.platform, username: SAMPLE_SOCIAL.username, displayName: SAMPLE_SOCIAL.displayName, bio: SAMPLE_SOCIAL.bio, website: SAMPLE_SOCIAL.website });
                  else setA({ brandId: SAMPLE_APP.brandId, name: SAMPLE_APP.name, publisher: SAMPLE_APP.publisher, packageId: SAMPLE_APP.packageId, description: SAMPLE_APP.description, storeUrl: SAMPLE_APP.storeUrl, website: SAMPLE_APP.website });
                }}>Load sample</Button>
              </div>
              <p className="mt-3 text-xs text-muted-foreground">Submitted URLs are never fetched in demo mode.</p>
            </form>
          </Tabs>
        </Panel>

        <Panel title="Result">
          {loading && <div className="flex items-center gap-2 py-12 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" />Running demo analysis…</div>}
          {!loading && !result && <EmptyState title="No analysis yet" text="Fill in the form or load a sample, then run a demo analysis." />}
          {!loading && result?.kind === "error" && <Notice t="danger">{result.msg}</Notice>}
          {!loading && result?.kind === "unmatched" && (
            <div className="space-y-3">
              <Notice t="warning">Live analysis requires a backend connection. This input does not match a prepared sample, so no findings are shown — we don't invent results.</Notice>
              <p className="text-sm text-muted-foreground">Try “Load sample” to see how a completed analysis looks, or see <Link to="/sources" className="text-primary hover:underline">Data Sources</Link> for what a live integration needs.</p>
            </div>
          )}
          {!loading && rec && (
            <div className="space-y-5">
              <Notice t="info">Simulated result — not a live AI assessment.</Notice>
              <div className="flex items-center gap-2"><span className="text-sm font-medium">Review priority</span><PriorityBadge p={rec.priority} /></div>
              <List title="Detected warning signs" items={rec.warningSigns} />
              <div><h3 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Supporting evidence</h3><EvidenceList entityId={rec.id} /></div>
              <List title="Information that could not be verified" items={rec.missingInfo} />
              <List title="Suggested next review steps" items={["Compare against official handles in Brand Registry", "Check for other records sharing the same domain in Connected Threats", "Create a case and capture reviewer notes before drafting a report"]} />
              <div className="flex flex-wrap gap-2">
                <Button onClick={() => setCaseOpen(true)}>Create case</Button>
                <Button variant="outline" asChild>{"username" in rec ? <Link to="/social/$id" params={{ id: rec.id }}>Open full investigation</Link> : <Link to="/apps/$id" params={{ id: rec.id }}>Open full investigation</Link>}</Button>
              </div>
              {caseOpen && <CreateCaseDialog open={caseOpen} onOpenChange={setCaseOpen} findingIds={[rec.id]} brandId={rec.brandId} priority={rec.priority} defaultTitle={`Quick analyze: ${"username" in rec ? rec.username : rec.name}`} />}
            </div>
          )}
        </Panel>
      </div>
    </>
  );
}
