import { useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CASE_STATUSES, fmtDate, useStore } from "@/lib/store";
import { CaseStatusBadge, EmptyState, PageHeader, Panel, PriorityBadge, SortHeader } from "@/components/drp/common";
import { FilterSelect } from "@/components/drp/FilterSelect";
import { CreateCaseDialog } from "@/components/drp/ReviewActions";

export const Route = createFileRoute("/cases/")({
  head: () => ({
    meta: [
      { title: "Cases & Evidence — Sentinel DRP" },
      { name: "description", content: "Track investigations, linked findings and evidence." },
      { property: "og:title", content: "Cases & Evidence — Sentinel DRP" },
      { property: "og:description", content: "Track investigations, linked findings and evidence." },
    ],
  }),
  component: Cases,
});

const PR = { high: 3, medium: 2, low: 1, none: 0 };

function Cases() {
  const { state, brandId } = useStore();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [open, setOpen] = useState(false);
  const [sort, setSort] = useState<{ k: "updatedAt" | "priority" | "id"; d: "asc" | "desc" }>({ k: "updatedAt", d: "desc" });
  const rows = useMemo(() => state.cases.filter((c) => (brandId === "all" || c.brandId === brandId) && (status === "all" || c.status === status) && `${c.id} ${c.title}`.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => { const va = sort.k === "priority" ? PR[a.priority] : a[sort.k]; const vb = sort.k === "priority" ? PR[b.priority] : b[sort.k]; const r = va < vb ? -1 : va > vb ? 1 : 0; return sort.d === "asc" ? r : -r; }),
  [state.cases, brandId, status, q, sort]);
  const h = (k: typeof sort.k, l: string) => <SortHeader label={l} active={sort.k === k} dir={sort.d} onClick={() => setSort((s) => ({ k, d: s.k === k && s.d === "desc" ? "asc" : "desc" }))} />;

  return (
    <>
      <PageHeader crumbs={[{ label: "Cases & Evidence" }]} title="Cases & Evidence"
        description="Group related findings into a case, record notes and prepare an evidence report for manual submission."
        actions={<Button onClick={() => setOpen(true)}><Plus className="h-4 w-4" />New case</Button>} />
      <Panel>
        <div className="mb-4 flex flex-col gap-2 sm:flex-row">
          <Input placeholder="Search case ID or title" value={q} onChange={(e) => setQ(e.target.value)} className="h-9 sm:w-64" aria-label="Search cases" />
          <FilterSelect label="Status" value={status} onChange={setStatus} options={CASE_STATUSES} />
        </div>
        {rows.length === 0 ? <EmptyState title="No cases" text="Create a case from a finding or with the New case button." /> : (
          <div className="overflow-x-auto"><table className="w-full min-w-[820px] text-sm">
            <thead className="text-left text-xs text-muted-foreground"><tr className="border-b">
              <th className="py-2 pr-3">{h("id", "Case ID")}</th><th className="py-2 pr-3">Title</th><th className="py-2 pr-3">Brand</th>
              <th className="py-2 pr-3">{h("priority", "Priority")}</th><th className="py-2 pr-3">Assigned</th><th className="py-2 pr-3">Status</th>
              <th className="py-2 pr-3">Findings</th><th className="py-2">{h("updatedAt", "Last updated")}</th></tr></thead>
            <tbody>{rows.map((c) => (
              <tr key={c.id} tabIndex={0} className="cursor-pointer border-b last:border-0 hover:bg-muted/50 focus-visible:bg-muted focus-visible:outline-none"
                onClick={() => navigate({ to: "/cases/$id", params: { id: c.id } })} onKeyDown={(e) => e.key === "Enter" && navigate({ to: "/cases/$id", params: { id: c.id } })}>
                <td className="py-2.5 pr-3 font-mono text-xs">{c.id}</td><td className="py-2.5 pr-3 font-medium">{c.title}</td>
                <td className="py-2.5 pr-3">{state.brands.find((b) => b.id === c.brandId)?.name}</td>
                <td className="py-2.5 pr-3"><PriorityBadge p={c.priority} /></td><td className="py-2.5 pr-3">{c.assignee}</td>
                <td className="py-2.5 pr-3"><CaseStatusBadge s={c.status} /></td><td className="py-2.5 pr-3 tabular-nums">{c.findingIds.length}</td>
                <td className="py-2.5 text-muted-foreground">{fmtDate(c.updatedAt)}</td>
              </tr>))}</tbody>
          </table></div>
        )}
      </Panel>
      {open && <CreateCaseDialog open={open} onOpenChange={setOpen} findingIds={[]} brandId={brandId === "all" ? state.brands[0]?.id ?? "" : brandId} priority="medium" defaultTitle="" />}
    </>
  );
}
