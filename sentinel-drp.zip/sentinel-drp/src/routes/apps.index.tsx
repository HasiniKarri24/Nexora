import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Input } from "@/components/ui/input";
import { fmtDate, useStore } from "@/lib/store";
import { EmptyState, PageHeader, Pill, PriorityBadge, STATUS_LABEL, StatusBadge } from "@/components/drp/common";
import { FilterSelect } from "@/components/drp/FilterSelect";

export const Route = createFileRoute("/apps/")({
  head: () => ({
    meta: [
      { title: "App Monitoring — Sentinel DRP" },
      { name: "description", content: "Mobile app listings that reference registered brands." },
      { property: "og:title", content: "App Monitoring — Sentinel DRP" },
      { property: "og:description", content: "Mobile app listings that reference registered brands." },
    ],
  }),
  component: Apps,
});

const PR = { high: 3, medium: 2, low: 1, none: 0 };

function Apps() {
  const { state, brandId } = useStore();
  const [q, setQ] = useState("");
  const [f, setF] = useState({ store: "all", brand: brandId, priority: "all", status: "all" });
  const set = (k: keyof typeof f) => (v: string) => setF({ ...f, [k]: v });
  const rows = useMemo(() => state.apps.filter((a) =>
    (f.store === "all" || a.store === f.store) && (f.brand === "all" || a.brandId === f.brand) &&
    (f.priority === "all" || a.priority === f.priority) && (f.status === "all" || a.status === f.status) &&
    `${a.name} ${a.publisher} ${a.packageId ?? ""}`.toLowerCase().includes(q.toLowerCase()),
  ).sort((a, b) => PR[b.priority] - PR[a.priority]), [state.apps, f, q]);

  return (
    <>
      <PageHeader crumbs={[{ label: "App Monitoring" }]} title="App Monitoring"
        description="App listings from the demo dataset that use a registered brand's name or look. Listing analysis does not detect malware." />
      <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:flex-wrap">
        <Input placeholder="Search name, publisher or package" value={q} onChange={(e) => setQ(e.target.value)} className="h-9 sm:w-64" aria-label="Search apps" />
        <FilterSelect label="Store" value={f.store} onChange={set("store")} options={["Google Play", "Apple App Store", "Third-party APK site"].map((v) => ({ value: v, label: v }))} />
        <FilterSelect label="Brand" value={f.brand} onChange={set("brand")} options={state.brands.map((b) => ({ value: b.id, label: b.name }))} />
        <FilterSelect label="Priority" value={f.priority} onChange={set("priority")} options={["high", "medium", "low", "none"].map((v) => ({ value: v, label: v.charAt(0).toUpperCase() + v.slice(1) }))} />
        <FilterSelect label="Status" value={f.status} onChange={set("status")} options={Object.entries(STATUS_LABEL).map(([value, label]) => ({ value, label }))} />
      </div>
      {rows.length === 0 ? <EmptyState title="No apps match" text="Try clearing a filter or search term." /> : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {rows.map((a) => {
            const b = state.brands.find((x) => x.id === a.brandId);
            return (
              <Link key={a.id} to="/apps/$id" params={{ id: a.id }} className="rounded-lg border bg-card p-4 transition-colors hover:border-primary/40">
                <div className="flex items-start gap-3">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl font-bold text-primary-foreground" style={{ background: b?.logoColor }} aria-hidden>{a.name[0]}</span>
                  <div className="min-w-0 flex-1"><p className="truncate font-medium">{a.name}</p><p className="text-xs text-muted-foreground">{a.publisher} · {a.store}</p>
                    <p className="truncate font-mono text-xs text-muted-foreground">{a.packageId ?? "Package ID not available"}</p></div>
                </div>
                <div className="mt-3 flex flex-wrap items-center gap-1.5"><PriorityBadge p={a.priority} /><StatusBadge s={a.status} />
                  {a.relationship === "official" && <Pill t="success">Official</Pill>}</div>
                <p className="mt-3 text-xs text-muted-foreground">Claims {b?.name} · last checked {fmtDate(a.lastChecked)}</p>
              </Link>
            );
          })}
        </div>
      )}
    </>
  );
}
