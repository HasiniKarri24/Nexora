import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { fmtDateTime, useStore } from "@/lib/store";
import { Notice, PageHeader, Panel, PriorityBadge, SampleLabel } from "@/components/drp/common";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/threats")({
  validateSearch: (s: Record<string, unknown>): { focus?: string | undefined } => ({ focus: typeof s["focus"] === "string" ? s["focus"] : undefined }),
  head: () => ({
    meta: [
      { title: "Connected Threats — Sentinel DRP" },
      { name: "description", content: "Relationship graph of profiles, apps, domains and brands sharing indicators." },
      { property: "og:title", content: "Connected Threats — Sentinel DRP" },
      { property: "og:description", content: "Relationship graph of profiles, apps, domains and brands sharing indicators." },
    ],
  }),
  component: Threats,
});

type NType = "brand" | "profile" | "app" | "domain";
interface GNode { id: string; type: NType; label: string; sub: string; x: number; y: number }
interface GEdge { id: string; from: string; to: string; label: "Links to domain" | "Uses similar branding" | "Claims to represent"; evidence: string[] }

const W = 900, H = 560;
const COLORS: Record<NType, string> = { brand: "var(--color-success)", profile: "var(--color-chart-1)", app: "var(--color-warning)", domain: "var(--color-danger)" };
const TYPE_LABEL: Record<NType, string> = { brand: "Brand", profile: "Social profile", app: "Mobile app", domain: "Domain" };

function Threats() {
  const { state, brandId } = useStore();
  const { focus } = Route.useSearch();
  const [types, setTypes] = useState<Record<NType, boolean>>({ brand: true, profile: true, app: true, domain: true });
  const [selNode, setSelNode] = useState<string | null>(focus ?? null);
  const [selEdge, setSelEdge] = useState<string | null>(null);
  const [highlight, setHighlight] = useState<string | null>(focus ?? null);

  const { nodes, edges } = useMemo(() => {
    const brands = state.brands.filter((b) => brandId === "all" || b.id === brandId);
    const bIds = new Set(brands.map((b) => b.id));
    const profiles = state.profiles.filter((p) => bIds.has(p.brandId) && p.category !== "none" && p.status !== "dismissed");
    const apps = state.apps.filter((a) => bIds.has(a.brandId) && a.category !== "none" && a.status !== "dismissed");
    const host = (u?: string) => { try { return u ? new URL(u).hostname : undefined; } catch { return undefined; } };
    const domains = [...new Set([...profiles.map((p) => host(p.url)), ...apps.map((a) => host(a.website))].filter((d): d is string => !!d && !brands.some((b) => b.approvedDomains.includes(d))))];
    const spread = (n: number, i: number, top: number, bottom: number) => n === 1 ? (top + bottom) / 2 : top + (i * (bottom - top)) / (n - 1);
    const N: GNode[] = [
      ...brands.map((b, i) => ({ id: b.id, type: "brand" as const, label: b.name, sub: "Registered brand", x: spread(brands.length, i, 330, 570), y: 50 })),
      ...profiles.map((p, i) => ({ id: p.id, type: "profile" as const, label: p.username, sub: p.platform, x: 110, y: spread(profiles.length, i, 120, 520) })),
      ...apps.map((a, i) => ({ id: a.id, type: "app" as const, label: a.name, sub: a.store, x: 790, y: spread(apps.length, i, 160, 480) })),
      ...domains.map((d, i) => ({ id: `d:${d}`, type: "domain" as const, label: d, sub: "Unapproved domain", x: 450, y: spread(domains.length, i, 260, 500) })),
    ];
    const ev = (id: string, d?: string) => state.evidence.filter((e) => e.entityId === id && (!d || e.excerpt.includes(d))).map((e) => `“${e.excerpt}” — ${e.source}, ${fmtDateTime(e.capturedAt)}`);
    const E: GEdge[] = [];
    for (const p of profiles) {
      const d = host(p.url);
      if (d && domains.includes(d)) E.push({ id: `${p.id}-d`, from: p.id, to: `d:${d}`, label: "Links to domain", evidence: ev(p.id, d).length ? ev(p.id, d) : [`Profile URL field: ${p.url}`] });
      E.push(p.similarities.length
        ? { id: `${p.id}-b`, from: p.id, to: p.brandId, label: "Uses similar branding", evidence: p.similarities }
        : { id: `${p.id}-b`, from: p.id, to: p.brandId, label: "Claims to represent", evidence: p.misleadingClaims.length ? p.misleadingClaims : ["Brand keyword match in profile text"] });
    }
    for (const a of apps) {
      const d = host(a.website);
      if (d && domains.includes(d)) E.push({ id: `${a.id}-d`, from: a.id, to: `d:${d}`, label: "Links to domain", evidence: ev(a.id, d).length ? ev(a.id, d) : [`Developer website: ${a.website}`] });
      E.push(a.similarities.length
        ? { id: `${a.id}-b`, from: a.id, to: a.brandId, label: "Uses similar branding", evidence: a.similarities }
        : { id: `${a.id}-b`, from: a.id, to: a.brandId, label: "Claims to represent", evidence: ["Brand name used in listing"] });
    }
    return { nodes: N, edges: E };
  }, [state, brandId]);

  const visible = nodes.filter((n) => types[n.type]);
  const vIds = new Set(visible.map((n) => n.id));
  const vEdges = edges.filter((e) => vIds.has(e.from) && vIds.has(e.to));
  const byId = new Map(nodes.map((n) => [n.id, n]));
  // highlight: node + neighbours, plus second hop through domains
  const hl = useMemo(() => {
    if (!highlight) return null;
    const s = new Set([highlight]);
    for (const e of edges) if (e.from === highlight || e.to === highlight) { s.add(e.from); s.add(e.to); }
    for (const id of [...s]) if (id.startsWith("d:")) for (const e of edges) if (e.to === id) s.add(e.from);
    return s;
  }, [highlight, edges]);
  const node = selNode ? byId.get(selNode) : undefined;
  const edge = selEdge ? edges.find((e) => e.id === selEdge) : undefined;
  const relatedCase = (id: string) => state.cases.find((c) => c.findingIds.includes(id));
  const rec = node ? state.profiles.find((p) => p.id === node.id) ?? state.apps.find((a) => a.id === node.id) : undefined;
  const nodeCase = node && (node.type === "domain" ? state.cases.find((c) => edges.some((e) => e.to === node.id && c.findingIds.includes(e.from))) : relatedCase(node.id));

  return (
    <>
      <PageHeader crumbs={[{ label: "Connected Threats" }]} title="Connected Threats"
        description="See which profiles and apps share indicators such as the same domain. Select a node or connection to inspect evidence." />
      <div className="mb-4"><Notice t="warning">Shared indicators suggest a relationship but do not prove common ownership or a coordinated campaign.</Notice></div>
      <Tabs defaultValue="graph">
        <div className="mb-3 flex flex-wrap items-center gap-3">
          <TabsList><TabsTrigger value="graph">Graph</TabsTrigger><TabsTrigger value="list">List view</TabsTrigger></TabsList>
          <fieldset className="flex flex-wrap items-center gap-3 text-sm"><legend className="sr-only">Entity types</legend>
            {(Object.keys(types) as NType[]).map((t) => (
              <label key={t} className="flex items-center gap-1.5"><Checkbox checked={types[t]} onCheckedChange={(c) => setTypes({ ...types, [t]: !!c })} />
                <span className="h-2.5 w-2.5 rounded-full" style={{ background: COLORS[t] }} aria-hidden />{TYPE_LABEL[t]}</label>))}
          </fieldset>
          <Button size="sm" variant="outline" className="ml-auto" onClick={() => { setTypes({ brand: true, profile: true, app: true, domain: true }); setSelNode(null); setSelEdge(null); setHighlight(null); }}><RotateCcw className="h-4 w-4" />Reset graph</Button>
        </div>
        <div className="grid gap-4 xl:grid-cols-[1fr_320px]">
          <TabsContent value="graph" className="mt-0 min-w-0">
            <Panel actions={<SampleLabel />} title="Relationship graph" subtitle={highlight ? `Highlighting connections for ${byId.get(highlight)?.label}` : "Click a node or a connecting line"}>
              <div className="overflow-x-auto">
                <svg viewBox={`-170 0 ${W + 340} ${H}`} className="min-w-[700px] w-full" role="group" aria-label="Threat relationship graph">
                  {vEdges.map((e) => {
                    const a = byId.get(e.from)!, b = byId.get(e.to)!;
                    const dim = hl && !(hl.has(e.from) && hl.has(e.to));
                    const active = selEdge === e.id;
                    const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
                    return (
                      <g key={e.id} className="cursor-pointer" opacity={dim ? 0.12 : 1} onClick={() => { setSelEdge(e.id); setSelNode(null); }}
                        tabIndex={0} role="button" aria-label={`${a.label} ${e.label} ${b.label}`} onKeyDown={(k) => k.key === "Enter" && setSelEdge(e.id)}>
                        <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="transparent" strokeWidth={12} />
                        <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={active ? "var(--color-primary)" : e.label === "Links to domain" ? "var(--color-danger)" : "var(--color-muted-foreground)"}
                          strokeWidth={active ? 2.5 : 1.3} strokeDasharray={e.label === "Claims to represent" ? "4 4" : undefined} opacity={e.label === "Links to domain" ? 0.8 : 0.45} />
                        {active && <text x={mx} y={my - 6} textAnchor="middle" fontSize={11} fill="var(--color-primary)" fontWeight={600}>{e.label}</text>}
                      </g>
                    );
                  })}
                  {visible.map((n) => {
                    const dim = hl && !hl.has(n.id);
                    const sel = selNode === n.id;
                    const left = n.type === "profile", right = n.type === "app";
                    return (
                      <g key={n.id} transform={`translate(${n.x},${n.y})`} opacity={dim ? 0.2 : 1} className="cursor-pointer"
                        onClick={() => { setSelNode(n.id); setSelEdge(null); }} tabIndex={0} role="button" aria-label={`${TYPE_LABEL[n.type]} ${n.label}`}
                        onKeyDown={(k) => k.key === "Enter" && setSelNode(n.id)}>
                        <circle r={n.type === "domain" || n.type === "brand" ? 14 : 10} fill={COLORS[n.type]} stroke={sel ? "var(--color-foreground)" : "var(--color-card)"} strokeWidth={sel ? 3 : 2} />
                        <text x={left ? -16 : right ? 16 : 0} y={left || right ? 4 : n.type === "brand" ? -22 : 30} textAnchor={left ? "end" : right ? "start" : "middle"}
                          fontSize={12} fontWeight={500} fill="var(--color-foreground)" fontFamily="var(--font-mono)">{n.label}</text>
                      </g>
                    );
                  })}
                </svg>
              </div>
              <div className="mt-2 flex flex-wrap gap-4 text-xs text-muted-foreground">
                <span><span className="mr-1 inline-block h-0.5 w-5 bg-danger align-middle" />Links to domain</span>
                <span><span className="mr-1 inline-block h-0.5 w-5 bg-muted-foreground align-middle" />Uses similar branding</span>
                <span><span className="mr-1 inline-block w-5 border-t border-dashed border-muted-foreground align-middle" />Claims to represent</span>
              </div>
            </Panel>
          </TabsContent>
          <TabsContent value="list" className="mt-0 min-w-0">
            <Panel title="Connections" subtitle={`${vEdges.length} connections in view`}>
              <ul className="divide-y text-sm">{vEdges.map((e) => (
                <li key={e.id}><button type="button" onClick={() => { setSelEdge(e.id); setSelNode(null); }} className={cn("w-full px-1 py-2 text-left hover:bg-muted", selEdge === e.id && "bg-muted")}>
                  <span className="font-mono">{byId.get(e.from)?.label}</span> <span className="text-muted-foreground">— {e.label} →</span> <span className="font-mono">{byId.get(e.to)?.label}</span>
                </button></li>))}</ul>
            </Panel>
          </TabsContent>
          <aside className="space-y-4">
            {!node && !edge && <Panel title="Details"><p className="text-sm text-muted-foreground">Select a node or connection to see its details and evidence.</p>
              <Button size="sm" variant="outline" className="mt-3" onClick={() => { const d = nodes.find((n) => n.type === "domain"); if (d) { setHighlight(d.id); setSelNode(d.id); } }}>Show sample investigation</Button></Panel>}
            {node && (
              <Panel title={node.label} subtitle={`${TYPE_LABEL[node.type]} · ${node.sub}`}>
                {rec && <div className="mb-3"><PriorityBadge p={rec.priority} /></div>}
                {node.type === "domain" && <p className="mb-3 text-sm">Referenced by {edges.filter((e) => e.to === node.id).length} records. Not in the brand's approved domains.</p>}
                <div className="flex flex-col gap-2">
                  <Button size="sm" variant="outline" onClick={() => setHighlight(highlight === node.id ? null : node.id)}>{highlight === node.id ? "Clear highlight" : "Highlight connections"}</Button>
                  {node.type === "profile" && <Button size="sm" variant="outline" asChild><Link to="/social/$id" params={{ id: node.id }}>Open record</Link></Button>}
                  {node.type === "app" && <Button size="sm" variant="outline" asChild><Link to="/apps/$id" params={{ id: node.id }}>Open record</Link></Button>}
                  {node.type === "brand" && <Button size="sm" variant="outline" asChild><Link to="/brands/$id" params={{ id: node.id }}>Open record</Link></Button>}
                  {nodeCase ? <Button size="sm" asChild><Link to="/cases/$id" params={{ id: nodeCase.id }}>Open related case ({nodeCase.id})</Link></Button>
                    : <p className="text-xs text-muted-foreground">No related case yet. Open the record to create one.</p>}
                </div>
              </Panel>
            )}
            {edge && (
              <Panel title={edge.label} subtitle={`${byId.get(edge.from)?.label} → ${byId.get(edge.to)?.label}`}>
                <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Evidence for this connection</h3>
                <ul className="space-y-2 text-sm">{edge.evidence.map((x) => <li key={x} className="rounded bg-muted/60 px-2 py-1.5 font-mono text-xs">{x}</li>)}</ul>
              </Panel>
            )}
          </aside>
        </div>
      </Tabs>
    </>
  );
}
