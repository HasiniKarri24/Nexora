import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { fmtDateTime, useStore } from "@/lib/store";
import type { DataSource } from "@/lib/types";
import { Notice, PageHeader, Pill } from "@/components/drp/common";

export const Route = createFileRoute("/sources")({
  head: () => ({
    meta: [
      { title: "Data Sources — Sentinel DRP" },
      { name: "description", content: "Status and coverage limits of each data source." },
      { property: "og:title", content: "Data Sources — Sentinel DRP" },
      { property: "og:description", content: "Status and coverage limits of each data source." },
    ],
  }),
  component: Sources,
});

function Sources() {
  const { state, loadDemoDataset } = useStore();
  const [detail, setDetail] = useState<DataSource | null>(null);
  const [loading, setLoading] = useState(false);
  return (
    <>
      <PageHeader crumbs={[{ label: "Data Sources" }]} title="Data Sources"
        description="Where findings come from. No real accounts or app stores are being monitored in this prototype."
        actions={<Button disabled={loading} onClick={() => { setLoading(true); setTimeout(() => { loadDemoDataset(); setLoading(false); toast.success("Demo dataset loaded (12 profiles, 6 apps, 4 cases)"); }, 600); }}>
          {loading && <Loader2 className="h-4 w-4 animate-spin" />}Load demo dataset</Button>} />
      <div className="mb-4"><Notice t="warning">Loading the demo dataset replaces findings, brands and cases with the original sample records. Your settings are kept.</Notice></div>
      <div className="grid gap-4 md:grid-cols-2">
        {state.sources.map((s) => (
          <div key={s.id} className="rounded-lg border bg-card p-5">
            <div className="flex items-start justify-between gap-2"><div><p className="font-semibold">{s.name}</p><p className="text-xs text-muted-foreground">{s.category}</p></div>
              <Pill t={s.status === "demo" ? "info" : s.status === "error" ? "danger" : "neutral"}>{s.status === "demo" ? "Demo dataset" : s.status === "error" ? "Error" : "Not connected"}</Pill></div>
            <dl className="mt-4 space-y-2 text-sm">
              <div><dt className="text-xs text-muted-foreground">Available data</dt><dd>{s.dataType}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Last successful import</dt><dd>{s.lastImport ? fmtDateTime(s.lastImport) : "Never"}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Coverage limitations</dt><dd>{s.limitations}</dd></div>
            </dl>
            <Button variant="outline" size="sm" className="mt-4" onClick={() => setDetail(s)}>Connection details</Button>
          </div>
        ))}
      </div>
      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{detail?.name}: future integration</DialogTitle><DialogDescription>What a backend would need before this source can go live.</DialogDescription></DialogHeader>
          <p className="text-sm">{detail?.integrationNeeds}</p>
          <Notice>API keys and credentials must be stored on a server, never in this browser. This prototype does not ask for or store any keys.</Notice>
        </DialogContent>
      </Dialog>
    </>
  );
}
