import { useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Input } from "@/components/ui/input";
import { fmtDate, inRange, useStore, type DateRange } from "@/lib/store";
import { CATEGORY_LABEL, EmptyState, PageHeader, Panel, Pill, PriorityBadge, STATUS_LABEL, SortHeader, StatusBadge } from "@/components/drp/common";
import { FilterSelect } from "@/components/drp/FilterSelect";

export const Route = createFileRoute("/social/")({
  head: () => ({
    meta: [
      { title: "Social Monitoring — Sentinel DRP" },
      { name: "description", content: "Searchable list of monitored social profiles and warning signs." },
      { property: "og:title", content: "Social Monitoring — Sentinel DRP" },
      { property: "og:description", content: "Searchable list of monitored social profiles and warning signs." },
    ],
  }),
  component: Social,
});

const PR = { high: 3, medium: 2, low: 1, none: 0 };
const REL = { official: "Official", authorized: "Authorized partner", fan: "Fan account", unknown: "" };

function Social() {
  const { state, brandId } = useStore();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [f, setF] = useState({ platform: "all", brand: brandId, category: "all", priority: "all", status: "all", date: "all" });
  const [sort, setSort] = useState<{ k: "priority" | "lastChecked" | "displayName"; d: "asc" | "desc" }>({ k: "priority", d: "desc" });
  const set = (k: keyof typeof f) => (v: string) => setF({ ...f, [k]: v });

  const rows = useMemo(() => state.profiles.filter((p) =>
    (f.platform === "all" || p.platform === f.platform) && (f.brand === "all" || p.brandId === f.brand) &&
    (f.category === "all" || p.category === f.category) && (f.priority === "all" || p.priority === f.priority) &&
    (f.status === "all" || p.status === f.status) && inRange(p.firstDetected, f.date as DateRange) &&
    (`${p.displayName} ${p.username} ${p.bio}`.toLowerCase().includes(q.toLowerCase())),
  ).sort((a, b) => {
    const va = sort.k === "priority" ? PR[a.priority] : a[sort.k]; const vb = sort.k === "priority" ? PR[b.priority] : b[sort.k];
    const r = va < vb ? -1 : va > vb ? 1 : 0; return sort.d === "asc" ? r : -r;
  }), [state.profiles, f, q, sort]);
  const h = (k: typeof sort.k, l: string) => <SortHeader label={l} active={sort.k === k} dir={sort.d} onClick={() => setSort((s) => ({ k, d: s.k === k && s.d === "desc" ? "asc" : "desc" }))} />;
  const brandName = (id: string) => state.brands.find((b) => b.id === id)?.name ?? "—";

  return (
    <>
      <PageHeader crumbs={[{ label: "Social Monitoring" }]} title="Social Monitoring"
        description="Profiles from the demo dataset that mention a registered brand. Select a row to open its investigation." />
      <Panel>
        <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:flex-wrap">
          <Input placeholder="Search name, username or bio" value={q} onChange={(e) => setQ(e.target.value)} className="h-9 sm:w-64" aria-label="Search profiles" />
          <FilterSelect label="Platform" value={f.platform} onChange={set("platform")} options={["X", "Instagram", "Facebook", "Telegram", "TikTok"].map((v) => ({ value: v, label: v }))} />
          <FilterSelect label="Brand" value={f.brand} onChange={set("brand")} options={state.brands.map((b) => ({ value: b.id, label: b.name }))} />
          <FilterSelect label="Category" value={f.category} onChange={set("category")} options={(["impersonation", "suspected_scam", "none"] as const).map((v) => ({ value: v, label: CATEGORY_LABEL[v] }))} />
          <FilterSelect label="Priority" value={f.priority} onChange={set("priority")} options={["high", "medium", "low", "none"].map((v) => ({ value: v, label: v.charAt(0).toUpperCase() + v.slice(1) }))} />
          <FilterSelect label="Status" value={f.status} onChange={set("status")} options={Object.entries(STATUS_LABEL).map(([value, label]) => ({ value, label }))} />
          <FilterSelect label="Detected" value={f.date} onChange={set("date")} options={[{ value: "7d", label: "Last 7 days" }, { value: "30d", label: "Last 30 days" }, { value: "90d", label: "Last 90 days" }]} />
        </div>
        {rows.length === 0 ? <EmptyState title="No profiles match" text="Try clearing a filter or search term." /> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] text-sm">
              <thead className="text-left text-xs text-muted-foreground"><tr className="border-b">
                <th className="py-2 pr-3">{h("displayName", "Profile")}</th><th className="py-2 pr-3">Platform</th><th className="py-2 pr-3">Claimed brand</th>
                <th className="py-2 pr-3">{h("priority", "Priority")}</th><th className="py-2 pr-3">Main warning signs</th>
                <th className="py-2 pr-3">{h("lastChecked", "Last checked")}</th><th className="py-2">Review status</th></tr></thead>
              <tbody>{rows.map((p) => (
                <tr key={p.id} tabIndex={0} onClick={() => navigate({ to: "/social/$id", params: { id: p.id } })}
                  onKeyDown={(e) => e.key === "Enter" && navigate({ to: "/social/$id", params: { id: p.id } })}
                  className="cursor-pointer border-b last:border-0 hover:bg-muted/50 focus-visible:bg-muted focus-visible:outline-none">
                  <td className="py-2.5 pr-3"><div className="flex items-center gap-2.5">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-semibold">{p.displayName[0]}</span>
                    <div><p className="font-medium">{p.displayName}</p><p className="font-mono text-xs text-muted-foreground">{p.username}</p></div>
                    {REL[p.relationship] && <Pill t={p.relationship === "fan" ? "neutral" : "success"}>{REL[p.relationship]}</Pill>}</div></td>
                  <td className="py-2.5 pr-3">{p.platform}</td><td className="py-2.5 pr-3">{brandName(p.brandId)}</td>
                  <td className="py-2.5 pr-3"><PriorityBadge p={p.priority} /></td>
                  <td className="py-2.5 pr-3 text-xs text-muted-foreground">{p.warningSigns.slice(0, 2).join(", ") || "—"}</td>
                  <td className="py-2.5 pr-3 text-muted-foreground">{fmtDate(p.lastChecked)}</td>
                  <td className="py-2.5"><StatusBadge s={p.status} /></td>
                </tr>))}</tbody>
            </table>
          </div>
        )}
      </Panel>
    </>
  );
}
