import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import { BrandTile, EmptyState, List, Notice, PageHeader, Panel, Pill } from "@/components/drp/common";
import { BrandFormDialog } from "@/components/drp/BrandForm";
import { FindingsTable } from "@/components/drp/FindingsTable";

export const Route = createFileRoute("/brands/$id")({
  head: () => ({
    meta: [
      { title: "Brand details — Sentinel DRP" },
      { name: "description", content: "Official assets, keywords and related findings for a brand." },
      { property: "og:title", content: "Brand details — Sentinel DRP" },
      { property: "og:description", content: "Official assets, keywords and related findings for a brand." },
    ],
  }),
  component: BrandDetail,
});

function BrandDetail() {
  const { id } = Route.useParams();
  const { state, allFindings } = useStore();
  const [open, setOpen] = useState(false);
  const b = state.brands.find((x) => x.id === id);
  if (!b) return <EmptyState title="Brand not found" text="This brand may have been removed when demo data was reset." />;
  const authorized = [...state.profiles, ...state.apps].filter((x) => x.brandId === b.id && (x.relationship === "official" || x.relationship === "authorized"));
  return (
    <>
      <PageHeader crumbs={[{ label: "Brand Registry", to: "/brands" }, { label: b.name }]} title={b.name}
        description={`${b.industry}. Reference details used when assessing findings.`}
        actions={<Button variant="outline" onClick={() => setOpen(true)}><Pencil className="h-4 w-4" />Edit brand</Button>} />
      <div className="mb-4"><Notice>Supplied by the user; not independently verified.</Notice></div>
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title="Official assets" className="lg:col-span-2">
          <div className="mb-4 flex items-center gap-3"><BrandTile name={b.name} color={b.logoColor} size={48} /><a className="text-sm text-primary hover:underline" href={b.website} target="_blank" rel="noreferrer">{b.website || "No website"}</a></div>
          <div className="grid gap-5 sm:grid-cols-2">
            <List title="Approved domains" items={b.approvedDomains} />
            <List title="Official social handles" items={b.socialHandles.map((h) => `${h.platform} · ${h.handle}`)} />
            <List title="Official apps" items={b.officialApps.map((a) => `${a.name} — ${a.packageId} (${a.publisher})`)} />
            <List title="Authorized partners" items={b.partners} />
          </div>
        </Panel>
        <Panel title="Monitoring keywords">
          <div className="flex flex-wrap gap-1.5">{[...b.keywords, ...b.aliases].map((k) => <Pill key={k} t="neutral">{k}</Pill>)}</div>
        </Panel>
      </div>
      <Panel title="Authorized accounts in dataset" className="mt-4">
        <ul className="divide-y text-sm">{authorized.map((a) => (
          <li key={a.id} className="flex justify-between py-2"><span>{"displayName" in a ? `${a.displayName} (${a.username})` : a.name}</span>
            <Pill t="success">{a.relationship === "official" ? "Official" : "Authorized"}</Pill></li>))}</ul>
      </Panel>
      <Panel title="Related findings" className="mt-4"><FindingsTable findings={allFindings.filter((f) => f.brandId === b.id)} /></Panel>
      {open && <BrandFormDialog open={open} onOpenChange={setOpen} brand={b} />}
    </>
  );
}
