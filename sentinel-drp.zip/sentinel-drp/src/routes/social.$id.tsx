import { createFileRoute, Link } from "@tanstack/react-router";
import { fmtDate, fmtDateTime, useStore } from "@/lib/store";
import { BrandTile, CategoryBadge, EmptyState, List, Notice, PageHeader, Panel, PriorityBadge, StatusBadge } from "@/components/drp/common";
import { ReviewActions } from "@/components/drp/ReviewActions";
import { EvidenceList } from "@/components/drp/EvidenceList";

export const Route = createFileRoute("/social/$id")({
  head: () => ({
    meta: [
      { title: "Profile investigation — Sentinel DRP" },
      { name: "description", content: "Side-by-side comparison of a suspicious profile with the official brand." },
      { property: "og:title", content: "Profile investigation — Sentinel DRP" },
      { property: "og:description", content: "Side-by-side comparison of a suspicious profile with the official brand." },
    ],
  }),
  component: ProfileDetail,
});

function ProfileDetail() {
  const { id } = Route.useParams();
  const { state } = useStore();
  const p = state.profiles.find((x) => x.id === id);
  if (!p) return <EmptyState title="Profile not found" text="It may have been removed when demo data was reset." />;
  const b = state.brands.find((x) => x.id === p.brandId);
  const official = b?.socialHandles.find((h) => h.platform === p.platform) ?? b?.socialHandles[0];
  const domain = p.url ? new URL(p.url).hostname : null;
  const related = domain ? [...state.profiles.filter((x) => x.id !== p.id && x.url?.includes(domain)), ...state.apps.filter((a) => a.website?.includes(domain))] : [];

  return (
    <>
      <PageHeader crumbs={[{ label: "Social Monitoring", to: "/social" }, { label: p.username }]} title={p.displayName}
        description={`${p.platform} profile claiming ${b?.name ?? "a registered brand"}. First detected ${fmtDate(p.firstDetected)}.`} />
      <div className="mb-4 flex flex-wrap gap-2"><CategoryBadge c={p.category} /><PriorityBadge p={p.priority} /><StatusBadge s={p.status} /></div>
      {p.dismissReason && p.status === "dismissed" && <div className="mb-4"><Notice t="neutral">Dismissed: {p.dismissReason}</Notice></div>}

      <div className="grid gap-4 lg:grid-cols-[1fr_260px]">
        <div className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Panel title="Official brand" subtitle="From Brand Registry">
              {b && <div className="flex items-center gap-3"><BrandTile name={b.name} color={b.logoColor} /><div><p className="font-medium">{b.name}</p><p className="font-mono text-xs text-muted-foreground">{official?.platform} · {official?.handle}</p></div></div>}
              <p className="mt-3 text-xs text-muted-foreground">Approved domains</p><p className="font-mono text-sm">{b?.approvedDomains.join(", ")}</p>
            </Panel>
            <Panel title="Profile under review" subtitle="From demo capture">
              <div className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary font-semibold">{p.displayName[0]}</span><div><p className="font-medium">{p.displayName}</p><p className="font-mono text-xs text-muted-foreground">{p.platform} · {p.username}</p></div></div>
              <p className="mt-3 text-sm">{p.bio}</p>
              <p className="mt-2 text-xs text-muted-foreground">Supplied URL</p><p className="break-all font-mono text-sm">{p.url ?? "None supplied"}</p>
            </Panel>
          </div>
          <Panel title="Warning signs">
            <div className="grid gap-5 sm:grid-cols-2">
              <List title="Logo or name similarities" items={p.similarities} />
              <List title="Domain mismatches" items={p.domainMismatches} />
              <List title="Misleading support / verification claims" items={p.misleadingClaims} />
              <List title="Suspicious requests in supplied content" items={p.suspiciousRequests} />
            </div>
          </Panel>
          <Panel title="Evidence excerpts"><EvidenceList entityId={p.id} /></Panel>
          {related.length > 0 && domain && (
            <Panel title="Shares a domain with other records" subtitle={`Also references ${domain}`} actions={<Link to="/threats" search={{ focus: p.id }} className="text-sm text-primary hover:underline">Open in Connected Threats</Link>}>
              <ul className="space-y-1 text-sm">{related.map((r) => (
                <li key={r.id}>{"username" in r
                  ? <Link to="/social/$id" params={{ id: r.id }} className="text-primary hover:underline">{r.displayName} ({r.platform})</Link>
                  : <Link to="/apps/$id" params={{ id: r.id }} className="text-primary hover:underline">App: {r.name}</Link>}</li>))}</ul>
            </Panel>
          )}
          <Panel title="Missing information"><List title="Not available in supplied data" items={p.missingInfo} /></Panel>
          <Notice t="warning">This is a suspected finding based on supplied data. A human reviewer must confirm before any report is filed — matching names or links do not prove intent or ownership.</Notice>
        </div>
        <aside><Panel title="Reviewer actions"><ReviewActions id={p.id} brandId={p.brandId} priority={p.priority} name={p.username} /></Panel>
          <p className="mt-2 px-1 text-xs text-muted-foreground">Last checked {fmtDateTime(p.lastChecked)}</p></aside>
      </div>
    </>
  );
}
