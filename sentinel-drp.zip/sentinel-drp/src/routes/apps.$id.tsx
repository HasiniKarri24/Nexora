import { createFileRoute, Link } from "@tanstack/react-router";
import { fmtDate, useStore } from "@/lib/store";
import { CategoryBadge, EmptyState, List, Notice, PageHeader, Panel, PriorityBadge, StatusBadge } from "@/components/drp/common";
import { ReviewActions } from "@/components/drp/ReviewActions";
import { EvidenceList } from "@/components/drp/EvidenceList";

export const Route = createFileRoute("/apps/$id")({
  head: () => ({
    meta: [
      { title: "App listing review — Sentinel DRP" },
      { name: "description", content: "Compare a suspicious app listing with the official app." },
      { property: "og:title", content: "App listing review — Sentinel DRP" },
      { property: "og:description", content: "Compare a suspicious app listing with the official app." },
    ],
  }),
  component: AppDetail,
});

function Row({ k, a, b, mismatch }: { k: string; a?: string | undefined; b?: string | undefined; mismatch?: boolean }) {
  return (
    <tr className="border-b last:border-0">
      <th scope="row" className="py-2 pr-3 text-left text-xs font-medium text-muted-foreground">{k}</th>
      <td className="py-2 pr-3 font-mono text-xs">{a || "—"}</td>
      <td className="py-2 font-mono text-xs">{b || "Not supplied"} {mismatch && <span className="ml-1 font-sans font-medium text-danger">· Mismatch</span>}</td>
    </tr>
  );
}

function AppDetail() {
  const { id } = Route.useParams();
  const { state } = useStore();
  const a = state.apps.find((x) => x.id === id);
  if (!a) return <EmptyState title="App not found" text="It may have been removed when demo data was reset." />;
  const b = state.brands.find((x) => x.id === a.brandId);
  const off = b?.officialApps[0];
  const domain = a.website ? new URL(a.website).hostname : undefined;
  const domainOk = !domain || b?.approvedDomains.includes(domain);
  const related = domain && !domainOk ? state.profiles.filter((p) => p.url?.includes(domain)) : [];

  return (
    <>
      <PageHeader crumbs={[{ label: "App Monitoring", to: "/apps" }, { label: a.name }]} title={a.name}
        description={`${a.store} listing by ${a.publisher}. First detected ${fmtDate(a.firstDetected)}.`} />
      <div className="mb-4 flex flex-wrap gap-2"><CategoryBadge c={a.category} /><PriorityBadge p={a.priority} /><StatusBadge s={a.status} /></div>
      <div className="grid gap-4 lg:grid-cols-[1fr_260px]">
        <div className="space-y-4">
          <Panel title="Comparison with official app">
            <div className="overflow-x-auto"><table className="w-full min-w-[480px]">
              <thead><tr className="border-b text-left text-xs text-muted-foreground"><th className="py-2" /><th className="py-2">Official ({b?.name})</th><th className="py-2">This listing</th></tr></thead>
              <tbody>
                <Row k="App name" a={off?.name} b={a.name} />
                <Row k="Publisher" a={off?.publisher} b={a.publisher} mismatch={!!off && off.publisher !== a.publisher} />
                <Row k="Package ID" a={off?.packageId} b={a.packageId} mismatch={!!off && !!a.packageId && off.packageId !== a.packageId} />
                <Row k="Linked website" a={b?.website} b={a.website} mismatch={!domainOk} />
                <Row k="Privacy-policy domain" a={b?.approvedDomains[0]} b={a.privacyDomain} mismatch={!!a.privacyDomain && !b?.approvedDomains.includes(a.privacyDomain)} />
              </tbody>
            </table></div>
          </Panel>
          <Panel title="Warning signs">
            <div className="grid gap-5 sm:grid-cols-2">
              <List title="Name and icon similarities" items={a.similarities} />
              <List title="Suspicious wording in description" items={a.suspiciousWording} />
            </div>
            <p className="mt-4 text-sm"><span className="text-xs text-muted-foreground">Description: </span>{a.description}</p>
          </Panel>
          {a.permissions && (
            <Panel title="Permissions (as supplied)" subtitle={`Source: ${a.permissions.source}`}><List title="Listed permissions" items={a.permissions.items} /></Panel>
          )}
          <Panel title="Available evidence"><EvidenceList entityId={a.id} /></Panel>
          {related.length > 0 && (
            <Panel title="Profiles linking to the same domain" subtitle={domain} actions={<Link to="/threats" search={{ focus: a.id }} className="text-sm text-primary hover:underline">Open in Connected Threats</Link>}>
              <ul className="space-y-1 text-sm">{related.map((r) => <li key={r.id}><Link to="/social/$id" params={{ id: r.id }} className="text-primary hover:underline">{r.displayName} ({r.platform})</Link></li>)}</ul>
            </Panel>
          )}
          <Panel title="Missing data"><List title="Not available in supplied data" items={a.missingInfo} /></Panel>
          <Notice t="warning">App-listing analysis compares public listing details only. It does not establish whether an app contains malware.</Notice>
        </div>
        <aside><Panel title="Reviewer actions"><ReviewActions id={a.id} brandId={a.brandId} priority={a.priority} name={a.name} /></Panel></aside>
      </div>
    </>
  );
}
