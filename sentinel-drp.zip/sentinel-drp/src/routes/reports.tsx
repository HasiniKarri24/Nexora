import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Download, Printer } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { inRange, useStore, type DateRange } from "@/lib/store";
import { CASE_STATUS_LABEL, CATEGORY_LABEL, Notice, PRIORITY_LABEL, PageHeader, Panel, SampleLabel, STATUS_LABEL } from "@/components/drp/common";
import { FilterSelect } from "@/components/drp/FilterSelect";
import { HBars, TimeChart, countBy } from "@/components/drp/charts";

export const Route = createFileRoute("/reports")({
  head: () => ({
    meta: [
      { title: "Reports — Sentinel DRP" },
      { name: "description", content: "Charts and exports computed from the demo findings and cases." },
      { property: "og:title", content: "Reports — Sentinel DRP" },
      { property: "og:description", content: "Charts and exports computed from the demo findings and cases." },
    ],
  }),
  component: Reports,
});

function Reports() {
  const { state, allFindings, brandId } = useStore();
  const [brand, setBrand] = useState(brandId);
  const [range, setRange] = useState("all");
  const [source, setSource] = useState("all");
  const sources = [...new Set(allFindings.map((f) => f.source))];
  const findings = useMemo(() => allFindings.filter((f) => (brand === "all" || f.brandId === brand) && inRange(f.firstDetected, range as DateRange) && (source === "all" || f.source === source)), [allFindings, brand, range, source]);
  const cases = state.cases.filter((c) => brand === "all" || c.brandId === brand);

  function csv() {
    const head = ["id", "name", "kind", "brand", "source", "category", "priority", "review_status", "first_detected"];
    const esc = (v: string) => `"${v.replace(/"/g, '""')}"`;
    const rows = findings.map((f) => [f.id, f.name, f.kind, state.brands.find((b) => b.id === f.brandId)?.name ?? "", f.source, CATEGORY_LABEL[f.category], PRIORITY_LABEL[f.priority], STATUS_LABEL[f.status], f.firstDetected].map(esc).join(","));
    const blob = new Blob([[head.join(","), ...rows].join("\n")], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "findings-demo.csv"; a.click(); URL.revokeObjectURL(a.href);
    toast(`CSV with ${findings.length} findings downloaded by your browser`);
  }

  return (
    <>
      <PageHeader crumbs={[{ label: "Reports" }]} title="Reports"
        description="Charts are computed from the same demo records used across the app."
        actions={<><Button variant="outline" onClick={csv} disabled={!findings.length}><Download className="h-4 w-4" />Export findings CSV</Button><Button variant="outline" onClick={() => window.print()}><Printer className="h-4 w-4" />Print summary</Button></>} />
      <div className="mb-4 flex flex-col gap-2 sm:flex-row print:hidden">
        <FilterSelect label="Brand" value={brand} onChange={setBrand} options={state.brands.map((b) => ({ value: b.id, label: b.name }))} />
        <FilterSelect label="Date" value={range} onChange={setRange} options={[{ value: "7d", label: "Last 7 days" }, { value: "30d", label: "Last 30 days" }, { value: "90d", label: "Last 90 days" }]} />
        <FilterSelect label="Source" value={source} onChange={setSource} options={sources.map((s) => ({ value: s, label: s }))} />
      </div>
      <div className="mb-4"><Notice>Review statuses and case outcomes are reviewer decisions. No platform enforcement has been confirmed.</Notice></div>
      <div className="grid gap-4 md:grid-cols-2">
        <Panel title="Findings by source" actions={<SampleLabel />}><HBars data={countBy(findings, (f) => f.source)} /></Panel>
        <Panel title="Findings by category" actions={<SampleLabel />}><HBars data={countBy(findings, (f) => CATEGORY_LABEL[f.category])} /></Panel>
        <Panel title="Review status (reviewer decisions)" actions={<SampleLabel />}><HBars data={countBy(findings, (f) => STATUS_LABEL[f.status])} /></Panel>
        <Panel title="Case resolution status" actions={<SampleLabel />}><HBars data={countBy(cases, (c) => CASE_STATUS_LABEL[c.status])} /></Panel>
        <Panel title="Findings over time" actions={<SampleLabel />} className="md:col-span-2"><TimeChart findings={findings} /></Panel>
      </div>
    </>
  );
}
