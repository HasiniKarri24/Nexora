import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { FileText, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CASE_STATUSES, fmtDateTime, useStore } from "@/lib/store";
import { REVIEWERS } from "@/lib/demo-data";
import { CASE_STATUS_LABEL, CaseStatusBadge, CategoryBadge, EmptyState, PageHeader, Panel, PriorityBadge } from "@/components/drp/common";
import { EvidenceList } from "@/components/drp/EvidenceList";
import type { CaseStatus } from "@/lib/types";

export const Route = createFileRoute("/cases/$id")({
  head: () => ({
    meta: [
      { title: "Case detail — Sentinel DRP" },
      { name: "description", content: "Linked findings, evidence, notes and activity for a case." },
      { property: "og:title", content: "Case detail — Sentinel DRP" },
      { property: "og:description", content: "Linked findings, evidence, notes and activity for a case." },
    ],
  }),
  component: CaseDetail,
});

function CaseDetail() {
  const { id } = Route.useParams();
  const { state, allFindings, updateCase, addFindingToCase, removeFindingFromCase } = useStore();
  const c = state.cases.find((x) => x.id === id);
  const [notes, setNotes] = useState(c?.notes ?? "");
  const [add, setAdd] = useState("");
  useEffect(() => { setNotes(c?.notes ?? ""); }, [c?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!c) return <EmptyState title="Case not found" text="It may have been removed when demo data was reset." action={<Button asChild variant="outline"><Link to="/cases">Back to cases</Link></Button>} />;
  const linked = allFindings.filter((f) => c.findingIds.includes(f.id));
  const available = allFindings.filter((f) => !c.findingIds.includes(f.id) && f.status !== "dismissed");

  return (
    <>
      <PageHeader crumbs={[{ label: "Cases & Evidence", to: "/cases" }, { label: c.id }]} title={c.title}
        description={c.summary || "No summary yet."}
        actions={<Button asChild><Link to="/report/$id" params={{ id: c.id }}><FileText className="h-4 w-4" />Export evidence report</Link></Button>} />
      <div className="mb-4 flex flex-wrap gap-2"><span className="font-mono text-xs text-muted-foreground">{c.id}</span><PriorityBadge p={c.priority} /><CaseStatusBadge s={c.status} /></div>

      <div className="grid gap-4 lg:grid-cols-[1fr_300px]">
        <div className="space-y-4">
          <Panel title="Linked profiles and apps" subtitle={`${linked.length} findings`}>
            {linked.length === 0 ? <p className="text-sm text-muted-foreground">No findings linked yet.</p> : (
              <ul className="divide-y">{linked.map((f) => (
                <li key={f.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5">
                  <div>{f.kind === "social" ? <Link to="/social/$id" params={{ id: f.id }} className="text-sm font-medium hover:underline">{f.name}</Link>
                    : <Link to="/apps/$id" params={{ id: f.id }} className="text-sm font-medium hover:underline">{f.name}</Link>}
                    <p className="text-xs text-muted-foreground">{f.source}</p></div>
                  <div className="flex items-center gap-2"><CategoryBadge c={f.category} /><PriorityBadge p={f.priority} />
                    <Button size="icon" variant="ghost" aria-label={`Remove ${f.name}`} onClick={() => { removeFindingFromCase(c.id, f.id); toast("Finding removed"); }}><Trash2 className="h-4 w-4" /></Button></div>
                </li>))}</ul>
            )}
            <div className="mt-3 flex gap-2">
              <Select value={add} onValueChange={setAdd}><SelectTrigger className="h-9" aria-label="Add finding"><SelectValue placeholder="Add a finding…" /></SelectTrigger>
                <SelectContent>{available.map((f) => <SelectItem key={f.id} value={f.id}>{f.name} · {f.source}</SelectItem>)}</SelectContent></Select>
              <Button variant="outline" disabled={!add} onClick={() => { addFindingToCase(c.id, add); setAdd(""); toast.success("Finding added"); }}>Add</Button>
            </div>
          </Panel>
          <Panel title="Evidence items">
            {linked.length === 0 ? <p className="text-sm text-muted-foreground">Link findings to collect their evidence.</p> :
              <div className="space-y-5">{linked.map((f) => <div key={f.id}><p className="mb-2 text-sm font-medium">{f.name}</p><EvidenceList entityId={f.id} /></div>)}</div>}
          </Panel>
          <Panel title="Reviewer notes">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={4} aria-label="Reviewer notes" />
            <Button className="mt-2" size="sm" disabled={notes === c.notes} onClick={() => { updateCase(c.id, { notes }, "Reviewer notes updated"); toast.success("Notes saved"); }}>Save notes</Button>
          </Panel>
        </div>
        <aside className="space-y-4">
          <Panel title="Status & assignee">
            <label className="text-xs text-muted-foreground" htmlFor="cs-status">Status</label>
            <Select value={c.status} onValueChange={(v) => updateCase(c.id, { status: v as CaseStatus }, `Status changed to ${CASE_STATUS_LABEL[v as CaseStatus]}`)}>
              <SelectTrigger id="cs-status" className="mb-3 mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>{CASE_STATUSES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select>
            <label className="text-xs text-muted-foreground" htmlFor="cs-assignee">Assignee</label>
            <Select value={c.assignee} onValueChange={(v) => updateCase(c.id, { assignee: v }, `Assigned to ${v}`)}>
              <SelectTrigger id="cs-assignee" className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>{REVIEWERS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent></Select>
            <p className="mt-3 text-xs text-muted-foreground">Status reflects reviewer decisions only, not platform enforcement.</p>
          </Panel>
          <Panel title="Activity timeline">
            <ol className="space-y-3 border-l pl-4">{[...c.activity].reverse().map((a) => (
              <li key={a.id} className="relative"><span className="absolute -left-[21px] top-1.5 h-2 w-2 rounded-full bg-primary" />
                <p className="text-sm">{a.text}</p><p className="text-xs text-muted-foreground">{fmtDateTime(a.at)}</p></li>))}</ol>
          </Panel>
        </aside>
      </div>
    </>
  );
}
