import { createFileRoute, Link } from "@tanstack/react-router";
import { ScanSearch } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStore, fmtDateTime, inRange } from "@/lib/store";
import { CATEGORY_LABEL, PRIORITY_LABEL, Panel, PageHeader, PriorityBadge, SampleLabel, CaseStatusBadge, Pill } from "@/components/drp/common";
import { FindingsTable } from "@/components/drp/FindingsTable";
import { HBars, TimeChart, countBy } from "@/components/drp/charts";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Overview — Sentinel DRP" },
      { name: "description", content: "Summary of brand impersonation, scam and suspicious app findings." },
      { property: "og:title", content: "Overview — Sentinel DRP" },
      { property: "og:description", content: "Summary of brand impersonation, scam and suspicious app findings." },
    ],
  }),
  component: Overview,
});

function Overview() {
  const { state, findings, brandId, range } = useStore();
  const byBrand = <T extends { brandId: string }>(x: T) => brandId === "all" || x.brandId === brandId;
  const profiles = state.profiles.filter(byBrand).filter((p) => inRange(p.firstDetected, range));
  const apps = state.apps.filter(byBrand).filter((a) => inRange(a.firstDetected, range));
  const cases = state.cases.filter(byBrand);
  const openCases = cases.filter((c) => c.status !== "resolved" && c.status !== "dismissed");
  const needsReview = findings.filter((f) => f.status === "new" || f.status === "needs_review");
  const high = findings.filter((f) => f.priority === "high");
  const stats = [
    { label: "Profiles analyzed", value: profiles.length },
    { label: "App listings analyzed", value: apps.length },
    { label: "Findings needing review", value: needsReview.length },
    { label: "High-priority findings", value: high.length },
    { label: "Open cases", value: openCases.length },
  ];
  const topCases = [...openCases].sort((a, b) => (a.priority === "high" ? -1 : 1) - (b.priority === "high" ? -1 : 1)).slice(0, 4);

  return (
    <>
      <PageHeader crumbs={[{ label: "Overview" }]} title="Overview"
        description="A summary of monitored profiles and apps for the selected brand. All figures come from the fictional demo dataset."
        actions={<Button asChild><Link to="/analyze"><ScanSearch className="h-4 w-4" />Analyze a profile or app</Link></Button>} />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        {stats.map((s) => (
          <div key={s.label} className="rounded-lg border bg-card p-4">
            <p className="text-xs text-muted-foreground">{s.label}</p>
            <p className="mt-1 text-2xl font-semibold tabular-nums">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel title="Findings over time" subtitle="New findings per week" actions={<SampleLabel />} className="lg:col-span-2"><TimeChart findings={findings} /></Panel>
        <Panel title="Priority breakdown" actions={<SampleLabel />}>
          <HBars data={countBy(findings, (f) => PRIORITY_LABEL[f.priority], ["High", "Medium", "Low"])}
            colors={["var(--color-danger)", "var(--color-warning)", "var(--color-chart-1)", "var(--color-chart-5)"]} />
        </Panel>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel title="Findings by category" actions={<SampleLabel />}>
          <HBars data={countBy(findings, (f) => CATEGORY_LABEL[f.category], [CATEGORY_LABEL.impersonation, CATEGORY_LABEL.suspected_scam, CATEGORY_LABEL.suspicious_app])} />
        </Panel>
        <Panel title="Highest-priority investigations" className="lg:col-span-2">
          {topCases.length === 0 ? <p className="text-sm text-muted-foreground">No open cases.</p> : (
            <ul className="divide-y">
              {topCases.map((c) => (
                <li key={c.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5">
                  <div><Link to="/cases/$id" params={{ id: c.id }} className="text-sm font-medium hover:underline">{c.title}</Link>
                    <p className="text-xs text-muted-foreground">{c.id} · {c.findingIds.length} findings · {c.assignee}</p></div>
                  <div className="flex gap-2"><PriorityBadge p={c.priority} /><CaseStatusBadge s={c.status} /></div>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>

      <Panel title="Recent findings" className="mt-4" actions={<Link to="/social" className="text-sm text-primary hover:underline">All findings</Link>}>
        <FindingsTable findings={findings} />
      </Panel>

      <Panel title="Source coverage" subtitle="No live sources are connected" className="mt-4">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {state.sources.map((s) => (
            <div key={s.id} className="rounded-md border p-3">
              <div className="flex items-center justify-between"><p className="text-sm font-medium">{s.name}</p>
                <Pill t={s.status === "demo" ? "info" : s.status === "error" ? "danger" : "neutral"}>{s.status === "demo" ? "Demo dataset" : s.status === "error" ? "Error" : "Not connected"}</Pill></div>
              <p className="mt-1 text-xs text-muted-foreground">Last successful import: {s.lastImport ? fmtDateTime(s.lastImport) : "—"}</p>
            </div>
          ))}
        </div>
      </Panel>
    </>
  );
}
