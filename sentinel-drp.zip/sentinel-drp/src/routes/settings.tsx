import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useStore } from "@/lib/store";
import { Notice, PageHeader, Panel, Pill } from "@/components/drp/common";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Sentinel DRP" },
      { name: "description", content: "Workspace, reviewer and display preferences for this browser." },
      { property: "og:title", content: "Settings — Sentinel DRP" },
      { property: "og:description", content: "Workspace, reviewer and display preferences for this browser." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { state, updateSettings, resetDemo } = useStore();
  const s = state.settings;
  const [ws, setWs] = useState(s.workspaceName);
  const [name, setName] = useState(s.reviewerName);
  const [role, setRole] = useState(s.reviewerRole);
  return (
    <>
      <PageHeader crumbs={[{ label: "Settings" }]} title="Settings" description="Preferences for this demo workspace." />
      <div className="mb-4"><Notice>All settings are stored in this browser only. Email alerts, sign-in and team invitations need a backend and are not available.</Notice></div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Workspace" actions={<Pill t="neutral">This browser only</Pill>}>
          <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); if (!ws.trim()) { toast.error("Workspace name is required"); return; } updateSettings({ workspaceName: ws.trim() }); toast.success("Workspace saved"); }}>
            <div><Label htmlFor="ws">Workspace name</Label><Input id="ws" value={ws} onChange={(e) => setWs(e.target.value)} /></div>
            <div><Label>Default brand</Label>
              <Select value={s.defaultBrandId} onValueChange={(v) => { updateSettings({ defaultBrandId: v }); toast("Default brand updated"); }}>
                <SelectTrigger aria-label="Default brand"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="all">All brands</SelectItem>{state.brands.map((b) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent></Select></div>
            <div className="flex items-center justify-between rounded-md border p-3"><Label htmlFor="theme">Dark theme</Label>
              <Switch id="theme" checked={s.theme === "dark"} onCheckedChange={(c) => updateSettings({ theme: c ? "dark" : "light" })} /></div>
            <Button type="submit">Save workspace</Button>
          </form>
        </Panel>
        <Panel title="Demo reviewer profile" actions={<Pill t="neutral">Not a real account</Pill>}>
          <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); if (!name.trim()) { toast.error("Name is required"); return; } updateSettings({ reviewerName: name.trim(), reviewerRole: role.trim() }); toast.success("Reviewer saved"); }}>
            <div><Label htmlFor="rn">Name</Label><Input id="rn" value={name} onChange={(e) => setName(e.target.value)} /></div>
            <div><Label htmlFor="rr">Role</Label><Input id="rr" value={role} onChange={(e) => setRole(e.target.value)} /></div>
            <Button type="submit">Save reviewer</Button>
          </form>
        </Panel>
        <Panel title="In-app notifications" actions={<Pill t="neutral">This browser only</Pill>}>
          <div className="space-y-3">
            <div className="flex items-center justify-between"><Label htmlFor="n1">New high-priority findings</Label><Switch id="n1" checked={s.notifyHighPriority} onCheckedChange={(c) => updateSettings({ notifyHighPriority: c })} /></div>
            <div className="flex items-center justify-between"><Label htmlFor="n2">Case status changes</Label><Switch id="n2" checked={s.notifyCaseUpdates} onCheckedChange={(c) => updateSettings({ notifyCaseUpdates: c })} /></div>
          </div>
        </Panel>
        <Panel title="Reset demo data">
          <p className="mb-3 text-sm text-muted-foreground">Restore all brands, findings, cases and settings to the original demo state.</p>
          <AlertDialog>
            <AlertDialogTrigger asChild><Button variant="destructive">Reset demo data</Button></AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader><AlertDialogTitle>Reset all demo data?</AlertDialogTitle><AlertDialogDescription>Your local changes, cases and notes will be removed from this browser.</AlertDialogDescription></AlertDialogHeader>
              <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={() => { resetDemo(); setWs("Hacxlerate Demo Workspace"); setName("Priya Raman"); setRole("Brand protection analyst"); toast.success("Demo data reset"); }}>Reset</AlertDialogAction></AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </Panel>
      </div>
    </>
  );
}
