import { createFileRoute, Link } from "@tanstack/react-router";
import { Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { fmtDate, fmtDateTime, useStore } from "@/lib/store";
import { CASE_STATUS_LABEL, CATEGORY_LABEL, EmptyState, List, Notice, PRIORITY_LABEL, PageHeader, STATUS_LABEL } from "@/components/drp/common";

export const Route = createFileRoute("/report/$id")({
  head: () => ({
    meta: [
      { title: "Evidence report — Sentinel DRP" },
      { name: "description", content: "Print-friendly draft evidence report for manual submission." },
      { property: "og:title", content: "Evidence report — Sentinel DRP" },
      { property: "og:description", content: "Print-friendly draft evidence report for manual submission." },
    ],
  }),
  component: Report,
});

function Report() {
  const { id } = Route.useParams();
  const { state, allFindings } = useStore();
  const c = state.cases.find((x) => x.id === id);
  if (!c) return <EmptyState title="Case not found" text="Nothing to report." />;
  const b = state.brands.find((x) => x.id === c.brandId);
  const linked = allFindings.filter((f) => c.findingIds.includes(f.id));

  return (
    <>
      <PageHeader crumbs={[{ label: "Cases & Evidence", to: "/cases" }, { label: c.id, to: `/cases/${c.id}` }, { label: "Report" }]} title="Draft evidence report"
        description="Review this draft, then use your browser's print dialog to print or save it as PDF. Nothing is sent to any platform."
        actions={<><Button variant="outline" asChild><Link to="/cases/$id" params={{ id: c.id }}>Back to case</Link></Button><Button onClick={() => window.print()}><Printer className="h-4 w-4" />Print / Save as PDF</Button></>} />
      <article className="mx-auto max-w-3xl rounded-lg border bg-card p-8 text-sm leading-relaxed print:max-w-none print:border-0 print:p-0">
        <header className="border-b pb-4">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Draft — for manual submission · Demo data</p>
          <h1 className="mt-1 text-xl font-semibold">{c.title}</h1>
          <dl className="mt-3 grid grid-cols-2 gap-x-6 gap-y-1 text-xs sm:grid-cols-4">
            <div><dt className="text-muted-foreground">Case</dt><dd className="font-mono">{c.id}</dd></div>
            <div><dt className="text-muted-foreground">Brand</dt><dd>{b?.name}</dd></div>
            <div><dt className="text-muted-foreground">Priority</dt><dd>{PRIORITY_LABEL[c.priority]}</dd></div>
            <div><dt className="text-muted-foreground">Reviewer status</dt><dd>{CASE_STATUS_LABEL[c.status]}</dd></div>
          </dl>
        </header>
        <section className="mt-5"><h2 className="mb-1 font-semibold">Summary</h2><p>{c.summary || "—"}</p></section>
        <section className="mt-5"><h2 className="mb-1 font-semibold">Official brand reference (user-supplied)</h2>
          <p>Website: <span className="font-mono">{b?.website}</span> · Approved domains: <span className="font-mono">{b?.approvedDomains.join(", ")}</span></p></section>
        <section className="mt-5"><h2 className="mb-2 font-semibold">Findings ({linked.length})</h2>
          {linked.map((f, i) => {
            const rec = state.profiles.find((p) => p.id === f.id) ?? state.apps.find((a) => a.id === f.id);
            const ev = state.evidence.filter((e) => e.entityId === f.id);
            return (
              <div key={f.id} className="mb-4 break-inside-avoid border-l-2 pl-3">
                <p className="font-medium">{i + 1}. {f.name}</p>
                <p className="text-xs text-muted-foreground">{f.source} · {CATEGORY_LABEL[f.category]} · Priority {PRIORITY_LABEL[f.priority]} · Review: {STATUS_LABEL[f.status]} · First detected {fmtDate(f.firstDetected)}</p>
                {rec && <div className="mt-2"><List title="Warning signs" items={rec.warningSigns} /></div>}
                <ul className="mt-2 space-y-1">{ev.map((e) => <li key={e.id} className="text-xs"><span className="font-mono">“{e.excerpt}”</span> — {e.source}, {fmtDateTime(e.capturedAt)}</li>)}</ul>
              </div>
            );
          })}
        </section>
        {c.notes && <section className="mt-5"><h2 className="mb-1 font-semibold">Reviewer notes</h2><p className="whitespace-pre-wrap">{c.notes}</p></section>}
        <section className="mt-5"><h2 className="mb-1 font-semibold">Activity</h2>
          <ul className="text-xs">{c.activity.map((a) => <li key={a.id}>{fmtDateTime(a.at)} — {a.text}</li>)}</ul></section>
        <footer className="mt-6"><Notice t="neutral">This report reflects reviewer assessments of suspected activity. It is not confirmation of fraud or of any platform enforcement action.</Notice></footer>
      </article>
    </>
  );
}
