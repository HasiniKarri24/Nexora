import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import { BrandTile, Notice, PageHeader } from "@/components/drp/common";
import { BrandFormDialog } from "@/components/drp/BrandForm";

export const Route = createFileRoute("/brands/")({
  head: () => ({
    meta: [
      { title: "Brand Registry — Sentinel DRP" },
      { name: "description", content: "Official brand assets used as the reference for monitoring." },
      { property: "og:title", content: "Brand Registry — Sentinel DRP" },
      { property: "og:description", content: "Official brand assets used as the reference for monitoring." },
    ],
  }),
  component: Brands,
});

function Brands() {
  const { state, allFindings } = useStore();
  const [open, setOpen] = useState(false);
  return (
    <>
      <PageHeader crumbs={[{ label: "Brand Registry" }]} title="Brand Registry"
        description="Register official domains, accounts and apps. Monitoring compares findings against these details."
        actions={<Button onClick={() => setOpen(true)}><Plus className="h-4 w-4" />Add brand</Button>} />
      <div className="mb-4"><Notice>Brand details are supplied by users and have not been independently verified.</Notice></div>
      <div className="grid gap-4 md:grid-cols-2">
        {state.brands.map((b) => {
          const n = allFindings.filter((f) => f.brandId === b.id).length;
          return (
            <Link key={b.id} to="/brands/$id" params={{ id: b.id }} className="rounded-lg border bg-card p-5 transition-colors hover:border-primary/40">
              <div className="flex items-center gap-3"><BrandTile name={b.name} color={b.logoColor} size={44} />
                <div><p className="font-semibold">{b.name}</p><p className="text-xs text-muted-foreground">{b.industry}</p></div></div>
              <dl className="mt-4 grid grid-cols-3 gap-2 text-xs">
                <div><dt className="text-muted-foreground">Domains</dt><dd className="text-base font-semibold">{b.approvedDomains.length}</dd></div>
                <div><dt className="text-muted-foreground">Official handles</dt><dd className="text-base font-semibold">{b.socialHandles.length}</dd></div>
                <div><dt className="text-muted-foreground">Findings</dt><dd className="text-base font-semibold">{n}</dd></div>
              </dl>
            </Link>
          );
        })}
      </div>
      {open && <BrandFormDialog open={open} onOpenChange={setOpen} />}
    </>
  );
}
