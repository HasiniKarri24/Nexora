import type { AppState, Brand, SocialProfile, AppListing, Evidence, Case, DataSource, Notification } from "./types";

/** Fixed "now" for the demo so relative dates are stable. */
export const DEMO_NOW = "2026-10-07T09:00:00Z";

const brands: Brand[] = [
  {
    id: "b-northwind",
    name: "Northwind Bank",
    industry: "Retail banking",
    logoColor: "oklch(0.55 0.15 255)",
    website: "https://northwindbank.example",
    approvedDomains: ["northwindbank.example", "help.northwindbank.example"],
    socialHandles: [
      { platform: "X", handle: "@northwindbank" },
      { platform: "Instagram", handle: "@northwind.bank" },
      { platform: "Facebook", handle: "NorthwindBankOfficial" },
    ],
    officialApps: [{ name: "Northwind Mobile", packageId: "com.northwindbank.mobile", publisher: "Northwind Bank Ltd" }],
    partners: ["Harbor Card Services (authorized reseller)"],
    aliases: ["Northwind", "NW Bank", "Nortwind Bank", "North Wind Bank"],
    keywords: ["northwind", "nw bank", "northwind support", "northwind rewards"],
  },
  {
    id: "b-lumora",
    name: "Lumora Wallet",
    industry: "Digital payments",
    logoColor: "oklch(0.6 0.14 160)",
    website: "https://lumora.example",
    approvedDomains: ["lumora.example"],
    socialHandles: [
      { platform: "X", handle: "@lumorawallet" },
      { platform: "TikTok", handle: "@lumora" },
    ],
    officialApps: [{ name: "Lumora Wallet", packageId: "com.lumora.wallet", publisher: "Lumora Inc." }],
    partners: [],
    aliases: ["Lumora", "Lumorra", "Lumora Pay"],
    keywords: ["lumora", "lumora wallet", "lumora airdrop"],
  },
];

const base = { similarities: [], domainMismatches: [], misleadingClaims: [], suspiciousRequests: [], missingInfo: [] };

const profiles: SocialProfile[] = [
  {
    ...base, id: "sp-01", brandId: "b-northwind", platform: "X", displayName: "Northwind Bank", username: "@northwindbank",
    bio: "Official account of Northwind Bank. Support: help.northwindbank.example", url: "https://northwindbank.example",
    relationship: "official", category: "none", priority: "none", status: "authorized",
    warningSigns: [], firstDetected: "2026-08-02", lastChecked: "2026-10-06",
  },
  {
    ...base, id: "sp-02", brandId: "b-northwind", platform: "Instagram", displayName: "Harbor Card Services", username: "@harborcards",
    bio: "Authorized Northwind card reseller. Visit any branch for applications.", url: "https://harborcards.example",
    relationship: "authorized", category: "none", priority: "none", status: "authorized",
    warningSigns: [], firstDetected: "2026-08-10", lastChecked: "2026-10-05",
  },
  {
    ...base, id: "sp-03", brandId: "b-northwind", platform: "Instagram", displayName: "Northwind Fans (unofficial)", username: "@nw_fanpage",
    bio: "Fan page. Not affiliated with Northwind Bank. Sharing branch photos & history.",
    relationship: "fan", category: "none", priority: "low", status: "authorized",
    warningSigns: ["Uses brand name"], similarities: ["Brand name in display name, clearly marked unofficial"],
    firstDetected: "2026-09-01", lastChecked: "2026-10-04",
  },
  {
    id: "sp-04", brandId: "b-northwind", platform: "X", displayName: "Northwind Bank Support", username: "@northwind_helpdesk",
    bio: "24/7 Northwind customer support. DM us your account number to verify. Secure portal: northwind-verify.example",
    url: "https://northwind-verify.example/login",
    relationship: "unknown", category: "impersonation", priority: "high", status: "needs_review",
    warningSigns: ["Support claim", "Unapproved domain", "Requests account details"],
    similarities: ["Display name matches official brand", "Profile image resembles official logo (blue N mark)"],
    domainMismatches: ["Links to northwind-verify.example, not in approved domains"],
    misleadingClaims: ["Claims to be official 24/7 support"],
    suspiciousRequests: ["Asks users to DM account numbers"],
    missingInfo: ["Account creation date not supplied", "Follower history not available"],
    firstDetected: "2026-09-22", lastChecked: "2026-10-06",
  },
  {
    id: "sp-05", brandId: "b-northwind", platform: "Facebook", displayName: "Northwind Rewards Giveaway", username: "NorthwindRewards2026",
    bio: "🎉 Celebrating 50 years! Claim your $500 reward — verify at northwind-verify.example. Limited time!",
    url: "https://northwind-verify.example/reward",
    relationship: "unknown", category: "suspected_scam", priority: "high", status: "new",
    warningSigns: ["Giveaway offer", "Unapproved domain", "Urgency language"],
    similarities: ["Uses Northwind wordmark"],
    domainMismatches: ["Links to northwind-verify.example"],
    misleadingClaims: ["Implies official anniversary promotion"],
    suspiciousRequests: ["Asks users to 'verify' login to claim reward"],
    missingInfo: ["No official announcement found in supplied brand data"],
    firstDetected: "2026-09-25", lastChecked: "2026-10-06",
  },
  {
    id: "sp-06", brandId: "b-northwind", platform: "Telegram", displayName: "Northwind Verification Desk", username: "@nw_verify_desk",
    bio: "Official verification channel. Complete KYC at northwind-verify.example to avoid account suspension.",
    url: "https://northwind-verify.example/kyc",
    relationship: "unknown", category: "impersonation", priority: "high", status: "needs_review",
    warningSigns: ["Verification claim", "Unapproved domain", "Threat of suspension"],
    similarities: ["Name contains brand alias 'Northwind'"],
    domainMismatches: ["Links to northwind-verify.example"],
    misleadingClaims: ["Claims to be official verification channel"],
    suspiciousRequests: ["Requests KYC documents via external site"],
    missingInfo: ["Channel member count not supplied"],
    firstDetected: "2026-09-27", lastChecked: "2026-10-05",
  },
  {
    ...base, id: "sp-07", brandId: "b-northwind", platform: "TikTok", displayName: "Nortwind Bank Tips", username: "@nortwind.tips",
    bio: "Money tips 💸 link in bio",
    relationship: "unknown", category: "impersonation", priority: "medium", status: "new",
    warningSigns: ["Misspelled brand name"], similarities: ["Uses common misspelling 'Nortwind'"],
    missingInfo: ["No link or content supplied", "Insufficient evidence to assess intent"],
    firstDetected: "2026-10-01", lastChecked: "2026-10-03",
  },
  {
    ...base, id: "sp-08", brandId: "b-northwind", platform: "X", displayName: "NW Bank Careers", username: "@nwbank_jobs",
    bio: "Hiring now! Apply via the form. Processing fee required.",
    url: "https://nw-careers.example",
    relationship: "unknown", category: "suspected_scam", priority: "medium", status: "needs_review",
    warningSigns: ["Fee request", "Unapproved domain"],
    domainMismatches: ["Links to nw-careers.example"], suspiciousRequests: ["Requests a processing fee from applicants"],
    firstDetected: "2026-09-18", lastChecked: "2026-10-02",
  },
  {
    ...base, id: "sp-09", brandId: "b-lumora", platform: "X", displayName: "Lumora Wallet", username: "@lumorawallet",
    bio: "Official Lumora Wallet. We will never DM you first.", url: "https://lumora.example",
    relationship: "official", category: "none", priority: "none", status: "authorized",
    warningSigns: [], firstDetected: "2026-08-05", lastChecked: "2026-10-06",
  },
  {
    id: "sp-10", brandId: "b-lumora", platform: "X", displayName: "Lumora Airdrop", username: "@lumora_airdrop",
    bio: "Free LUM tokens for early users! Connect wallet at lumora-claim.example",
    url: "https://lumora-claim.example",
    relationship: "unknown", category: "suspected_scam", priority: "high", status: "new",
    warningSigns: ["Giveaway offer", "Unapproved domain", "Wallet connect request"],
    similarities: ["Uses Lumora logo colors"],
    domainMismatches: ["Links to lumora-claim.example"],
    misleadingClaims: ["Implies official token airdrop"],
    suspiciousRequests: ["Asks users to connect a wallet"],
    missingInfo: ["No official airdrop listed in brand registry"],
    firstDetected: "2026-09-29", lastChecked: "2026-10-06",
  },
  {
    ...base, id: "sp-11", brandId: "b-lumora", platform: "Instagram", displayName: "Lumorra Support", username: "@lumorra.support",
    bio: "Wallet issues? DM for instant recovery help.",
    relationship: "unknown", category: "impersonation", priority: "medium", status: "needs_review",
    warningSigns: ["Support claim", "Misspelled brand name"],
    similarities: ["Uses alias 'Lumorra'"], misleadingClaims: ["Offers recovery support"],
    suspiciousRequests: ["Invites DMs about wallet recovery"],
    missingInfo: ["No website supplied"],
    firstDetected: "2026-09-12", lastChecked: "2026-09-30",
  },
  {
    ...base, id: "sp-12", brandId: "b-lumora", platform: "TikTok", displayName: "Crypto with Ana", username: "@anacrypto",
    bio: "Reviewing wallets incl. Lumora. Opinions my own.",
    relationship: "unknown", category: "impersonation", priority: "low", status: "dismissed",
    dismissReason: "Independent reviewer; no brand claims.",
    warningSigns: ["Mentions brand"], firstDetected: "2026-09-08", lastChecked: "2026-09-20",
  },
];

const apps: AppListing[] = [
  {
    id: "ap-01", brandId: "b-northwind", name: "Northwind Mobile", store: "Google Play", publisher: "Northwind Bank Ltd",
    packageId: "com.northwindbank.mobile", description: "The official Northwind Bank app.", website: "https://northwindbank.example",
    privacyDomain: "northwindbank.example", relationship: "official", category: "none", priority: "none", status: "authorized",
    warningSigns: [], similarities: [], suspiciousWording: [], missingInfo: [], firstDetected: "2026-08-02", lastChecked: "2026-10-06",
  },
  {
    id: "ap-02", brandId: "b-northwind", name: "Northwind Secure Verify", store: "Third-party APK site", publisher: "NW Digital Services",
    packageId: "com.nw.secureverify", description: "Verify your Northwind account instantly. Required update for all customers to avoid suspension.",
    website: "https://northwind-verify.example", privacyDomain: "northwind-verify.example",
    relationship: "unknown", category: "suspicious_app", priority: "high", status: "needs_review",
    warningSigns: ["Similar icon", "Unfamiliar publisher", "Unapproved domain"],
    similarities: ["Icon uses blue 'N' mark similar to official app", "Name contains 'Northwind'"],
    suspiciousWording: ["'Required update for all customers'", "'to avoid suspension'"],
    missingInfo: ["Download count not supplied", "Publisher registration details unavailable"],
    permissions: { items: ["Read SMS", "Accessibility service"], source: "Listing page text captured 2026-09-28" },
    firstDetected: "2026-09-28", lastChecked: "2026-10-06",
  },
  {
    id: "ap-03", brandId: "b-northwind", name: "NW Rewards Wallet", store: "Google Play", publisher: "RewardsHub Apps",
    packageId: "com.rewardshub.nwwallet", description: "Collect your Northwind points and convert to cash.",
    website: "https://rewardshub.example", privacyDomain: "rewardshub.example",
    relationship: "unknown", category: "suspicious_app", priority: "medium", status: "new",
    warningSigns: ["Unfamiliar publisher", "Brand alias in name"],
    similarities: ["Uses alias 'NW'"], suspiciousWording: ["'convert to cash'"],
    missingInfo: ["No icon supplied for comparison"], firstDetected: "2026-09-20", lastChecked: "2026-10-01",
  },
  {
    id: "ap-04", brandId: "b-northwind", name: "Budget Buddy", store: "Apple App Store", publisher: "Pocket Labs",
    description: "Budgeting app supporting many banks including Northwind.",
    relationship: "unknown", category: "suspicious_app", priority: "low", status: "dismissed", dismissReason: "Third-party integration; no impersonation.",
    warningSigns: ["Mentions brand"], similarities: [], suspiciousWording: [], missingInfo: [],
    firstDetected: "2026-09-05", lastChecked: "2026-09-15",
  },
  {
    id: "ap-05", brandId: "b-lumora", name: "Lumora Wallet", store: "Apple App Store", publisher: "Lumora Inc.",
    packageId: "com.lumora.wallet", description: "Official Lumora Wallet.", website: "https://lumora.example", privacyDomain: "lumora.example",
    relationship: "official", category: "none", priority: "none", status: "authorized",
    warningSigns: [], similarities: [], suspiciousWording: [], missingInfo: [], firstDetected: "2026-08-05", lastChecked: "2026-10-06",
  },
  {
    id: "ap-06", brandId: "b-lumora", name: "Lumora Claim", store: "Google Play", publisher: "LMR Tools",
    packageId: "io.lmr.claim", description: "Claim your Lumora airdrop. Enter seed phrase to sync.",
    website: "https://lumora-claim.example", privacyDomain: "lumora-claim.example",
    relationship: "unknown", category: "suspicious_app", priority: "high", status: "new",
    warningSigns: ["Requests seed phrase", "Unapproved domain", "Unfamiliar publisher"],
    similarities: ["Name contains 'Lumora'"], suspiciousWording: ["'Enter seed phrase to sync'"],
    missingInfo: ["Package ID not verified against store"], firstDetected: "2026-09-30", lastChecked: "2026-10-06",
  },
];

const evidence: Evidence[] = [
  { id: "ev-01", entityId: "sp-04", label: "Bio text", excerpt: "DM us your account number to verify.", source: "X profile bio (demo capture)", capturedAt: "2026-09-22T10:14:00Z" },
  { id: "ev-02", entityId: "sp-04", label: "Profile link", excerpt: "https://northwind-verify.example/login", source: "X profile URL field (demo capture)", capturedAt: "2026-09-22T10:14:00Z" },
  { id: "ev-03", entityId: "sp-05", label: "Post text", excerpt: "Claim your $500 reward — verify at northwind-verify.example", source: "Facebook page post (demo capture)", capturedAt: "2026-09-25T08:02:00Z" },
  { id: "ev-04", entityId: "sp-06", label: "Channel description", excerpt: "Complete KYC at northwind-verify.example to avoid account suspension.", source: "Telegram channel info (demo capture)", capturedAt: "2026-09-27T16:40:00Z" },
  { id: "ev-05", entityId: "ap-02", label: "Developer website", excerpt: "https://northwind-verify.example", source: "APK listing page (demo capture)", capturedAt: "2026-09-28T12:00:00Z" },
  { id: "ev-06", entityId: "ap-02", label: "Description", excerpt: "Required update for all customers to avoid suspension.", source: "APK listing page (demo capture)", capturedAt: "2026-09-28T12:00:00Z" },
  { id: "ev-07", entityId: "ap-02", label: "Icon comparison", excerpt: "Blue rounded square with white 'N' — visually similar to official icon.", source: "Manual reviewer note (demo)", capturedAt: "2026-09-28T12:30:00Z" },
  { id: "ev-08", entityId: "sp-08", label: "Bio text", excerpt: "Processing fee required.", source: "X profile bio (demo capture)", capturedAt: "2026-09-18T09:00:00Z" },
  { id: "ev-09", entityId: "sp-10", label: "Bio text", excerpt: "Connect wallet at lumora-claim.example", source: "X profile bio (demo capture)", capturedAt: "2026-09-29T11:20:00Z" },
  { id: "ev-10", entityId: "ap-06", label: "Description", excerpt: "Enter seed phrase to sync.", source: "Google Play listing (demo capture)", capturedAt: "2026-09-30T14:00:00Z" },
  { id: "ev-11", entityId: "sp-11", label: "Bio text", excerpt: "DM for instant recovery help.", source: "Instagram bio (demo capture)", capturedAt: "2026-09-12T13:00:00Z" },
  { id: "ev-12", entityId: "ap-03", label: "Description", excerpt: "convert to cash", source: "Google Play listing (demo capture)", capturedAt: "2026-09-20T10:00:00Z" },
  { id: "ev-13", entityId: "sp-07", label: "Username", excerpt: "@nortwind.tips", source: "TikTok profile (demo capture)", capturedAt: "2026-10-01T07:00:00Z" },
];

const cases: Case[] = [
  {
    id: "CASE-1001", title: "northwind-verify.example cluster", brandId: "b-northwind", priority: "high", assignee: "Priya Raman",
    status: "investigating", summary: "Multiple profiles reference the same unapproved domain used for login and KYC pages.",
    findingIds: ["sp-04", "sp-06"], notes: "Domain appears in support and verification claims. App listing not yet linked.",
    activity: [
      { id: "a1", at: "2026-09-27T17:00:00Z", text: "Case created by Priya Raman" },
      { id: "a2", at: "2026-09-27T17:05:00Z", text: "Linked @northwind_helpdesk and @nw_verify_desk" },
      { id: "a3", at: "2026-10-01T09:00:00Z", text: "Status changed to Investigating" },
    ],
    updatedAt: "2026-10-01T09:00:00Z",
  },
  {
    id: "CASE-1002", title: "Fake careers fee request", brandId: "b-northwind", priority: "medium", assignee: "Diego Alvarez",
    status: "ready_for_review", summary: "Recruitment profile requesting processing fees.", findingIds: ["sp-08"], notes: "",
    activity: [{ id: "a4", at: "2026-09-19T10:00:00Z", text: "Case created by Diego Alvarez" }, { id: "a5", at: "2026-09-30T12:00:00Z", text: "Status changed to Ready for review" }],
    updatedAt: "2026-09-30T12:00:00Z",
  },
  {
    id: "CASE-1003", title: "Lumora airdrop claims", brandId: "b-lumora", priority: "high", assignee: "Priya Raman",
    status: "new", summary: "Airdrop profile and claim app share lumora-claim.example.", findingIds: ["sp-10", "ap-06"], notes: "",
    activity: [{ id: "a6", at: "2026-10-01T15:00:00Z", text: "Case created by Priya Raman" }], updatedAt: "2026-10-01T15:00:00Z",
  },
  {
    id: "CASE-1004", title: "Independent reviewer mention", brandId: "b-lumora", priority: "low", assignee: "Diego Alvarez",
    status: "dismissed", summary: "Reviewer account mentioning brand; no impersonation identified.", findingIds: ["sp-12"], notes: "Dismissed after review.",
    activity: [{ id: "a7", at: "2026-09-10T10:00:00Z", text: "Case created" }, { id: "a8", at: "2026-09-20T10:00:00Z", text: "Status changed to Dismissed" }],
    updatedAt: "2026-09-20T10:00:00Z",
  },
];

const sources: DataSource[] = [
  { id: "src-social", name: "Social platforms", category: "Social platforms", status: "demo", dataType: "Public profile metadata, bios, links", lastImport: "2026-10-06T06:00:00Z", limitations: "Demo dataset only. No live platform accounts are being monitored.", integrationNeeds: "A backend service with approved platform API access (credentials stored server-side), rate limiting and scheduled collection jobs." },
  { id: "src-apps", name: "App stores", category: "App stores", status: "demo", dataType: "Listing name, publisher, description, links", lastImport: "2026-10-06T06:00:00Z", limitations: "Demo dataset only. Listing analysis cannot determine whether an app contains malware.", integrationNeeds: "A backend collector for store listing metadata and optional APK analysis by a separate security service." },
  { id: "src-manual", name: "Manual submissions", category: "Manual submissions", status: "demo", dataType: "Reviewer-entered profiles and apps via Quick Analyze", limitations: "Only sample records return prepared results until a backend is connected.", integrationNeeds: "An analysis API endpoint and storage for submissions and uploaded images." },
  { id: "src-upload", name: "Uploaded datasets", category: "Uploaded datasets", status: "not_connected", dataType: "CSV / JSON exports", limitations: "Not connected. File import requires backend parsing and storage.", integrationNeeds: "Server-side file upload, schema validation and deduplication." },
];

const notifications: Notification[] = [
  { id: "n1", text: "New high-priority finding: Lumora Claim app", at: "2026-09-30T14:05:00Z", read: false, link: "/apps/ap-06" },
  { id: "n2", text: "Giveaway page links to northwind-verify.example", at: "2026-09-25T08:10:00Z", read: false, link: "/social/sp-05" },
  { id: "n3", text: "CASE-1002 moved to Ready for review", at: "2026-09-30T12:00:00Z", read: true, link: "/cases/CASE-1002" },
];

export function createDemoState(): AppState {
  return structuredClone({
    brands, profiles, apps, evidence, cases, sources, notifications,
    settings: {
      workspaceName: "Hacxlerate Demo Workspace", defaultBrandId: "b-northwind", theme: "light",
      reviewerName: "Priya Raman", reviewerRole: "Brand protection analyst",
      notifyHighPriority: true, notifyCaseUpdates: true,
    },
    datasetLoaded: true,
  });
}

export const REVIEWERS = ["Priya Raman", "Diego Alvarez", "Unassigned"];

/** Prepared Quick Analyze sample inputs that map to existing records. */
export const SAMPLE_SOCIAL = {
  brandId: "b-northwind", platform: "X", username: "@northwind_helpdesk", displayName: "Northwind Bank Support",
  bio: "24/7 Northwind customer support. DM us your account number to verify. Secure portal: northwind-verify.example",
  website: "https://northwind-verify.example/login", matchId: "sp-04",
};
export const SAMPLE_APP = {
  brandId: "b-northwind", name: "Northwind Secure Verify", publisher: "NW Digital Services", packageId: "com.nw.secureverify",
  description: "Verify your Northwind account instantly. Required update for all customers to avoid suspension.",
  storeUrl: "https://apk-mirror.example/nw-secureverify", website: "https://northwind-verify.example", matchId: "ap-02",
};
