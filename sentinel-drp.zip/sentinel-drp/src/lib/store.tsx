import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { createDemoState, DEMO_NOW } from "./demo-data";
import type { AppState, Brand, Case, CaseStatus, Finding, ReviewStatus, Settings, AppListing, SocialProfile } from "./types";

/**
 * Local demo service layer. Every mutation goes through these functions so a
 * real backend client can replace them later without touching pages.
 */
const KEY = "drp-demo-state-v1";

export type DateRange = "7d" | "30d" | "90d" | "all";

interface Ctx {
  state: AppState;
  hydrated: boolean;
  brandId: string; // "all" or brand id
  setBrandId: (id: string) => void;
  range: DateRange;
  setRange: (r: DateRange) => void;
  findings: Finding[]; // filtered by brand + range
  allFindings: Finding[];
  upsertBrand: (b: Brand) => void;
  setFindingStatus: (id: string, status: ReviewStatus, reason?: string) => void;
  createCase: (input: { title: string; brandId: string; priority: Case["priority"]; findingIds: string[]; summary?: string }) => string;
  updateCase: (id: string, patch: Partial<Pick<Case, "status" | "assignee" | "notes">>, activity?: string) => void;
  addFindingToCase: (caseId: string, findingId: string) => void;
  removeFindingFromCase: (caseId: string, findingId: string) => void;
  markNotificationsRead: () => void;
  updateSettings: (patch: Partial<Settings>) => void;
  resetDemo: () => void;
  loadDemoDataset: () => void;
}

const StoreCtx = createContext<Ctx | null>(null);

export function toFindings(profiles: SocialProfile[], apps: AppListing[]): Finding[] {
  return [
    ...profiles.filter((p) => p.category !== "none").map((p) => ({
      id: p.id, kind: "social" as const, brandId: p.brandId, name: `${p.displayName} (${p.username})`, source: p.platform,
      category: p.category, priority: p.priority, status: p.status, firstDetected: p.firstDetected,
    })),
    ...apps.filter((a) => a.category !== "none").map((a) => ({
      id: a.id, kind: "app" as const, brandId: a.brandId, name: a.name, source: a.store,
      category: a.category, priority: a.priority, status: a.status, firstDetected: a.firstDetected,
    })),
  ];
}

export function inRange(date: string, range: DateRange) {
  if (range === "all") return true;
  const days = range === "7d" ? 7 : range === "30d" ? 30 : 90;
  return new Date(DEMO_NOW).getTime() - new Date(date).getTime() <= days * 86400000;
}

const nowIso = () => new Date().toISOString();
const uid = () => Math.random().toString(36).slice(2, 9);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(() => createDemoState());
  const [hydrated, setHydrated] = useState(false);
  const [brandId, setBrandId] = useState("b-northwind");
  const [range, setRange] = useState<DateRange>("all");

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const s = JSON.parse(raw) as AppState;
        setState(s);
        setBrandId(s.settings.defaultBrandId || "all");
      }
    } catch { /* ignore corrupt storage */ }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) localStorage.setItem(KEY, JSON.stringify(state));
    document.documentElement.classList.toggle("dark", state.settings.theme === "dark");
  }, [state, hydrated]);

  const allFindings = useMemo(() => toFindings(state.profiles, state.apps), [state.profiles, state.apps]);
  const findings = useMemo(
    () => allFindings.filter((f) => (brandId === "all" || f.brandId === brandId) && inRange(f.firstDetected, range)),
    [allFindings, brandId, range],
  );

  const reviewer = state.settings.reviewerName;

  const setFindingStatus = useCallback((id: string, status: ReviewStatus, reason?: string) => {
    setState((s) => ({
      ...s,
      profiles: s.profiles.map((p) => (p.id === id ? { ...p, status, dismissReason: reason ?? p.dismissReason } : p)),
      apps: s.apps.map((a) => (a.id === id ? { ...a, status, dismissReason: reason ?? a.dismissReason } : a)),
    }));
  }, []);

  const createCase: Ctx["createCase"] = useCallback((input) => {
    let newId = "";
    setState((s) => {
      const max = Math.max(1000, ...s.cases.map((c) => Number(c.id.split("-")[1]) || 0));
      newId = `CASE-${max + 1}`;
      const c: Case = {
        id: newId, title: input.title, brandId: input.brandId, priority: input.priority, assignee: reviewer,
        status: "new", summary: input.summary ?? "", findingIds: input.findingIds, notes: "",
        activity: [{ id: uid(), at: nowIso(), text: `Case created by ${reviewer}` },
          ...input.findingIds.map((f) => ({ id: uid(), at: nowIso(), text: `Linked finding ${f}` }))],
        updatedAt: nowIso(),
      };
      const ids = new Set(input.findingIds);
      return {
        ...s, cases: [c, ...s.cases],
        profiles: s.profiles.map((p) => (ids.has(p.id) ? { ...p, status: "in_case" } : p)),
        apps: s.apps.map((a) => (ids.has(a.id) ? { ...a, status: "in_case" } : a)),
      };
    });
    // compute id synchronously for navigation
    const max = Math.max(1000, ...state.cases.map((c) => Number(c.id.split("-")[1]) || 0));
    return newId || `CASE-${max + 1}`;
  }, [reviewer, state.cases]);

  const updateCase: Ctx["updateCase"] = useCallback((id, patch, activity) => {
    setState((s) => ({
      ...s,
      cases: s.cases.map((c) => c.id === id ? {
        ...c, ...patch, updatedAt: nowIso(),
        activity: activity ? [...c.activity, { id: uid(), at: nowIso(), text: activity }] : c.activity,
      } : c),
    }));
  }, []);

  const addFindingToCase = useCallback((caseId: string, findingId: string) => {
    setState((s) => ({
      ...s,
      cases: s.cases.map((c) => c.id === caseId && !c.findingIds.includes(findingId) ? {
        ...c, findingIds: [...c.findingIds, findingId], updatedAt: nowIso(),
        activity: [...c.activity, { id: uid(), at: nowIso(), text: `Linked finding ${findingId}` }],
      } : c),
      profiles: s.profiles.map((p) => (p.id === findingId ? { ...p, status: "in_case" } : p)),
      apps: s.apps.map((a) => (a.id === findingId ? { ...a, status: "in_case" } : a)),
    }));
  }, []);

  const removeFindingFromCase = useCallback((caseId: string, findingId: string) => {
    setState((s) => ({
      ...s,
      cases: s.cases.map((c) => c.id === caseId ? {
        ...c, findingIds: c.findingIds.filter((f) => f !== findingId), updatedAt: nowIso(),
        activity: [...c.activity, { id: uid(), at: nowIso(), text: `Removed finding ${findingId}` }],
      } : c),
    }));
  }, []);

  const value: Ctx = {
    state, hydrated, brandId, setBrandId, range, setRange, findings, allFindings,
    upsertBrand: (b) => setState((s) => ({
      ...s, brands: s.brands.some((x) => x.id === b.id) ? s.brands.map((x) => (x.id === b.id ? b : x)) : [...s.brands, b],
    })),
    setFindingStatus, createCase, updateCase, addFindingToCase, removeFindingFromCase,
    markNotificationsRead: () => setState((s) => ({ ...s, notifications: s.notifications.map((n) => ({ ...n, read: true })) })),
    updateSettings: (patch) => setState((s) => ({ ...s, settings: { ...s.settings, ...patch } })),
    resetDemo: () => { localStorage.removeItem(KEY); setState(createDemoState()); setBrandId("b-northwind"); },
    loadDemoDataset: () => {
      const fresh = createDemoState();
      setState((s) => ({ ...fresh, settings: s.settings, sources: fresh.sources.map((src) => ({ ...src, lastImport: src.status === "demo" ? nowIso() : undefined })) }));
    },
  };

  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}

export function useStore() {
  const c = useContext(StoreCtx);
  if (!c) throw new Error("useStore outside provider");
  return c;
}

export const CASE_STATUSES: { value: CaseStatus; label: string }[] = [
  { value: "new", label: "New" }, { value: "investigating", label: "Investigating" },
  { value: "ready_for_review", label: "Ready for review" }, { value: "resolved", label: "Resolved" }, { value: "dismissed", label: "Dismissed" },
];

export function fmtDate(d: string) {
  return new Date(d).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}
export function fmtDateTime(d: string) {
  return new Date(d).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "UTC" }) + " UTC";
}
