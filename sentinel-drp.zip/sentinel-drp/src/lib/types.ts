export type Priority = "high" | "medium" | "low" | "none";
export type ReviewStatus = "new" | "needs_review" | "authorized" | "dismissed" | "in_case";
export type FindingCategory = "impersonation" | "suspected_scam" | "suspicious_app" | "none";
export type Relationship = "official" | "authorized" | "fan" | "unknown";
export type Platform = "X" | "Instagram" | "Facebook" | "Telegram" | "TikTok";
export type AppStore = "Google Play" | "Apple App Store" | "Third-party APK site";
export type CaseStatus = "new" | "investigating" | "ready_for_review" | "resolved" | "dismissed";

export interface Brand {
  id: string;
  name: string;
  industry: string;
  logoColor: string; // oklch string used for the initials tile
  website: string;
  approvedDomains: string[];
  socialHandles: { platform: Platform; handle: string }[];
  officialApps: { name: string; packageId: string; publisher: string }[];
  partners: string[];
  aliases: string[];
  keywords: string[];
}

export interface Evidence {
  id: string;
  entityId: string;
  label: string;
  excerpt: string;
  source: string;
  capturedAt: string; // ISO
}

export interface SocialProfile {
  id: string;
  brandId: string;
  platform: Platform;
  displayName: string;
  username: string;
  bio: string;
  url?: string | undefined;
  relationship: Relationship;
  category: FindingCategory;
  priority: Priority;
  status: ReviewStatus;
  warningSigns: string[];
  similarities: string[];
  domainMismatches: string[];
  misleadingClaims: string[];
  suspiciousRequests: string[];
  missingInfo: string[];
  firstDetected: string;
  lastChecked: string;
  dismissReason?: string | undefined;
}

export interface AppListing {
  id: string;
  brandId: string;
  name: string;
  store: AppStore;
  publisher: string;
  packageId?: string | undefined;
  description: string;
  website?: string | undefined;
  privacyDomain?: string | undefined;
  relationship: Relationship;
  category: FindingCategory;
  priority: Priority;
  status: ReviewStatus;
  warningSigns: string[];
  similarities: string[];
  suspiciousWording: string[];
  missingInfo: string[];
  permissions?: { items: string[]; source: string } | undefined;
  firstDetected: string;
  lastChecked: string;
  dismissReason?: string | undefined;
}

/** A finding is any monitored profile or app flagged with a category. */
export interface Finding {
  id: string;
  kind: "social" | "app";
  brandId: string;
  name: string;
  source: string;
  category: FindingCategory;
  priority: Priority;
  status: ReviewStatus;
  firstDetected: string;
}

export interface CaseActivity {
  id: string;
  at: string;
  text: string;
}

export interface Case {
  id: string;
  title: string;
  brandId: string;
  priority: Priority;
  assignee: string;
  status: CaseStatus;
  summary: string;
  findingIds: string[];
  notes: string;
  activity: CaseActivity[];
  updatedAt: string;
}

export interface DataSource {
  id: string;
  name: string;
  category: "Social platforms" | "App stores" | "Manual submissions" | "Uploaded datasets";
  status: "demo" | "not_connected" | "error";
  dataType: string;
  lastImport?: string | undefined;
  limitations: string;
  integrationNeeds: string;
}

export interface Notification {
  id: string;
  text: string;
  at: string;
  read: boolean;
  link?: string | undefined;
}

export interface Settings {
  workspaceName: string;
  defaultBrandId: string;
  theme: "light" | "dark";
  reviewerName: string;
  reviewerRole: string;
  notifyHighPriority: boolean;
  notifyCaseUpdates: boolean;
}

export interface AppState {
  brands: Brand[];
  profiles: SocialProfile[];
  apps: AppListing[];
  evidence: Evidence[];
  cases: Case[];
  sources: DataSource[];
  notifications: Notification[];
  settings: Settings;
  datasetLoaded: boolean;
}
