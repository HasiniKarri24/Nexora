import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useStore } from "@/lib/store";
import type { Priority } from "@/lib/types";

export function CreateCaseDialog({ open, onOpenChange, findingIds, brandId, priority, defaultTitle }: {
  open: boolean; onOpenChange: (o: boolean) => void; findingIds: string[]; brandId: string; priority: Priority; defaultTitle: string;
}) {
  const { createCase, state } = useStore();
  const navigate = useNavigate();
  const [title, setTitle] = useState(defaultTitle);
  const [summary, setSummary] = useState("");
  const [bId, setBId] = useState(brandId);
  const [err, setErr] = useState("");
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader><DialogTitle>Create case</DialogTitle><DialogDescription>Saved locally in this browser (demo).</DialogDescription></DialogHeader>
        <form className="space-y-3" onSubmit={(e) => {
          e.preventDefault();
          if (!title.trim()) { setErr("Title is required."); return; }
          const id = createCase({ title: title.trim(), brandId: bId, priority, findingIds, summary });
          toast.success(`${id} created`);
          onOpenChange(false);
          navigate({ to: "/cases/$id", params: { id } });
        }}>
          <div><Label htmlFor="ct">Title</Label><Input id="ct" value={title} onChange={(e) => { setTitle(e.target.value); setErr(""); }} aria-invalid={!!err} />
            {err && <p className="mt-1 text-xs text-danger">{err}</p>}</div>
          <div><Label>Brand</Label>
            <Select value={bId} onValueChange={setBId}><SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{state.brands.map((b) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent></Select></div>
          <div><Label htmlFor="cs">Summary</Label><Textarea id="cs" value={summary} onChange={(e) => setSummary(e.target.value)} /></div>
          <p className="text-xs text-muted-foreground">{findingIds.length} finding(s) will be linked.</p>
          <DialogFooter><Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button><Button type="submit">Create case</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function ReviewActions({ id, brandId, priority, name }: { id: string; brandId: string; priority: Priority; name: string }) {
  const { setFindingStatus, state, addFindingToCase } = useStore();
  const [dismissOpen, setDismissOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [reasonErr, setReasonErr] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [caseId, setCaseId] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const linkedCases = state.cases.filter((c) => c.findingIds.includes(id));

  return (
    <div className="flex flex-col gap-2">
      <Button onClick={() => { setFindingStatus(id, "needs_review"); toast("Marked for review"); }}>Mark for review</Button>
      <Button variant="outline" onClick={() => { setFindingStatus(id, "authorized"); toast("Marked as authorized"); }}>Mark as authorized</Button>
      <Button variant="outline" onClick={() => setDismissOpen(true)}>Dismiss with reason</Button>
      <Button variant="outline" onClick={() => setAddOpen(true)}>Add to existing case</Button>
      <Button variant="secondary" onClick={() => setCreateOpen(true)}>Create case</Button>
      {linkedCases.length > 0 && <p className="text-xs text-muted-foreground">Linked to: {linkedCases.map((c) => c.id).join(", ")}</p>}

      <Dialog open={dismissOpen} onOpenChange={setDismissOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Dismiss finding</DialogTitle><DialogDescription>Record why this finding does not need further action.</DialogDescription></DialogHeader>
          <Label htmlFor="dr">Reason</Label>
          <Textarea id="dr" value={reason} onChange={(e) => { setReason(e.target.value); setReasonErr(false); }} aria-invalid={reasonErr} />
          {reasonErr && <p className="text-xs text-danger">A reason is required.</p>}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDismissOpen(false)}>Cancel</Button>
            <Button onClick={() => { if (!reason.trim()) { setReasonErr(true); return; } setFindingStatus(id, "dismissed", reason.trim()); setDismissOpen(false); toast("Finding dismissed"); }}>Dismiss</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add to existing case</DialogTitle><DialogDescription>Choose an open case for {name}.</DialogDescription></DialogHeader>
          <Select value={caseId} onValueChange={setCaseId}>
            <SelectTrigger aria-label="Case"><SelectValue placeholder="Select a case" /></SelectTrigger>
            <SelectContent>{state.cases.filter((c) => c.status !== "resolved" && c.status !== "dismissed").map((c) => <SelectItem key={c.id} value={c.id}>{c.id} — {c.title}</SelectItem>)}</SelectContent>
          </Select>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button disabled={!caseId} onClick={() => { addFindingToCase(caseId, id); setAddOpen(false); toast.success(`Added to ${caseId}`); }}>Add</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {createOpen && <CreateCaseDialog open={createOpen} onOpenChange={setCreateOpen} findingIds={[id]} brandId={brandId} priority={priority} defaultTitle={`Investigation: ${name}`} />}
    </div>
  );
}
