import { fmtDateTime, useStore } from "@/lib/store";

export function EvidenceList({ entityId }: { entityId: string }) {
  const { state } = useStore();
  const items = state.evidence.filter((e) => e.entityId === entityId);
  if (!items.length) return <p className="text-sm text-muted-foreground">No evidence excerpts captured for this record.</p>;
  return (
    <ul className="space-y-3">
      {items.map((e) => (
        <li key={e.id} className="rounded-md border-l-2 border-primary/50 bg-muted/50 px-3 py-2">
          <p className="text-xs font-medium text-muted-foreground">{e.label}</p>
          <p className="mt-0.5 font-mono text-sm">“{e.excerpt}”</p>
          <p className="mt-1 text-xs text-muted-foreground">{e.source} · {fmtDateTime(e.capturedAt)}</p>
        </li>
      ))}
    </ul>
  );
}
