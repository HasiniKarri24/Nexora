import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useStore } from "@/lib/store";
import type { Brand, Platform } from "@/lib/types";
import { BrandTile, Notice } from "./common";

const lines = (s: string) => s.split("\n").map((x) => x.trim()).filter(Boolean);
const COLORS = ["oklch(0.55 0.15 255)", "oklch(0.6 0.14 160)", "oklch(0.58 0.16 30)", "oklch(0.5 0.12 300)", "oklch(0.45 0.05 260)"];

export function BrandFormDialog({ open, onOpenChange, brand }: { open: boolean; onOpenChange: (o: boolean) => void; brand?: Brand }) {
  const { upsertBrand } = useStore();
  const [f, setF] = useState(() => ({
    name: brand?.name ?? "", industry: brand?.industry ?? "", website: brand?.website ?? "",
    logoColor: brand?.logoColor ?? COLORS[0]!,
    domains: brand?.approvedDomains.join("\n") ?? "",
    handles: brand?.socialHandles.map((h) => `${h.platform}: ${h.handle}`).join("\n") ?? "",
    apps: brand?.officialApps.map((a) => `${a.name} | ${a.packageId} | ${a.publisher}`).join("\n") ?? "",
    partners: brand?.partners.join("\n") ?? "", aliases: brand?.aliases.join("\n") ?? "",
  }));
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const er: Record<string, string> = {};
    if (!f.name.trim()) er["name"] = "Brand name is required.";
    if (!f.industry.trim()) er["industry"] = "Industry is required.";
    if (f.website && !/^https?:\/\//.test(f.website)) er["website"] = "Use a full URL starting with https://";
    setErrors(er);
    if (Object.keys(er).length) return;
    const aliases = lines(f.aliases);
    const b: Brand = {
      id: brand?.id ?? `b-${Date.now().toString(36)}`, name: f.name.trim(), industry: f.industry.trim(), logoColor: f.logoColor,
      website: f.website.trim(), approvedDomains: lines(f.domains),
      socialHandles: lines(f.handles).map((l) => { const [p = "", ...h] = l.split(":"); return { platform: (p.trim() as Platform) || "X", handle: h.join(":").trim() || p.trim() }; }),
      officialApps: lines(f.apps).map((l) => { const [name = "", packageId = "", publisher = ""] = l.split("|").map((x) => x.trim()); return { name, packageId, publisher }; }),
      partners: lines(f.partners), aliases,
      keywords: brand?.keywords ?? [f.name.trim().toLowerCase(), ...aliases.map((a) => a.toLowerCase())],
    };
    upsertBrand(b);
    toast.success(brand ? "Brand updated" : "Brand added");
    onOpenChange(false);
  }

  const field = (k: keyof typeof f, label: string, hint?: string, multi?: boolean) => (
    <div>
      <Label htmlFor={`bf-${k}`}>{label}</Label>
      {multi ? <Textarea id={`bf-${k}`} value={f[k]} onChange={set(k)} rows={3} /> : <Input id={`bf-${k}`} value={f[k]} onChange={set(k)} aria-invalid={!!errors[k]} />}
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
      {errors[k] && <p className="mt-1 text-xs text-danger">{errors[k]}</p>}
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader><DialogTitle>{brand ? "Edit brand" : "Add brand"}</DialogTitle>
          <DialogDescription>These details are supplied by you and are not independently verified.</DialogDescription></DialogHeader>
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          {field("name", "Brand name")}
          {field("industry", "Industry")}
          {field("website", "Official website", "e.g. https://brand.example")}
          <div>
            <Label>Official logo</Label>
            <div className="mt-1 flex items-center gap-3">
              {logoPreview ? <img src={logoPreview} alt="Logo preview" className="h-9 w-9 rounded-md object-cover" /> : <BrandTile name={f.name || "?"} color={f.logoColor} />}
              <input type="file" accept="image/*" aria-label="Upload logo" className="text-xs" onChange={(e) => { const file = e.target.files?.[0]; setLogoPreview(file ? URL.createObjectURL(file) : null); }} />
            </div>
            <div className="mt-2 flex gap-1.5">{COLORS.map((c) => (
              <button key={c} type="button" onClick={() => setF({ ...f, logoColor: c })} aria-label="Tile color" aria-pressed={f.logoColor === c}
                className="h-5 w-5 rounded-full ring-offset-2 aria-pressed:ring-2 aria-pressed:ring-ring" style={{ background: c }} />))}</div>
            <p className="mt-1 text-xs text-muted-foreground">Uploaded images are previewed only and not saved.</p>
          </div>
          {field("domains", "Approved domains", "One per line", true)}
          {field("handles", "Official social handles", "One per line, e.g. X: @brand", true)}
          {field("apps", "Official apps", "Name | package ID | publisher", true)}
          {field("partners", "Authorized partners / resellers", "One per line", true)}
          <div className="sm:col-span-2">{field("aliases", "Aliases & spelling variations", "One per line", true)}</div>
          <div className="sm:col-span-2"><Notice>Saved in this browser only. Nothing is sent to a server.</Notice></div>
          <DialogFooter className="sm:col-span-2"><Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button><Button type="submit">{brand ? "Save changes" : "Add brand"}</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
