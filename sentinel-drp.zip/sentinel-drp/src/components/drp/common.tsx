import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import type { CaseStatus, FindingCategory, Priority, ReviewStatus } from "@/lib/types";

export function PageHeader({ crumbs, title, description, actions }: {
  crumbs: { label: string; to?: string }[]; title: string; description: string; actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-end md:justify-between print:hidden">
      <div className="min-w-0">
        <nav aria-label="Breadcrumb" className="mb-2 flex flex-wrap items-center gap-1 text-xs text-muted-foreground">
          <Link to="/" className="hover:text-foreground">Home</Link>
          {crumbs.map((c) => (
            <span key={c.label} className="flex items-center gap-1">
              <ChevronRight className="h-3 w-3" aria-hidden />
              {c.to ? <Link to={c.to} className="hover:text-foreground">{c.label}</Link> : <span className="text-foreground">{c.label}</span>}
            </span>
          ))}
        </nav>
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{description}</p>
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

const tone = {
  danger: "bg-danger-soft text-danger border-danger/20",
  warning: "bg-warning-soft text-warning border-warning/25",
  success: "bg-success-soft text-success border-success/20",
  info: "bg-info-soft text-primary border-primary/20",
  neutral: "bg-muted text-muted-foreground border-border",
};
export type Tone = keyof typeof tone;

export function Pill({ t, children, className }: { t: Tone; children: ReactNode; className?: string }) {
  return <span className={cn("inline-flex items-center gap-1.5 whitespace-nowrap rounded-md border px-2 py-0.5 text-xs font-medium", tone[t], className)}>{children}</span>;
}

const dot = { danger: "bg-danger", warning: "bg-warning", success: "bg-success", info: "bg-primary", neutral: "bg-muted-foreground" };
function Dot({ t }: { t: Tone }) { return <span className={cn("h-1.5 w-1.5 rounded-full", dot[t])} aria-hidden />; }

export const PRIORITY_LABEL: Record<Priority, string> = { high: "High", medium: "Medium", low: "Low", none: "None" };
const PRIORITY_TONE: Record<Priority, Tone> = { high: "danger", medium: "warning", low: "info", none: "neutral" };
export function PriorityBadge({ p }: { p: Priority }) {
  return <Pill t={PRIORITY_TONE[p]}><Dot t={PRIORITY_TONE[p]} />{PRIORITY_LABEL[p]}</Pill>;
}

export const STATUS_LABEL: Record<ReviewStatus, string> = { new: "New", needs_review: "Needs review", authorized: "Authorized", dismissed: "Dismissed", in_case: "In case" };
const STATUS_TONE: Record<ReviewStatus, Tone> = { new: "info", needs_review: "warning", authorized: "success", dismissed: "neutral", in_case: "info" };
export function StatusBadge({ s }: { s: ReviewStatus }) { return <Pill t={STATUS_TONE[s]}>{STATUS_LABEL[s]}</Pill>; }

export const CATEGORY_LABEL: Record<FindingCategory, string> = { impersonation: "Suspected impersonation", suspected_scam: "Suspected scam", suspicious_app: "Suspicious app", none: "No finding" };
export function CategoryBadge({ c }: { c: FindingCategory }) { return <Pill t="neutral">{CATEGORY_LABEL[c]}</Pill>; }

export const CASE_STATUS_LABEL: Record<CaseStatus, string> = { new: "New", investigating: "Investigating", ready_for_review: "Ready for review", resolved: "Resolved", dismissed: "Dismissed" };
const CASE_TONE: Record<CaseStatus, Tone> = { new: "info", investigating: "warning", ready_for_review: "info", resolved: "success", dismissed: "neutral" };
export function CaseStatusBadge({ s }: { s: CaseStatus }) { return <Pill t={CASE_TONE[s]}>{CASE_STATUS_LABEL[s]}</Pill>; }

export function Panel({ title, subtitle, children, className, actions }: { title?: string | undefined; subtitle?: string | undefined; children: ReactNode; className?: string; actions?: ReactNode }) {
  return (
    <section className={cn("rounded-lg border bg-card p-5", className)}>
      {(title || actions) && (
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            {title && <h2 className="text-sm font-semibold">{title}</h2>}
            {subtitle && <p className="mt-0.5 text-xs text-muted-foreground">{subtitle}</p>}
          </div>
          {actions}
        </div>
      )}
      {children}
    </section>
  );
}

export function Notice({ children, t = "info" }: { children: ReactNode; t?: Tone }) {
  return <div className={cn("rounded-md border px-3 py-2 text-xs leading-relaxed", tone[t])} role="note">{children}</div>;
}

export function EmptyState({ title, text, action }: { title: string; text: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed px-6 py-12 text-center">
      <p className="text-sm font-medium">{title}</p>
      <p className="mt-1 max-w-sm text-xs text-muted-foreground">{text}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function List({ title, items, empty = "None recorded." }: { title: string; items: string[]; empty?: string }) {
  return (
    <div>
      <h3 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">{title}</h3>
      {items.length ? (
        <ul className="space-y-1 text-sm">{items.map((i) => <li key={i} className="flex gap-2"><span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-muted-foreground" />{i}</li>)}</ul>
      ) : <p className="text-sm text-muted-foreground">{empty}</p>}
    </div>
  );
}

export function BrandTile({ name, color, size = 36 }: { name: string; color: string; size?: number }) {
  const initials = name.split(/\s+/).map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  return (
    <span className="inline-flex shrink-0 items-center justify-center rounded-md font-semibold text-primary-foreground"
      style={{ background: color, width: size, height: size, fontSize: size * 0.38 }} aria-hidden>{initials}</span>
  );
}

export function SampleLabel() { return <Pill t="neutral">Sample data</Pill>; }

export function SortHeader({ label, active, dir, onClick }: { label: string; active: boolean; dir: "asc" | "desc"; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="inline-flex items-center gap-1 font-medium hover:text-foreground" aria-sort={active ? (dir === "asc" ? "ascending" : "descending") : "none"}>
      {label}<span className="text-[10px]">{active ? (dir === "asc" ? "▲" : "▼") : "↕"}</span>
    </button>
  );
}
