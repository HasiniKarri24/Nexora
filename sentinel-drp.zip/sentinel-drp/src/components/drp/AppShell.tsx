import { useMemo, useState, type ReactNode } from "react";
import { Link, useNavigate, useRouter } from "@tanstack/react-router";
import {
  LayoutDashboard, BookMarked, Users, Smartphone, ScanSearch, Network, FolderKanban, BarChart3, Database, Settings as SettingsIcon,
  Bell, Search, Menu, PanelLeftClose, PanelLeftOpen, ShieldCheck, UserCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useStore, type DateRange } from "@/lib/store";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { fmtDateTime } from "@/lib/store";

export const NAV = [
  { to: "/", label: "Overview", icon: LayoutDashboard },
  { to: "/brands", label: "Brand Registry", icon: BookMarked },
  { to: "/social", label: "Social Monitoring", icon: Users },
  { to: "/apps", label: "App Monitoring", icon: Smartphone },
  { to: "/analyze", label: "Quick Analyze", icon: ScanSearch },
  { to: "/threats", label: "Connected Threats", icon: Network },
  { to: "/cases", label: "Cases & Evidence", icon: FolderKanban },
  { to: "/reports", label: "Reports", icon: BarChart3 },
  { to: "/sources", label: "Data Sources", icon: Database },
  { to: "/settings", label: "Settings", icon: SettingsIcon },
] as const;

function NavList({ collapsed, onNavigate }: { collapsed: boolean; onNavigate?: () => void }) {
  return (
    <nav className="flex flex-col gap-0.5 px-2" aria-label="Main">
      {NAV.map(({ to, label, icon: Icon }) => (
        <Link key={to} to={to} onClick={onNavigate} activeOptions={{ exact: to === "/" }}
          className="flex items-center gap-3 rounded-md px-3 py-2 text-sm text-sidebar-foreground transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:outline-2 focus-visible:outline-sidebar-ring"
          activeProps={{ className: "bg-sidebar-accent text-sidebar-accent-foreground font-medium" }}
          title={collapsed ? label : undefined}>
          <Icon className="h-4 w-4 shrink-0" aria-hidden />
          <span className={cn(collapsed && "sr-only")}>{label}</span>
        </Link>
      ))}
    </nav>
  );
}

function Logo({ collapsed }: { collapsed: boolean }) {
  return (
    <div className="flex h-14 items-center gap-2 px-4 text-sidebar-accent-foreground">
      <ShieldCheck className="h-5 w-5 shrink-0 text-sidebar-primary" aria-hidden />
      {!collapsed && <span className="text-sm font-semibold tracking-tight">Sentinel DRP</span>}
    </div>
  );
}

function GlobalSearch() {
  const { state, allFindings } = useStore();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const router = useRouter();
  const results = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (t.length < 2) return [];
    const f = allFindings.filter((x) => x.name.toLowerCase().includes(t)).map((x) => ({ id: x.id, label: x.name, sub: x.source, to: x.kind === "social" ? `/social/${x.id}` : `/apps/${x.id}` }));
    const c = state.cases.filter((x) => (x.title + x.id).toLowerCase().includes(t)).map((x) => ({ id: x.id, label: x.title, sub: x.id, to: `/cases/${x.id}` }));
    return [...c, ...f].slice(0, 8);
  }, [q, allFindings, state.cases]);
  return (
    <Popover open={open && q.length >= 2} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <div className="relative w-full max-w-xs">
          <Search className="pointer-events-none absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" aria-hidden />
          <input value={q} onChange={(e) => { setQ(e.target.value); setOpen(true); }} placeholder="Search findings and cases"
            aria-label="Search findings and cases"
            className="h-9 w-full rounded-md border bg-background pl-8 pr-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" />
        </div>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-80 p-1" onOpenAutoFocus={(e) => e.preventDefault()}>
        {results.length === 0 ? <p className="px-3 py-4 text-sm text-muted-foreground">No matching findings or cases.</p> :
          results.map((r) => (
            <button key={r.id} type="button" onClick={() => { setOpen(false); setQ(""); router.history.push(r.to); }}
              className="flex w-full flex-col items-start rounded px-3 py-2 text-left hover:bg-muted">
              <span className="text-sm">{r.label}</span><span className="text-xs text-muted-foreground">{r.sub}</span>
            </button>
          ))}
      </PopoverContent>
    </Popover>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { state, brandId, setBrandId, range, setRange, markNotificationsRead } = useStore();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();
  const router = useRouter();
  const unread = state.notifications.filter((n) => !n.read).length;

  return (
    <div className="flex min-h-screen">
      <aside className={cn("sticky top-0 hidden h-screen shrink-0 flex-col bg-sidebar transition-[width] md:flex print:hidden", collapsed ? "w-16" : "w-60")}>
        <Logo collapsed={collapsed} />
        <div className="flex-1 overflow-y-auto py-2"><NavList collapsed={collapsed} /></div>
        <button type="button" onClick={() => setCollapsed(!collapsed)} aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          className="m-2 flex items-center gap-2 rounded-md px-3 py-2 text-xs text-sidebar-foreground hover:bg-sidebar-accent">
          {collapsed ? <PanelLeftOpen className="h-4 w-4" /> : <><PanelLeftClose className="h-4 w-4" />Collapse</>}
        </button>
      </aside>
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="w-64 border-0 bg-sidebar p-0">
          <SheetTitle className="sr-only">Navigation</SheetTitle>
          <Logo collapsed={false} />
          <NavList collapsed={false} onNavigate={() => setMobileOpen(false)} />
        </SheetContent>
      </Sheet>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex flex-wrap items-center gap-2 border-b bg-card px-4 py-2.5 md:px-6 print:hidden">
          <button type="button" className="rounded-md p-2 hover:bg-muted md:hidden" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu className="h-5 w-5" /></button>
          <Select value={brandId} onValueChange={setBrandId}>
            <SelectTrigger className="h-9 w-44" aria-label="Brand"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All brands</SelectItem>
              {state.brands.map((b) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={range} onValueChange={(v) => setRange(v as DateRange)}>
            <SelectTrigger className="hidden h-9 w-36 sm:flex" aria-label="Date range"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem><SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem><SelectItem value="all">All time</SelectItem>
            </SelectContent>
          </Select>
          <div className="order-last w-full sm:order-none sm:w-auto sm:flex-1"><GlobalSearch /></div>
          <span className="ml-auto inline-flex items-center rounded-md border border-warning/30 bg-warning-soft px-2 py-1 text-xs font-semibold text-warning" title="All data is fictional demo data">Demo mode</span>
          <Popover onOpenChange={(o) => { if (!o) markNotificationsRead(); }}>
            <PopoverTrigger asChild>
              <button type="button" className="relative rounded-md p-2 hover:bg-muted" aria-label={`Notifications, ${unread} unread`}>
                <Bell className="h-5 w-5" />
                {unread > 0 && <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger px-1 text-[10px] font-semibold text-primary-foreground">{unread}</span>}
              </button>
            </PopoverTrigger>
            <PopoverContent align="end" className="w-80 p-0">
              <p className="border-b px-4 py-2.5 text-sm font-semibold">Notifications <span className="font-normal text-muted-foreground">· in-app, demo</span></p>
              {state.notifications.map((n) => (
                <button key={n.id} type="button" onClick={() => n.link && router.history.push(n.link)} className="flex w-full flex-col items-start gap-0.5 border-b px-4 py-2.5 text-left last:border-0 hover:bg-muted">
                  <span className={cn("text-sm", !n.read && "font-medium")}>{n.text}</span>
                  <span className="text-xs text-muted-foreground">{fmtDateTime(n.at)}</span>
                </button>
              ))}
            </PopoverContent>
          </Popover>
          <DropdownMenu>
            <DropdownMenuTrigger className="rounded-md p-1.5 hover:bg-muted" aria-label="User menu"><UserCircle className="h-6 w-6" /></DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>{state.settings.reviewerName}<p className="text-xs font-normal text-muted-foreground">Demo reviewer · no sign-in</p></DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={() => navigate({ to: "/settings" })}>Settings</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>
        <main className="mx-auto w-full max-w-[1400px] flex-1 px-4 py-6 md:px-8 md:py-8 print:p-0">{children}</main>
      </div>
    </div>
  );
}
