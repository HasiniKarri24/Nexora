import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import type { Finding } from "@/lib/types";
import { fmtDate } from "@/lib/store";
import { CategoryBadge, EmptyState, PriorityBadge, SortHeader, StatusBadge } from "./common";

const PR = { high: 3, medium: 2, low: 1, none: 0 };
type Key = "name" | "source" | "priority" | "firstDetected";

export function FindingsTable({ findings }: { findings: Finding[] }) {
  const [sort, setSort] = useState<{ k: Key; d: "asc" | "desc" }>({ k: "firstDetected", d: "desc" });
  const rows = useMemo(() => [...findings].sort((a, b) => {
    const va = sort.k === "priority" ? PR[a.priority] : a[sort.k];
    const vb = sort.k === "priority" ? PR[b.priority] : b[sort.k];
    const r = va < vb ? -1 : va > vb ? 1 : 0;
    return sort.d === "asc" ? r : -r;
  }), [findings, sort]);
  const h = (k: Key, label: string) => <SortHeader label={label} active={sort.k === k} dir={sort.d} onClick={() => setSort((s) => ({ k, d: s.k === k && s.d === "desc" ? "asc" : "desc" }))} />;
  if (!rows.length) return <EmptyState title="No findings" text="No findings match the current brand and date filters." />;
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[760px] text-sm">
        <thead className="text-left text-xs text-muted-foreground">
          <tr className="border-b">
            <th className="py-2 pr-3">{h("name", "Account or app")}</th><th className="py-2 pr-3">{h("source", "Source")}</th>
            <th className="py-2 pr-3">Category</th><th className="py-2 pr-3">{h("priority", "Priority")}</th>
            <th className="py-2 pr-3">Review status</th><th className="py-2 pr-3">{h("firstDetected", "First detected")}</th><th className="py-2"><span className="sr-only">Action</span></th>
          </tr>
        </thead>
        <tbody>
          {rows.map((f) => (
            <tr key={f.id} className="border-b last:border-0 hover:bg-muted/50">
              <td className="py-2.5 pr-3 font-medium">{f.name}</td>
              <td className="py-2.5 pr-3 text-muted-foreground">{f.source}</td>
              <td className="py-2.5 pr-3"><CategoryBadge c={f.category} /></td>
              <td className="py-2.5 pr-3"><PriorityBadge p={f.priority} /></td>
              <td className="py-2.5 pr-3"><StatusBadge s={f.status} /></td>
              <td className="py-2.5 pr-3 text-muted-foreground">{fmtDate(f.firstDetected)}</td>
              <td className="py-2.5 text-right">
                {f.kind === "social"
                  ? <Link to="/social/$id" params={{ id: f.id }} className="text-sm font-medium text-primary hover:underline">View evidence</Link>
                  : <Link to="/apps/$id" params={{ id: f.id }} className="text-sm font-medium text-primary hover:underline">View evidence</Link>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
