import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { Finding } from "@/lib/types";

const axis = { fontSize: 11, fill: "var(--color-muted-foreground)" };
const tip = { contentStyle: { background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 6, fontSize: 12 } };

export function weeklySeries(findings: Finding[]) {
  const map = new Map<string, number>();
  for (const f of findings) {
    const d = new Date(f.firstDetected);
    d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7));
    const k = d.toISOString().slice(0, 10);
    map.set(k, (map.get(k) ?? 0) + 1);
  }
  return [...map.entries()].sort().map(([k, v]) => ({ week: new Date(k).toLocaleDateString("en-GB", { day: "2-digit", month: "short" }), findings: v }));
}

export function TimeChart({ findings }: { findings: Finding[] }) {
  const data = weeklySeries(findings);
  return (
    <div className="h-56" role="img" aria-label="Findings per week line chart">
      <ResponsiveContainer>
        <LineChart data={data} margin={{ left: -20, right: 8, top: 8 }}>
          <CartesianGrid stroke="var(--color-border)" vertical={false} />
          <XAxis dataKey="week" tick={axis} tickLine={false} axisLine={false} />
          <YAxis allowDecimals={false} tick={axis} tickLine={false} axisLine={false} />
          <Tooltip {...tip} />
          <Line type="monotone" dataKey="findings" stroke="var(--color-chart-1)" strokeWidth={2} dot={{ r: 3 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function HBars({ data, colors }: { data: { name: string; value: number }[]; colors?: string[] }) {
  return (
    <div style={{ height: Math.max(120, data.length * 40) }} role="img" aria-label={data.map((d) => `${d.name}: ${d.value}`).join(", ")}>
      <ResponsiveContainer>
        <BarChart data={data} layout="vertical" margin={{ left: 8, right: 16 }}>
          <XAxis type="number" allowDecimals={false} tick={axis} tickLine={false} axisLine={false} />
          <YAxis type="category" dataKey="name" width={150} tick={axis} tickLine={false} axisLine={false} />
          <Tooltip {...tip} cursor={{ fill: "var(--color-muted)" }} />
          <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={18}>
            {data.map((d, i) => <Cell key={d.name} fill={colors?.[i] ?? "var(--color-chart-1)"} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function countBy<T>(items: T[], key: (t: T) => string, order?: string[]) {
  const m = new Map<string, number>();
  for (const k of order ?? []) m.set(k, 0);
  for (const i of items) m.set(key(i), (m.get(key(i)) ?? 0) + 1);
  return [...m.entries()].map(([name, value]) => ({ name, value }));
}
