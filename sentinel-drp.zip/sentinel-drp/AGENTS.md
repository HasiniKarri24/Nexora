<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture
- All demo data lives in src/lib/demo-data.ts and all reads/mutations go through src/lib/store.tsx (localStorage-persisted context) so a real backend can replace the service layer later.
- Findings are derived from SocialProfile/AppListing records (category != "none"), so every chart and count stays consistent with one dataset.
