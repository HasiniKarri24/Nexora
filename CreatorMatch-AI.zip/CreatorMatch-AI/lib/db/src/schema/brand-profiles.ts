import {
  index,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { usersTable } from "./auth";

export const brandProfilesTable = pgTable(
  "brand_profiles",
  {
    id: serial("id").primaryKey(),
    userId: varchar("user_id")
      .notNull()
      .unique()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    companyName: varchar("company_name", { length: 180 }).notNull(),
    industry: varchar("industry", { length: 120 }).notNull().default(""),
    description: text("description").notNull().default(""),
    website: text("website").notNull().default(""),
    logoUrl: text("logo_url"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [index("brand_profiles_user_id_idx").on(table.userId)],
);

export type BrandProfile = typeof brandProfilesTable.$inferSelect;
export type InsertBrandProfile = typeof brandProfilesTable.$inferInsert;
