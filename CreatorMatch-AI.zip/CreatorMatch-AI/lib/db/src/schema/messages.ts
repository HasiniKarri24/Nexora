import {
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { collaborationRequestsTable } from "./collaboration-requests";
import { usersTable } from "./auth";

export const messagesTable = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    requestId: integer("request_id")
      .notNull()
      .references(() => collaborationRequestsTable.id, { onDelete: "cascade" }),
    senderId: varchar("sender_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    senderName: varchar("sender_name", { length: 180 }).notNull(),
    recipientId: varchar("recipient_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    content: text("content").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("messages_request_id_idx").on(table.requestId),
    index("messages_recipient_id_idx").on(table.recipientId),
  ],
);

export type Message = typeof messagesTable.$inferSelect;
