import { sql } from "drizzle-orm";
import {
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { usersTable } from "./auth";

export const creatorProfilesTable = pgTable(
  "creator_profiles",
  {
    id: serial("id").primaryKey(),
    userId: varchar("user_id")
      .notNull()
      .unique()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 160 }).notNull(),
    title: varchar("title", { length: 180 }).notNull(),
    bio: text("bio").notNull().default(""),
    avatarUrl: text("avatar_url"),
    skills: text("skills")
      .array()
      .notNull()
      .default(sql`'{}'::text[]`),
    tools: text("tools")
      .array()
      .notNull()
      .default(sql`'{}'::text[]`),
    categories: text("categories")
      .array()
      .notNull()
      .default(sql`'{}'::text[]`),
    yearsExperience: integer("years_experience").notNull().default(0),
    startingPrice: integer("starting_price").notNull().default(0),
    availability: varchar("availability", { length: 40 })
      .notNull()
      .default("available"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [index("creator_profiles_user_id_idx").on(table.userId)],
);

export type CreatorProfile = typeof creatorProfilesTable.$inferSelect;
export type InsertCreatorProfile = typeof creatorProfilesTable.$inferInsert;
