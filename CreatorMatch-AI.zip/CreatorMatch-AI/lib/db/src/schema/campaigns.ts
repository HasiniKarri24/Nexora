import { sql } from "drizzle-orm";
import {
  date,
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { brandProfilesTable } from "./brand-profiles";

export const campaignsTable = pgTable(
  "campaigns",
  {
    id: serial("id").primaryKey(),
    brandId: integer("brand_id")
      .notNull()
      .references(() => brandProfilesTable.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 200 }).notNull(),
    description: text("description").notNull().default(""),
    contentType: varchar("content_type", { length: 120 }).notNull(),
    skills: text("skills")
      .array()
      .notNull()
      .default(sql`'{}'::text[]`),
    tools: text("tools")
      .array()
      .notNull()
      .default(sql`'{}'::text[]`),
    budget: integer("budget").notNull().default(0),
    deadline: date("deadline", { mode: "string" }).notNull(),
    audience: text("audience").notNull().default(""),
    deliverables: text("deliverables")
      .array()
      .notNull()
      .default(sql`'{}'::text[]`),
    status: varchar("status", { length: 24 }).notNull().default("open"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    index("campaigns_brand_id_idx").on(table.brandId),
    index("campaigns_status_idx").on(table.status),
  ],
);

export type Campaign = typeof campaignsTable.$inferSelect;
export type InsertCampaign = typeof campaignsTable.$inferInsert;
