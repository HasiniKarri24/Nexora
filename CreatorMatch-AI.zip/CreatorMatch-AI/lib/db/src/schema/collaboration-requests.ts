import {
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { brandProfilesTable } from "./brand-profiles";
import { campaignsTable } from "./campaigns";
import { creatorProfilesTable } from "./creator-profiles";

export const collaborationRequestsTable = pgTable(
  "collaboration_requests",
  {
    id: serial("id").primaryKey(),
    campaignId: integer("campaign_id")
      .notNull()
      .references(() => campaignsTable.id, { onDelete: "cascade" }),
    creatorId: integer("creator_id")
      .notNull()
      .references(() => creatorProfilesTable.id, { onDelete: "cascade" }),
    brandId: integer("brand_id")
      .notNull()
      .references(() => brandProfilesTable.id, { onDelete: "cascade" }),
    message: text("message").notNull(),
    status: varchar("status", { length: 24 }).notNull().default("pending"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    index("collaboration_requests_creator_id_idx").on(table.creatorId),
    index("collaboration_requests_brand_id_idx").on(table.brandId),
    index("collaboration_requests_campaign_id_idx").on(table.campaignId),
  ],
);

export type CollaborationRequest =
  typeof collaborationRequestsTable.$inferSelect;
