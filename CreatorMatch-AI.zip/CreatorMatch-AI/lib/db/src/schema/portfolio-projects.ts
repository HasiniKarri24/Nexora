import { sql } from "drizzle-orm";
import {
  index,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { usersTable } from "./auth";

export const portfolioProjectsTable = pgTable(
  "portfolio_projects",
  {
    id: serial("id").primaryKey(),
    userId: varchar("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 200 }).notNull(),
    description: text("description").notNull().default(""),
    tools: text("tools")
      .array()
      .notNull()
      .default(sql`'{}'::text[]`),
    category: varchar("category", { length: 120 }).notNull().default(""),
    tags: text("tags")
      .array()
      .notNull()
      .default(sql`'{}'::text[]`),
    skills: text("skills")
      .array()
      .notNull()
      .default(sql`'{}'::text[]`),
    imageUrl: text("image_url"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    index("portfolio_projects_user_id_idx").on(table.userId),
    index("portfolio_projects_category_idx").on(table.category),
  ],
);

export type PortfolioProject = typeof portfolioProjectsTable.$inferSelect;
export type InsertPortfolioProject = typeof portfolioProjectsTable.$inferInsert;
