import { sql } from "drizzle-orm";
import {
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { campaignsTable } from "./campaigns";
import { creatorProfilesTable } from "./creator-profiles";

export const matchesTable = pgTable(
  "creator_matches",
  {
    id: serial("id").primaryKey(),
    campaignId: integer("campaign_id")
      .notNull()
      .references(() => campaignsTable.id, { onDelete: "cascade" }),
    creatorId: integer("creator_id")
      .notNull()
      .references(() => creatorProfilesTable.id, { onDelete: "cascade" }),
    score: integer("score").notNull(),
    matchingSkills: text("matching_skills")
      .array()
      .notNull()
      .default(sql`'{}'::text[]`),
    matchingTools: text("matching_tools")
      .array()
      .notNull()
      .default(sql`'{}'::text[]`),
    matchingCategory: text("matching_category"),
    reason: text("reason").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("creator_matches_campaign_creator_idx").on(
      table.campaignId,
      table.creatorId,
    ),
    index("creator_matches_campaign_id_idx").on(table.campaignId),
  ],
);

export type CreatorMatch = typeof matchesTable.$inferSelect;
