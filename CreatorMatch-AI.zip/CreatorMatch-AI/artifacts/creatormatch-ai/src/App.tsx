import { useEffect, useMemo, useState, type ButtonHTMLAttributes, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  useCreateCampaign, useCreateCollaborationRequest, useCreatePortfolioProject,
  useDeletePortfolioProject, useFindCampaignMatches, useGetBrandProfile,
  useGetCampaign, useGetCreator, useGetCreatorProfile, useGetDashboardSummary,
  useListCampaigns, useListCollaborationRequests, useListCreators,
  useListMessages, useListPortfolioProjects, useListRecentMatches,
  useRequestUploadUrl, useSaveBrandProfile, useSaveCreatorProfile,
  useSendMessage, useUpdateCollaborationRequest,
  getGetBrandProfileQueryKey, getGetCampaignQueryKey, getGetCreatorProfileQueryKey,
  getGetDashboardSummaryQueryKey, getGetCreatorQueryKey,
  getListCampaignsQueryKey,
  getListCollaborationRequestsQueryKey,
  getListMessagesQueryKey, getListPortfolioProjectsQueryKey,
  getListRecentMatchesQueryKey,
  useUpdatePortfolioProject,
} from '@workspace/api-client-react';
import type { Campaign, CreatorProfile, CreatorMatch, CollaborationRequest } from '@workspace/api-client-react';
import { useAuth } from '@workspace/replit-auth-web';
import {
  ArrowDownRight, ArrowRight, ArrowUpRight, BriefcaseBusiness,
  CalendarDays, Check, ChevronLeft,
  Clock3, Compass, FileImage, Filter, HeartHandshake, Inbox, LayoutDashboard,
  LogOut, MessageCircle, MessageSquareText, Plus, Search, Send,
  Settings2, Sparkles, UserRound, Users, WandSparkles, X,
} from 'lucide-react';
import { Link, Route, Switch, useLocation } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';

const queryClient = new QueryClient();
const iconSize = 17;
const money = (value?: number | null) => value == null ? '—' : `$${Number(value).toLocaleString()}`;
const initials = (name?: string | null) => (name || 'CM').split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase();
const dateLabel = (value?: string) => value ? new Date(value).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : 'No deadline';
const listValue = (value: string) => value.split(',').map((v) => v.trim()).filter(Boolean);

function Avatar({ name, src, size }: { name?: string | null; src?: string | null; size?: string }) {
  return <div className="avatar" style={size ? { width: size, height: size } : undefined}>{src ? <img src={src.startsWith('/objects/') ? `/api/storage${src}` : src} alt="" /> : initials(name)}</div>;
}
function Button({ children, variant = 'primary', ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'quiet' | 'plain' | 'danger' }) {
  return <button className={`button button-${variant}`} {...props}>{children}</button>;
}
function PageTitle({ eyebrow, title, copy, action }: { eyebrow: string; title: string; copy?: string; action?: ReactNode }) {
  return <div className="page-heading fade-up"><div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1>{copy && <p className="subheading">{copy}</p>}</div>{action}</div>;
}
function LoadingGrid({ count = 3 }: { count?: number }) {
  return <div className="cards-grid">{Array.from({ length: count }, (_, i) => <div className="panel" key={i} style={{ padding: 18 }}><div className="skeleton" style={{ height: 45, width: '55%', marginBottom: 18 }} /><div className="skeleton" style={{ height: 14, width: '88%', marginBottom: 10 }} /><div className="skeleton" style={{ height: 14, width: '68%', marginBottom: 32 }} /><div className="skeleton" style={{ height: 34, width: '100%' }} /></div>)}</div>;
}
function ErrorState({ retry }: { retry: () => void }) {
  return <div className="error-box"><span>We couldn’t load this view. Your work is safe; try again.</span><Button variant="plain" onClick={retry}>Retry</Button></div>;
}
function EmptyState({ title, detail, action }: { title: string; detail: string; action?: ReactNode }) {
  return <div className="empty-state"><div className="empty-mark"><Sparkles size={19} /></div><h3>{title}</h3><p>{detail}</p>{action}</div>;
}
function ChipList({ values, tone = '' }: { values?: string[]; tone?: string }) {
  if (!values?.length) return null;
  return <div className="chip-row">{values.slice(0, 5).map((value, i) => <span className={`chip ${tone}`} key={`${value}-${i}`}>{value}</span>)}</div>;
}
function AiUnavailableNotice({ feature }: { feature: string }) {
  return <div className="panel panel-pad" role="status" style={{ marginBottom: 18, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap', background: 'linear-gradient(110deg,rgba(115,74,145,.14),rgba(255,255,255,.02))' }}>
    <div><span className="eyebrow">AI writing assistant</span><p className="field-hint" style={{ margin: '6px 0 0' }}>{feature} needs an authorized AI provider. You can complete this manually for now.</p></div>
    <Button type="button" variant="quiet" disabled title="AI provider not configured"><WandSparkles size={14} /> Not connected</Button>
  </div>;
}

function Landing() {
  const { isAuthenticated, login } = useAuth();
  return <div className="landing">
    <header className="topbar">
      <Link href="/" className="brand-mark"><span className="brand-symbol"><Sparkles size={17} /></span>CreatorMatch<span style={{ color: '#ff9865' }}>AI</span></Link>
      <nav className="top-links"><a href="#how-it-works">How it works</a><a href="#for-creators">For creators</a><a href="#for-brands">For brands</a></nav>
      <div className="top-actions">{isAuthenticated ? <Link href="/dashboard" className="button button-quiet">Open workspace <ArrowRight size={15} /></Link> : <><button className="button button-quiet" onClick={login}>Log in</button><button className="button button-primary" onClick={login}>Get started <ArrowRight size={15} /></button></>}</div>
    </header>
    <main>
      <section className="landing-hero">
        <div className="fade-up">
          <div className="hero-kicker"><span /> The better brief starts here</div>
          <h1 className="hero-title">Good work finds<br />its <em>people.</em></h1>
          <p className="hero-copy">A thoughtful place for independent creators and ambitious brands to find the right fit, build something together, and make work worth sharing.</p>
          <div className="hero-buttons"><button className="button button-primary" onClick={login}>Find your next match <ArrowRight size={15} /></button><a className="button button-quiet" href="#how-it-works">See how it works <ArrowDownRight size={15} /></a></div>
          <div className="hero-proof"><div className="avatar-stack"><Avatar name="Maya Chen" /><Avatar name="Alex Morgan" /><Avatar name="Nia Foster" /><Avatar name="Leo Park" /></div><span>A better kind of creative partnership.</span></div>
        </div>
        <div className="hero-stage" aria-label="Creator match preview">
          <div className="orbit" /><div className="orbital-glow" />
          <div className="match-preview">
          <div className="preview-label">Illustrative example / 01</div>
            <div className="preview-head"><div className="preview-profile"><Avatar name="Maya Chen" /><div><strong>Maya Chen</strong><span>Creative director · Brooklyn, NY</span></div></div><div className="preview-score">96<small>%</small></div></div>
            <div className="match-meter"><span /></div>
            <div className="preview-match-row"><span>Creative direction</span><b>Strong fit</b></div>
            <div className="preview-match-row"><span>Short-form video</span><b>Strong fit</b></div>
            <div className="preview-match-row"><span>Brand storytelling</span><b>Aligned</b></div>
            <div className="preview-match-row"><span>Typical project</span><b>$2.4k+</b></div>
          </div>
          <div className="floating-note"><strong>Made for the work</strong>Clear briefs. Better chemistry.</div>
        </div>
      </section>
      <section className="landing-section" id="how-it-works">
        <div className="landing-section-head"><span className="eyebrow">Less searching, more creating</span><h2>From first spark to finished work.</h2><p>CreatorMatch brings the messy middle of finding collaborators into one calm, focused workflow.</p></div>
        <div className="steps-grid">
          <article className="panel step-card"><div className="step-number">01 / SET THE SCENE</div><h3>Make your point of view visible.</h3><p>Creators show their best work and the skills behind it. Brands share the brief, budget, audience and ambition.</p></article>
          <article className="panel step-card"><div className="step-number">02 / FIND THE FIT</div><h3>Meet on the work.</h3><p>Skill, tools and category signals bring the most relevant collaborators into view.</p></article>
          <article className="panel step-card"><div className="step-number">03 / MAKE IT REAL</div><h3>Build the relationship.</h3><p>Send a thoughtful request, agree on the details and keep the collaboration moving in one place.</p></article>
        </div>
      </section>
      <section className="landing-section" id="for-creators">
        <div className="split-section">
          <div><span className="eyebrow">For independent creators</span><h2 style={{ font: '750 clamp(31px,4vw,48px)/1.08 var(--app-font-display)', letterSpacing: '-1.8px', marginBottom: 14 }}>Your work should open the right doors.</h2><p className="subheading">Build a portfolio that says more than a job title. Let your skills, tools and point of view travel ahead of you.</p><div style={{ marginTop: 23 }}><button className="button button-primary" onClick={login}>Create your profile <ArrowRight size={15} /></button></div></div>
          <div className="feature-visual"><div className="feature-bars"><div className="feature-bar"><span>Brand storytelling</span><span>Strong signal</span></div><div className="feature-bar"><span>Video production</span><span>Strong signal</span></div><div className="feature-bar"><span>Creative strategy</span><span>Well matched</span></div><div className="feature-bar"><span>Portfolio clarity</span><span>On point</span></div></div></div>
        </div>
      </section>
      <section className="landing-section" id="for-brands">
        <div className="split-section">
          <div className="feature-visual"><div className="match-preview" style={{ width: '76%', transform: 'rotate(-1deg)' }}><div className="preview-label">Your campaign brief</div><div style={{ margin: '16px 0 12px', font: '700 18px var(--app-font-display)' }}>Make everyday feel extraordinary</div><div className="preview-match-row"><span>Campaign matches</span><b>Ranked by fit</b></div><div className="preview-match-row"><span>Creative direction</span><b>On brief</b></div><div className="preview-match-row"><span>Budget alignment</span><b>In range</b></div></div></div>
          <div><span className="eyebrow">For brand teams</span><h2 style={{ font: '750 clamp(31px,4vw,48px)/1.08 var(--app-font-display)', letterSpacing: '-1.8px', marginBottom: 14 }}>Find people who get the brief.</h2><p className="subheading">Turn a clear campaign into a shortlist of creators whose experience and craft line up with what you need.</p><div style={{ marginTop: 23 }}><button className="button button-quiet" onClick={login}>Explore the workspace <ArrowRight size={15} /></button></div></div>
        </div>
      </section>
      <section className="landing-section" style={{ paddingTop: 20, paddingBottom: 90 }}>
        <div className="panel panel-pad" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 24, flexWrap: 'wrap', background: 'linear-gradient(115deg,rgba(94,61,122,.24),rgba(255,134,80,.09))' }}>
          <div><span className="eyebrow">The next good thing</span><h2 style={{ fontSize: 28 }}>Let the right people find each other.</h2><p className="subheading">Create a profile or bring your next campaign into focus.</p></div><button className="button button-primary" onClick={login}>Get started <ArrowRight size={15} /></button>
        </div>
      </section>
    </main>
    <footer className="landing-footer"><span className="brand-mark"><span className="brand-symbol"><Sparkles size={14} /></span>CreatorMatch AI</span><span>Good work, together.</span><span>© 2025 CreatorMatch</span></footer>
  </div>;
}

const baseNavigation = [
  { href: '/dashboard', label: 'Overview', icon: LayoutDashboard },
  { href: '/creator/profile', label: 'My profile', icon: UserRound },
  { href: '/creator/portfolio', label: 'Portfolio', icon: FileImage, creator: true },
  { href: '/campaigns', label: 'Campaigns', icon: BriefcaseBusiness },
  { href: '/creators', label: 'Discover creators', icon: Compass, brand: true },
  { href: '/matches', label: 'Smart matches', icon: Sparkles, brand: true },
  { href: '/requests', label: 'Requests', icon: Inbox },
  { href: '/messages', label: 'Messages', icon: MessageCircle },
];

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const summaryQuery = useGetDashboardSummary();
  const creatorQuery = useGetCreatorProfile({ query: { enabled: !!user, queryKey: getGetCreatorProfileQueryKey() } });
  const brandQuery = useGetBrandProfile({ query: { enabled: !!user, queryKey: getGetBrandProfileQueryKey() } });
  const role = summaryQuery.data?.role || (creatorQuery.data?.profile ? 'creator' : brandQuery.data?.profile ? 'brand' : 'unset');
  const nav = baseNavigation.filter((item) => (!item.creator || role === 'creator' || role === 'unset') && (!item.brand || role === 'brand'));
  const name = user?.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : user?.email || 'Your account';
  return <div className="app-shell">
    <header className="topbar"><Link href="/dashboard" className="brand-mark"><span className="brand-symbol"><Sparkles size={17} /></span>CreatorMatch<span style={{ color: '#ff9865' }}>AI</span></Link><nav className="top-links"><Link href="/campaigns">Campaigns</Link><Link href="/creators">Creators</Link><Link href="/matches">Smart matches</Link></nav><div className="top-actions"><Link href="/creator/profile" className="button button-quiet"><Settings2 size={14} /> Profile</Link><button className="button button-plain" aria-label="Log out" onClick={logout}><LogOut size={15} /> <span>Log out</span></button></div></header>
    <div className="app-frame">
      <aside className="sidebar"><div className="workspace-label">Workspace</div><nav className="nav-group">{nav.map(({ href, label, icon: Icon }) => <Link href={href} className={`nav-item ${location === href || (href !== '/dashboard' && location.startsWith(`${href}/`)) ? 'active' : ''}`} key={href}><span className="nav-icon"><Icon size={iconSize} /></span>{label}</Link>)}</nav><div className="sidebar-bottom"><div className="account-row"><Avatar name={name} src={user?.profileImageUrl} /><div style={{ minWidth: 0 }}><div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 145 }}>{name}</div><div style={{ color: '#777582', fontSize: 10, marginTop: 4 }}>{role === 'unset' ? 'Complete your profile' : `${role} workspace`}</div></div></div></div></aside>
      <main className="main-area">{children}</main>
    </div>
    <nav className="mobile-nav">{nav.slice(0, 5).map(({ href, label, icon: Icon }) => <Link href={href} className={location === href ? 'active' : ''} key={href}><Icon size={18} /><span>{label}</span></Link>)}</nav>
  </div>;
}

function Dashboard() {
  const summary = useGetDashboardSummary();
  const matches = useListRecentMatches();
  const requests = useListCollaborationRequests();
  const { data, isLoading, isError, refetch } = summary;
  const role = data?.role || 'unset';
  const creator = role === 'creator';
  const visibleRequests = requests.data || [];
  const stats: { label: string; value: number; note: string; Icon: typeof BriefcaseBusiness }[] = [
    { label: 'Open campaigns', value: data?.campaignsOpen ?? 0, note: 'Across the marketplace', Icon: BriefcaseBusiness },
    { label: 'Creators', value: data?.creatorCount ?? 0, note: 'Ready to collaborate', Icon: Users },
    { label: 'Pending requests', value: data?.pendingRequests ?? 0, note: 'Waiting for a reply', Icon: HeartHandshake },
    { label: 'Inbox messages', value: data?.inboxMessages ?? 0, note: 'Keep the conversation going', Icon: MessageSquareText },
  ];
  if (isLoading) return <><PageTitle eyebrow="Workspace / overview" title="Your workspace" copy="A clear view of what’s moving." /><div className="stats-grid">{[1, 2, 3, 4].map((x) => <div className="panel stat-card" key={x}><div className="skeleton" style={{ height: 13, width: '50%' }} /><div className="skeleton" style={{ height: 30, width: '35%', marginTop: 19 }} /></div>)}</div><LoadingGrid count={2} /></>;
  if (isError) return <><PageTitle eyebrow="Workspace / overview" title="Your workspace" /><ErrorState retry={() => refetch()} /></>;
  return <>
    <PageTitle eyebrow={`Workspace / ${role}`} title={creator ? 'Your creative practice, in motion.' : role === 'brand' ? 'Make your next campaign count.' : 'A good place to begin.'} copy={creator ? 'Your next collaboration starts with a clear point of view.' : 'Your campaign pipeline and creative partnerships, at a glance.'} action={<Link href={creator ? '/creator/profile' : '/campaigns/new'} className="button button-primary">{creator ? 'Edit profile' : 'Create a campaign'} <ArrowRight size={15} /></Link>} />
    <div className="stats-grid">
      {stats.map(({ label, value, note, Icon }) => <div className="panel stat-card" key={label}><div style={{ display: 'flex', justifyContent: 'space-between' }}><span className="stat-label">{label}</span><span style={{ color: '#a88acb' }}><Icon size={16} /></span></div><div className="stat-value">{value}</div><div className="stat-foot">{note}</div></div>)}
    </div>
    <div className="grid dashboard-grid">
      <section className="panel panel-pad"><div className="section-head"><div><h2>Recent activity</h2><p>The latest movement across your collaborations.</p></div><Clock3 size={17} color="#858391" /></div>
        {data?.recentActivity?.length ? <div className="activity-list">{data.recentActivity.map((item) => <div className="activity-row" key={item.id}><span className="activity-dot" /><div><div className="activity-title">{item.title}</div><div className="activity-detail">{item.detail}</div></div><span className="activity-time">{dateLabel(item.createdAt)}</span></div>)}</div> : <EmptyState title="A fresh start" detail="Campaign activity and collaboration updates will appear here." />}</section>
      <section className="panel panel-pad"><div className="section-head"><div><h2>{creator ? 'Recent opportunities' : 'Quick actions'}</h2><p>{creator ? 'Campaigns and requests worth a look.' : 'Keep your momentum going.'}</p></div><ArrowUpRight size={17} color="#858391" /></div>
        {!creator && <div className="quick-links"><Link href="/campaigns/new" className="quick-link"><span>Publish a campaign</span><ArrowRight size={14} /></Link><Link href="/creators" className="quick-link"><span>Discover creators</span><ArrowRight size={14} /></Link><Link href="/matches" className="quick-link"><span>Review smart matches</span><ArrowRight size={14} /></Link><Link href="/requests" className="quick-link"><span>Manage requests</span><ArrowRight size={14} /></Link></div>}
        {creator && (visibleRequests.length ? visibleRequests.slice(0, 3).map((request) => <div className="activity-row" key={request.id}><span className="activity-dot" /><div><div className="activity-title">{request.campaignTitle}</div><div className="activity-detail">{request.brandName} sent a collaboration request</div></div><Link href="/requests" style={{ color: '#ff9865', fontSize: 11 }}>View</Link></div>) : <EmptyState title="Make your work discoverable" detail="A complete creator profile helps brands find the right fit." action={<Link className="button button-primary" href="/creator/profile">Complete profile</Link>} />)}
      </section>
      {role === 'brand' && <section className="panel panel-pad" style={{ gridColumn: '1 / -1' }}><div className="section-head"><div><h2>Creator matches</h2><p>Compatibility signals from your recent campaigns.</p></div><Link href="/matches" className="button button-quiet">See matches <ArrowRight size={14} /></Link></div>{matches.isLoading ? <LoadingGrid count={2} /> : matches.data?.length ? <div className="cards-grid">{matches.data.slice(0, 3).map((match) => <CreatorCard match={match} key={match.id} />)}</div> : <EmptyState title="No matches yet" detail="Publish a campaign to surface ranked creator matches." action={<Link className="button button-primary" href="/campaigns/new">Create a campaign</Link>} />}</section>}
    </div>
  </>;
}

function CreatorCard({ profile, match }: { profile?: CreatorProfile; match?: CreatorMatch }) {
  const id = match?.creatorId ?? profile?.id;
  const name = match?.creatorName ?? profile?.name ?? 'Creator';
  const title = match?.title ?? profile?.title ?? '';
  const src = match?.avatarUrl ?? profile?.avatarUrl;
  const price = match?.startingPrice ?? profile?.startingPrice;
  const skills = match?.matchingSkills ?? profile?.skills;
  const score = match?.score;
  return <article className="panel creator-card" data-testid={`card-creator-${id}`}><div className="creator-top"><Avatar name={name} src={src} /><div style={{ minWidth: 0 }}><div className="creator-name">{name}</div><div className="creator-title">{title}</div></div>{score != null && <div className="match-badge" title="Rules-based compatibility score"><span className="score-ring">{score}</span>{score}%</div>}</div><p>{match?.reason || profile?.bio || 'Independent creative building thoughtful work for ambitious teams.'}</p><ChipList values={skills} tone="purple" /><div className="card-bottom"><span className="price">From {money(price)}</span>{id ? <Link href={`/creators/${id}`} className="button button-quiet" style={{ padding: '8px 11px' }}>View profile <ArrowRight size={13} /></Link> : null}</div></article>;
}

function DiscoverCreators() {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('');
  const params = useMemo(() => ({ ...(query ? { q: query } : {}), ...(category ? { category } : {}) }), [query, category]);
  const result = useListCreators(params);
  const creators = result.data || [];
  const categories = useMemo(() => [...new Set(creators.flatMap((profile) => profile.categories || []))], [creators]);
  return <>
    <PageTitle eyebrow="Marketplace / creators" title="Find your people." copy="Search independent creators by name, discipline and point of view." />
    <div className="toolbar"><div className="search-wrap"><Search size={16} /><input className="search-input" type="search" placeholder="Search creators, skills or tools" value={query} onChange={(event) => setQuery(event.target.value)} aria-label="Search creators" data-testid="input-search-creators" /></div><div className="field" style={{ minWidth: 180 }}><select value={category} onChange={(event) => setCategory(event.target.value)} aria-label="Filter category" data-testid="select-category"><option value="">All categories</option>{categories.map((item) => <option value={item} key={item}>{item}</option>)}</select></div><span className="chip"><Filter size={11} style={{ verticalAlign: 'middle', marginRight: 4 }} />{creators.length} creators</span></div>
    {result.isLoading ? <LoadingGrid /> : result.isError ? <ErrorState retry={() => result.refetch()} /> : creators.length ? <div className="cards-grid">{creators.map((profile) => <CreatorCard profile={profile} key={profile.id} />)}</div> : <EmptyState title="No creators in this search" detail={query || category ? 'Try another search or clear the category filter.' : 'Creator profiles will appear here as people join the marketplace.'} action={(query || category) ? <Button variant="quiet" onClick={() => { setQuery(''); setCategory(''); }}>Clear filters</Button> : undefined} />}
  </>;
}

function CreatorDetailPage({ id }: { id: string }) {
  const creatorId = Number(id);
  const creator = useGetCreator(creatorId, { query: { enabled: Number.isFinite(creatorId), queryKey: getGetCreatorQueryKey(creatorId) } });
  const campaigns = useListCampaigns();
  const brandProfile = useGetBrandProfile();
  const request = useCreateCollaborationRequest();
  const client = useQueryClient();
  const ownedCampaigns = (campaigns.data || []).filter((item) => item.status === 'open' && item.brandId === brandProfile.data?.profile?.id);
  const [campaignId, setCampaignId] = useState('');
  const [message, setMessage] = useState('');
  const detail = creator.data;
  const send = (event: FormEvent) => {
    event.preventDefault();
    if (!campaignId || !message.trim()) return;
    request.mutate({ data: { campaignId: Number(campaignId), creatorId, message: message.trim() } }, { onSuccess: () => { client.invalidateQueries({ queryKey: getListCollaborationRequestsQueryKey() }); setMessage(''); } });
  };
  if (creator.isLoading || brandProfile.isLoading) return <><PageTitle eyebrow="Creator / profile" title="Loading profile" /><LoadingGrid count={2} /></>;
  if (creator.isError || !detail) return <><PageTitle eyebrow="Creator / profile" title="Profile unavailable" /><ErrorState retry={() => creator.refetch()} /></>;
  const profile = detail.profile;
  return <>
    <PageTitle eyebrow="Marketplace / creator profile" title={profile.name} copy={profile.title} action={<Link href="/creators" className="button button-quiet"><ChevronLeft size={15} /> All creators</Link>} />
    <div className="panel" style={{ overflow: 'hidden', marginBottom: 18 }}><div className="profile-cover" /><div className="profile-identity"><Avatar name={profile.name} src={profile.avatarUrl} /><div><h2>{profile.name}</h2><p className="subheading">{profile.title}</p></div></div><div className="panel-pad" style={{ paddingTop: 0 }}><p className="profile-bio">{profile.bio}</p><ChipList values={[...profile.skills, ...profile.tools, ...profile.categories].slice(0, 12)} tone="purple" /></div></div>
    <div className="creator-detail-layout"><section className="panel panel-pad"><div className="section-head"><div><h2>Selected work</h2><p>A closer look at the practice.</p></div></div>{detail.portfolio.length ? <div className="project-grid">{detail.portfolio.map((project) => <PortfolioCard key={project.id} project={project} />)}</div> : <EmptyState title="Portfolio in progress" detail="This creator is still adding selected projects." />}</section>
      <aside className="panel panel-pad"><div className="eyebrow">Collaboration details</div><div className="activity-row"><div><div className="activity-title">Experience</div><div className="activity-detail">{profile.yearsExperience} years</div></div></div><div className="activity-row"><div><div className="activity-title">Starting rate</div><div className="activity-detail">{money(profile.startingPrice)}</div></div></div><div className="activity-row"><div><div className="activity-title">Availability</div><div className="activity-detail">{profile.availability}</div></div></div>{ownedCampaigns.length ? <form onSubmit={send} style={{ marginTop: 18 }}><div className="field"><label htmlFor="campaign-select">Your campaign</label><select id="campaign-select" value={campaignId} onChange={(event) => setCampaignId(event.target.value)} required><option value="">Choose a campaign</option>{ownedCampaigns.map((item) => <option value={item.id} key={item.id}>{item.title}</option>)}</select></div><div className="field" style={{ marginTop: 12 }}><label htmlFor="request-message">A note to the creator</label><textarea id="request-message" value={message} onChange={(event) => setMessage(event.target.value)} placeholder="Tell them what caught your eye and why you think it could fit." required /></div><Button type="submit" disabled={request.isPending || !campaignId} style={{ width: '100%', marginTop: 14 }}>{request.isPending ? 'Sending…' : 'Send collaboration request'} <ArrowRight size={14} /></Button>{request.isError && <div className="field-hint" style={{ color: '#ff9a9d', marginTop: 8 }}>Couldn’t send the request. Please try again.</div>}</form> : <EmptyState title={brandProfile.data?.profile ? 'No open campaign to invite from' : 'Brand invitations start with a campaign'} detail={brandProfile.data?.profile ? 'Publish an open campaign before inviting a creator.' : 'Set up a brand profile to create a campaign and send a collaboration request.'} action={<Link className="button button-quiet" href={brandProfile.data?.profile ? '/campaigns/new' : '/creator/profile'}>{brandProfile.data?.profile ? 'Create campaign' : 'Set up brand profile'} <ArrowRight size={14} /></Link>} />}</aside></div>
  </>;
}

function CampaignsPage() {
  const query = useListCampaigns();
  const brandProfile = useGetBrandProfile();
  const campaigns = (query.data || []).filter((campaign) => campaign.status === 'open');
  return <>
    <PageTitle eyebrow="Marketplace / campaigns" title="Open calls, clear briefs." copy="Explore live projects from brands looking for their next creative collaborator." action={brandProfile.data?.profile ? <Link href="/campaigns/new" className="button button-primary"><Plus size={15} /> Create campaign</Link> : undefined} />
    <div className="toolbar"><span className="chip orange">{campaigns.length} open campaigns</span><span className="chip">Fresh briefs from across the marketplace</span></div>
    {query.isLoading ? <LoadingGrid /> : query.isError ? <ErrorState retry={() => query.refetch()} /> : campaigns.length ? <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,340px),1fr))' }}>{campaigns.map((campaign) => <CampaignCard campaign={campaign} key={campaign.id} />)}</div> : <EmptyState title="No open campaigns right now" detail={brandProfile.data?.profile ? 'Check back soon, or create the first brief for your team.' : 'There are no open briefs at the moment. When brands publish work, it will appear here.'} action={brandProfile.data?.profile ? <Link href="/campaigns/new" className="button button-primary">Create a campaign</Link> : undefined} />}
  </>;
}
function CampaignCard({ campaign }: { campaign: Campaign }) {
  return <article className="panel campaign-card" data-testid={`card-campaign-${campaign.id}`}><div className="campaign-meta"><span>{campaign.brandName}</span><span className="status-pill pending">{campaign.status}</span></div><div className="campaign-title">{campaign.title}</div><p className="campaign-description">{campaign.description}</p><ChipList values={[campaign.contentType, ...campaign.skills].filter(Boolean)} tone="purple" /><div className="campaign-footer"><span className="campaign-budget">{money(campaign.budget)} budget</span><span style={{ color: '#8f8d99', fontSize: 11 }}><CalendarDays size={13} style={{ verticalAlign: 'middle', marginRight: 5 }} />{dateLabel(campaign.deadline)}</span></div><Link href={`/campaigns/${campaign.id}`} className="button button-quiet" style={{ justifyContent: 'space-between' }}>View brief <ArrowRight size={14} /></Link></article>;
}

function CampaignForm() {
  const brandProfile = useGetBrandProfile();
  const create = useCreateCampaign();
  const client = useQueryClient();
  const [, setLocation] = useLocation();
  const [error, setError] = useState('');
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setError('');
    const form = new FormData(event.currentTarget);
    create.mutate({ data: {
      title: String(form.get('title') || ''),
      description: String(form.get('description') || ''),
      contentType: String(form.get('contentType') || ''),
      skills: listValue(String(form.get('skills') || '')),
      tools: listValue(String(form.get('tools') || '')),
      budget: Number(form.get('budget') || 0),
      deadline: String(form.get('deadline') || ''),
      audience: String(form.get('audience') || ''),
      deliverables: listValue(String(form.get('deliverables') || '')),
    } }, { onSuccess: (campaign) => { client.invalidateQueries({ queryKey: getListCampaignsQueryKey() }); client.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); setLocation(`/campaigns/${campaign.id}`); }, onError: () => setError('Your campaign could not be published. Please review the details and try again.') });
  };
  if (brandProfile.isError) return <><PageTitle eyebrow="Campaigns / create" title="A good brief starts with your brand." /><ErrorState retry={() => brandProfile.refetch()} /></>;
  if (!brandProfile.isLoading && !brandProfile.data?.profile) return <><PageTitle eyebrow="Campaigns / create" title="A good brief starts with your brand." copy="Set up your brand presence before publishing a campaign." /><EmptyState title="Complete your brand profile first" detail="A little context helps creators understand who they will be working with." action={<Link href="/creator/profile?role=brand" className="button button-primary">Set up brand profile <ArrowRight size={15} /></Link>} /></>;
  return <>
    <PageTitle eyebrow="Campaigns / create" title="Write a brief people can feel." copy="A clear campaign is the start of a good collaboration." action={<Link href="/campaigns" className="button button-quiet"><ChevronLeft size={15} /> Campaigns</Link>} />
    <AiUnavailableNotice feature="AI campaign brief generation" />
    <form className="panel panel-pad" onSubmit={submit} style={{ maxWidth: 900 }}>
      <div className="form-grid">
        <div className="field full"><label htmlFor="campaign-title">Campaign title</label><input id="campaign-title" name="title" placeholder="A specific, memorable project title" required minLength={1} /></div>
        <div className="field full"><label htmlFor="campaign-description">The brief</label><textarea id="campaign-description" name="description" placeholder="What are you making, why now, and what does success look like?" required /></div>
        <div className="field"><label htmlFor="campaign-content">Content type</label><input id="campaign-content" name="contentType" placeholder="Short-form video, brand identity…" required /></div>
        <div className="field"><label htmlFor="campaign-budget">Budget (USD)</label><input id="campaign-budget" name="budget" type="number" min="0" step="1" placeholder="2400" required /></div>
        <div className="field"><label htmlFor="campaign-deadline">Deadline</label><input id="campaign-deadline" name="deadline" type="date" required /></div>
        <div className="field"><label htmlFor="campaign-audience">Audience</label><input id="campaign-audience" name="audience" placeholder="Who should this speak to?" /></div>
        <div className="field"><label htmlFor="campaign-skills">Skills</label><input id="campaign-skills" name="skills" placeholder="Creative direction, editing" /><span className="field-hint">Separate with commas.</span></div>
        <div className="field"><label htmlFor="campaign-tools">Tools</label><input id="campaign-tools" name="tools" placeholder="Premiere Pro, Figma" /><span className="field-hint">Optional; separate with commas.</span></div>
        <div className="field full"><label htmlFor="campaign-deliverables">Deliverables</label><input id="campaign-deliverables" name="deliverables" placeholder="3 edited videos, cutdowns, usage rights" /><span className="field-hint">Separate deliverables with commas.</span></div>
      </div>
      {(error || create.isError) && <div className="error-box" style={{ marginTop: 17 }}>{error || 'Your campaign could not be published. Please review the details and try again.'}</div>}
      <div className="form-actions"><Button type="submit" disabled={create.isPending}>{create.isPending ? 'Publishing…' : 'Publish campaign'} <ArrowRight size={15} /></Button><Link href="/campaigns" className="button button-plain">Cancel</Link></div>
    </form>
  </>;
}

function CampaignDetail({ id }: { id: string }) {
  const campaignId = Number(id);
  const campaign = useGetCampaign(campaignId, { query: { enabled: Number.isFinite(campaignId), queryKey: getGetCampaignQueryKey(campaignId) } });
  const brandProfile = useGetBrandProfile();
  const matching = useFindCampaignMatches();
  const client = useQueryClient();
  const foundMatches = matching.data || [];
  const detail = campaign.data;
  const isOwner = !!detail && brandProfile.data?.profile?.id === detail.brandId;
  const runMatching = () => matching.mutate({ id: campaignId }, { onSuccess: () => { client.invalidateQueries({ queryKey: getListRecentMatchesQueryKey() }); } });
  if (campaign.isLoading) return <><PageTitle eyebrow="Campaign / brief" title="Loading brief" /><LoadingGrid count={2} /></>;
  if (campaign.isError || !detail) return <><PageTitle eyebrow="Campaign / brief" title="Brief unavailable" /><ErrorState retry={() => campaign.refetch()} /></>;
  return <>
    <PageTitle eyebrow={`Campaign / ${detail.brandName}`} title={detail.title} copy={detail.brandName} action={<Link href="/campaigns" className="button button-quiet"><ChevronLeft size={15} /> All campaigns</Link>} />
    <div className="detail-layout">
      <section className="panel panel-pad"><div className="campaign-meta"><span className="status-pill pending">{detail.status}</span><span style={{ color: '#92909d', fontSize: 11 }}>Published {dateLabel(detail.createdAt)}</span></div><h2 style={{ margin: '18px 0 12px' }}>The brief</h2><p className="profile-bio">{detail.description}</p><div className="grid" style={{ gridTemplateColumns: 'repeat(2,minmax(0,1fr))', margin: '25px 0' }}><div className="panel panel-pad"><span className="stat-label">Budget</span><div className="stat-value" style={{ fontSize: 22 }}>{money(detail.budget)}</div></div><div className="panel panel-pad"><span className="stat-label">Deadline</span><div style={{ font: '700 17px var(--app-font-display)', marginTop: 14 }}>{dateLabel(detail.deadline)}</div></div></div><h3>Deliverables</h3><div className="chip-row" style={{ margin: '12px 0 22px' }}>{detail.deliverables.map((item) => <span className="chip" key={item}>{item}</span>)}</div><h3>Creative fit</h3><p className="subheading" style={{ margin: '7px 0 12px' }}>{detail.contentType} for {detail.audience || 'your audience'}.</p><ChipList values={[...detail.skills, ...detail.tools]} tone="purple" /></section>
      <aside className="panel panel-pad"><span className="eyebrow">Compatibility shortlist</span><h2>{isOwner ? 'Find the right fit.' : 'A clear brief makes a better fit.'}</h2><p className="subheading" style={{ margin: '9px 0 19px' }}>{isOwner ? 'A transparent score compares this campaign’s skills, tools, category, portfolio relevance, experience and budget.' : 'The campaign owner can generate a ranked compatibility shortlist for this brief.'}</p>{isOwner ? <><Button onClick={runMatching} disabled={matching.isPending} style={{ width: '100%' }}>{matching.isPending ? 'Finding matches…' : <><Sparkles size={15} /> Find creator matches</>}</Button>{matching.isError && <p className="field-hint" style={{ color: '#ff9a9d', marginTop: 10 }}>Matches could not be loaded. Try again shortly.</p>}{foundMatches.length > 0 && <div style={{ display: 'grid', gap: 11, marginTop: 18 }}>{foundMatches.slice(0, 5).map((match) => <div key={match.id} style={{ padding: 12, borderRadius: 10, background: 'rgba(255,255,255,.035)', border: '1px solid rgba(255,255,255,.07)' }}><div style={{ display: 'flex', alignItems: 'center', gap: 9 }}><Avatar name={match.creatorName} src={match.avatarUrl} size="34px" /><div style={{ flex: 1 }}><div style={{ fontSize: 12, fontWeight: 700 }}>{match.creatorName}</div><div className="creator-title">{match.title}</div></div><span className="match-badge">{match.score}%</span></div><p className="activity-detail" style={{ margin: '9px 0' }}>{match.reason}</p><Link href={`/creators/${match.creatorId}`} style={{ color: '#ff9a68', fontSize: 11 }}>View creator <ArrowRight size={12} /></Link></div>)}</div>}</> : <span className="chip">Campaign owner only</span>}</aside>
    </div>
  </>;
}

function MatchesPage() {
  const campaigns = useListCampaigns();
  const brandProfile = useGetBrandProfile();
  const recent = useListRecentMatches();
  const open = (campaigns.data || []).filter((campaign) => campaign.status === 'open' && campaign.brandId === brandProfile.data?.profile?.id);
  const [campaignId, setCampaignId] = useState('');
  const matches = useFindCampaignMatches();
  const client = useQueryClient();
  const run = () => {
    if (!campaignId) return;
    matches.mutate({ id: Number(campaignId) }, { onSuccess: () => { client.invalidateQueries({ queryKey: getListRecentMatchesQueryKey() }); } });
  };
  const visible = matches.data || recent.data || [];
  return <>
     <PageTitle eyebrow="Intelligence / matches" title="Fit, not just reach." copy="Transparent creator compatibility scores based on each campaign’s requirements." />
    <section className="panel panel-pad" style={{ marginBottom: 18 }}><div className="section-head"><div><h2>Build your shortlist</h2><p>Choose a campaign and see the strongest compatibility signals.</p></div><Sparkles size={19} color="#c19bfa" /></div><div className="toolbar" style={{ marginBottom: 0 }}><div className="field" style={{ flex: 1, minWidth: 220 }}><select aria-label="Select campaign" value={campaignId} onChange={(event) => setCampaignId(event.target.value)}><option value="">Select an open campaign</option>{open.map((campaign) => <option key={campaign.id} value={campaign.id}>{campaign.title}</option>)}</select></div><Button onClick={run} disabled={!campaignId || matches.isPending}>{matches.isPending ? 'Finding matches…' : <><WandSparkles size={15} /> Find matches</>}</Button></div>{matches.isError && <p className="field-hint" style={{ color: '#ff9a9d', marginTop: 11 }}>The ranked match service is unavailable right now. Please try again.</p>}</section>
    <div className="section-head"><div><h2>{matches.data ? 'Campaign matches' : 'Recent matches'}</h2><p>Compatibility scores are returned by the matching service.</p></div></div>
    {recent.isLoading && !matches.data ? <LoadingGrid /> : visible.length ? <div className="cards-grid">{visible.map((match) => <CreatorCard match={match} key={`${match.campaignId}-${match.id}`} />)}</div> : <EmptyState title="Your shortlist starts with a brief" detail={open.length ? 'Choose an open campaign above to see creators ranked for its requirements.' : 'Publish an open campaign before searching for campaign-specific creator matches.'} action={!open.length ? <Link href="/campaigns/new" className="button button-primary">Create a campaign</Link> : undefined} />}
  </>;
}

function RequestsPage() {
  const query = useListCollaborationRequests();
  const creatorProfile = useGetCreatorProfile();
  const update = useUpdateCollaborationRequest();
  const client = useQueryClient();
  const requests = query.data || [];
  const handleUpdate = (item: CollaborationRequest, status: 'accepted' | 'declined') => update.mutate({ id: item.id, data: { status } }, { onSuccess: () => { client.invalidateQueries({ queryKey: getListCollaborationRequestsQueryKey() }); client.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); } });
  return <>
    <PageTitle eyebrow="Collaborations / inbox" title="Requests worth a conversation." copy="Review incoming and outgoing collaboration requests." />
    <div className="panel panel-pad"><div className="section-head"><div><h2>Collaboration requests</h2><p>Every good partnership starts with a thoughtful note.</p></div><Inbox size={18} color="#a689ca" /></div>
      {query.isLoading ? <div style={{ display: 'grid', gap: 13 }}>{[1, 2, 3].map((item) => <div className="skeleton" style={{ height: 73 }} key={item} />)}</div> : query.isError ? <ErrorState retry={() => query.refetch()} /> : requests.length ? requests.map((item) => <div className="request-row" key={item.id}><div><div className="request-title">{item.campaignTitle}</div><div className="request-meta">{item.brandName}</div></div><div><div className="request-title">{item.creatorName}</div><div className="request-meta">{dateLabel(item.createdAt)}</div></div><div><div className="request-message">{item.message}</div><span className={`status-pill ${item.status}`} style={{ marginTop: 8 }}>{item.status}</span></div><div style={{ display: 'flex', gap: 7, justifyContent: 'flex-end' }}>{item.status === 'pending' && item.creatorId === creatorProfile.data?.profile?.id && <><Button variant="quiet" disabled={update.isPending} onClick={() => handleUpdate(item, 'accepted')} title="Accept request"><Check size={14} /></Button><Button variant="danger" disabled={update.isPending} onClick={() => handleUpdate(item, 'declined')} title="Decline request"><X size={14} /></Button></>}<Link href="/messages" className="button button-plain" title="Open messages"><MessageCircle size={14} /></Link></div></div>) : <EmptyState title="No requests yet" detail="When a brand or creator reaches out, their note will appear here." action={<Link href="/campaigns" className="button button-quiet">Explore campaigns <ArrowRight size={14} /></Link>} />}
    </div>
  </>;
}

function MessagesPage() {
  const auth = useAuth();
  const creatorProfile = useGetCreatorProfile();
  const query = useListMessages();
  const requestQuery = useListCollaborationRequests();
  const send = useSendMessage();
  const client = useQueryClient();
  const requests = requestQuery.data || [];
  const messages = query.data || [];
  const [activeId, setActiveId] = useState<number | null>(null);
  const activeRequest = requests.find((item) => item.id === activeId) || requests[0];
  const requestId = activeRequest?.id ?? null;
  const conversation = messages.filter((message) => message.requestId === requestId);
  const [content, setContent] = useState('');
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!activeRequest || !content.trim()) return;
    send.mutate({ data: { requestId: activeRequest.id, content: content.trim() } }, { onSuccess: () => { client.invalidateQueries({ queryKey: getListMessagesQueryKey() }); client.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); setContent(''); } });
  };
  const counterpartName = (item: CollaborationRequest) => item.creatorId === creatorProfile.data?.profile?.id ? item.brandName : item.creatorName;
  return <>
    <PageTitle eyebrow="Collaborations / messages" title="Keep the good work moving." copy="Conversations tied to your collaboration requests." />
    <div className="panel message-layout">
      <div className="conversation-list">{requestQuery.isLoading ? <div className="skeleton" style={{ height: 60 }} /> : requests.length ? requests.map((item) => <div className={`conversation-item ${item.id === (activeRequest?.id) ? 'selected' : ''}`} key={item.id} onClick={() => setActiveId(item.id)} role="button" tabIndex={0} data-testid={`conversation-${item.id}`} onKeyDown={(event) => event.key === 'Enter' && setActiveId(item.id)}><Avatar name={counterpartName(item)} size="36px" /><div style={{ minWidth: 0 }}><div style={{ fontSize: 12, fontWeight: 700 }}>{item.campaignTitle}</div><div className="conversation-preview">{messages.find((message) => message.requestId === item.id)?.content || item.message}</div></div></div>) : <div className="empty-state" style={{ padding: '30px 8px', border: 0 }}><div className="empty-mark"><MessageCircle size={17} /></div><h3>No conversations</h3><p>Messages will appear after a collaboration request.</p></div>}</div>
      <div className="chat-pane">{activeRequest ? <><div className="chat-head">{activeRequest.campaignTitle}<span style={{ color: '#878591', fontWeight: 400, marginLeft: 10 }}>with {counterpartName(activeRequest)}</span></div><div className="chat-messages">{query.isLoading ? <div className="skeleton" style={{ height: 48, width: '60%' }} /> : conversation.length ? conversation.map((message) => <div className={`bubble ${message.senderId === auth.user?.id ? 'mine' : ''}`} key={message.id}>{message.content}<time>{message.senderName} · {dateLabel(message.createdAt)}</time></div>) : <EmptyState title="Start the conversation" detail="Share a thoughtful first note to get this collaboration moving." />}</div><form className="chat-compose" onSubmit={submit}><input aria-label="Write a message" value={content} onChange={(event) => setContent(event.target.value)} placeholder="Write a message…" required /><Button type="submit" disabled={send.isPending || !content.trim()} aria-label="Send message">{send.isPending ? 'Sending…' : <><Send size={15} /> Send</>}</Button></form>{send.isError && <div className="field-hint" style={{ color: '#ff9a9d', padding: '0 18px 12px' }}>Your message could not be sent. Try again.</div>}</> : <div style={{ display: 'grid', placeItems: 'center', minHeight: 390, padding: 24 }}><EmptyState title="Pick up a collaboration" detail="Select a request to view its conversation." /></div>}</div>
    </div>
  </>;
}

async function uploadImage(file: File, requestUpload: ReturnType<typeof useRequestUploadUrl>) {
  const result = await requestUpload.mutateAsync({ data: { name: file.name, size: file.size, contentType: file.type } });
  const response = await fetch(result.uploadURL, { method: 'PUT', headers: { 'Content-Type': file.type }, body: file });
  if (!response.ok) throw new Error('Image upload failed');
  return result.objectPath;
}

function ProfilePage() {
  const creatorQuery = useGetCreatorProfile();
  const brandQuery = useGetBrandProfile();
  const creatorSave = useSaveCreatorProfile();
  const brandSave = useSaveBrandProfile();
  const requestUpload = useRequestUploadUrl();
  const client = useQueryClient();
  const requestedRole = new URLSearchParams(window.location.search).get('role');
  const [kind, setKind] = useState<'creator' | 'brand'>(requestedRole === 'brand' ? 'brand' : 'creator');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const creator = creatorQuery.data?.profile;
  const brand = brandQuery.data?.profile;
  const saving = creatorSave.isPending || brandSave.isPending || requestUpload.isPending;
  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setError(''); setNotice('');
    const form = new FormData(event.currentTarget);
    let avatarPath: string | null | undefined = kind === 'creator' ? (creator?.avatarUrl || null) : (brand?.logoUrl || null);
    const file = form.get('image');
    try {
      if (file instanceof File && file.size > 0) avatarPath = await uploadImage(file, requestUpload);
      if (kind === 'creator') {
        await creatorSave.mutateAsync({ data: { name: String(form.get('name') || ''), title: String(form.get('title') || ''), bio: String(form.get('bio') || ''), avatarUrl: avatarPath, skills: listValue(String(form.get('skills') || '')), tools: listValue(String(form.get('tools') || '')), categories: listValue(String(form.get('categories') || '')), yearsExperience: Number(form.get('yearsExperience') || 0), startingPrice: Number(form.get('startingPrice') || 0), availability: String(form.get('availability') || 'Open to work') } });
        client.invalidateQueries({ queryKey: getGetCreatorProfileQueryKey() });
      } else {
        await brandSave.mutateAsync({ data: { companyName: String(form.get('companyName') || ''), industry: String(form.get('industry') || ''), description: String(form.get('description') || ''), website: String(form.get('website') || ''), logoUrl: avatarPath } });
        client.invalidateQueries({ queryKey: getGetBrandProfileQueryKey() });
      }
      client.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
      setNotice('Profile saved. Your marketplace presence is up to date.');
    } catch {
      setError('Your profile could not be saved. Check your connection and try again.');
    }
  };
  const queryLoading = creatorQuery.isLoading || brandQuery.isLoading;
  useEffect(() => {
    if (!requestedRole && !queryLoading) {
      setKind(creator ? 'creator' : brand ? 'brand' : 'creator');
    }
  }, [brand, creator, queryLoading, requestedRole]);
  if (queryLoading) return <><PageTitle eyebrow="Profile / setup" title="Your creative presence." /><LoadingGrid count={2} /></>;
  return <>
    <PageTitle eyebrow="Profile / setup" title="Your creative presence." copy="Give the marketplace a clear picture of who you are and how you work." />
    <div className="toolbar"><button className={`button ${kind === 'creator' ? 'button-primary' : 'button-quiet'}`} onClick={() => setKind('creator')}><UserRound size={14} /> Creator profile</button><button className={`button ${kind === 'brand' ? 'button-primary' : 'button-quiet'}`} onClick={() => setKind('brand')}><BriefcaseBusiness size={14} /> Brand profile</button></div>
    <form className="panel panel-pad" onSubmit={handleSubmit} style={{ maxWidth: 950 }}>
      <div className="upload-box" style={{ marginBottom: 22 }}><Avatar name={kind === 'creator' ? creator?.name : brand?.companyName} src={kind === 'creator' ? creator?.avatarUrl : brand?.logoUrl} size="56px" /><div><div style={{ fontSize: 13, fontWeight: 700 }}>{kind === 'creator' ? 'Your profile image' : 'Your brand mark'}</div><div className="field-hint" style={{ margin: '4px 0 8px' }}>PNG, JPG or WEBP. Uploaded directly and stored with your profile.</div><input className="file-input" id="profile-image" name="image" type="file" accept="image/png,image/jpeg,image/webp" /><label htmlFor="profile-image" className="button button-quiet" style={{ padding: '7px 10px', cursor: 'pointer' }}><FileImage size={13} /> Choose image</label></div></div>
      {kind === 'creator' ? <div className="form-grid">
        <div className="field"><label htmlFor="profile-name">Name</label><input id="profile-name" name="name" required defaultValue={creator?.name || ''} placeholder="Your name" /></div>
        <div className="field"><label htmlFor="profile-title">Professional title</label><input id="profile-title" name="title" required defaultValue={creator?.title || ''} placeholder="Creative director, filmmaker…" /></div>
        <div className="field full"><label htmlFor="profile-bio">Your point of view</label><textarea id="profile-bio" name="bio" defaultValue={creator?.bio || ''} placeholder="What do you make, and what kind of work brings out your best?" /></div>
        <div className="field"><label htmlFor="profile-skills">Skills</label><input id="profile-skills" name="skills" defaultValue={creator?.skills.join(', ') || ''} placeholder="Art direction, editing" /><span className="field-hint">Separate with commas.</span></div>
        <div className="field"><label htmlFor="profile-tools">Tools</label><input id="profile-tools" name="tools" defaultValue={creator?.tools.join(', ') || ''} placeholder="Premiere Pro, Figma" /></div>
        <div className="field"><label htmlFor="profile-categories">Categories</label><input id="profile-categories" name="categories" defaultValue={creator?.categories.join(', ') || ''} placeholder="Lifestyle, beauty, food" /></div>
        <div className="field"><label htmlFor="profile-availability">Availability</label><select id="profile-availability" name="availability" defaultValue={creator?.availability || 'Open to work'}><option>Open to work</option><option>Limited availability</option><option>Unavailable</option></select></div>
        <div className="field"><label htmlFor="profile-experience">Years of experience</label><input id="profile-experience" name="yearsExperience" type="number" min="0" defaultValue={creator?.yearsExperience ?? 0} /></div>
        <div className="field"><label htmlFor="profile-price">Starting price (USD)</label><input id="profile-price" name="startingPrice" type="number" min="0" defaultValue={creator?.startingPrice ?? 0} /></div>
      </div> : <div className="form-grid">
        <div className="field"><label htmlFor="brand-name">Company name</label><input id="brand-name" name="companyName" required defaultValue={brand?.companyName || ''} placeholder="Your company" /></div>
        <div className="field"><label htmlFor="brand-industry">Industry</label><input id="brand-industry" name="industry" defaultValue={brand?.industry || ''} placeholder="Consumer goods, media…" /></div>
        <div className="field full"><label htmlFor="brand-description">About the brand</label><textarea id="brand-description" name="description" defaultValue={brand?.description || ''} placeholder="What does your brand stand for, and who do you want to reach?" /></div>
        <div className="field full"><label htmlFor="brand-website">Website</label><input id="brand-website" name="website" type="url" defaultValue={brand?.website || ''} placeholder="https://yourbrand.com" /></div>
      </div>}
      {error && <div className="error-box" style={{ marginTop: 18 }}>{error}</div>}{notice && <div className="chip green" style={{ marginTop: 18, display: 'inline-flex' }}><Check size={13} /> {notice}</div>}
      <div className="form-actions"><Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save profile'} <Check size={14} /></Button></div>
    </form>
  </>;
}

function PortfolioCard({ project, onEdit, onDelete }: { project: any; onEdit?: () => void; onDelete?: () => void }) {
  return <article className="panel project-card" data-testid={`card-project-${project.id}`}><div className="project-image">{project.imageUrl ? <img src={project.imageUrl.startsWith('/objects/') ? `/api/storage${project.imageUrl}` : project.imageUrl} alt={project.title} /> : 'Selected work'}</div><div className="project-copy"><h3>{project.title}</h3><p>{project.description}</p><ChipList values={[project.category, ...project.tools].filter(Boolean)} tone="purple" />{(onEdit || onDelete) && <div className="form-actions" style={{ marginTop: 13 }}><Button variant="quiet" onClick={onEdit}>Edit project</Button><Button variant="danger" onClick={onDelete}>Delete</Button></div>}</div></article>;
}
function PortfolioPage() {
  const projects = useListPortfolioProjects();
  const create = useCreatePortfolioProject();
  const update = useUpdatePortfolioProject();
  const remove = useDeletePortfolioProject();
  const requestUpload = useRequestUploadUrl();
  const client = useQueryClient();
  const [editing, setEditing] = useState<number | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState('');
  const items = projects.data || [];
  const selected = items.find((project) => project.id === editing);
  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setError('');
    const form = new FormData(event.currentTarget);
    let imageUrl = selected?.imageUrl || null;
    const file = form.get('image');
    try {
      if (file instanceof File && file.size > 0) imageUrl = await uploadImage(file, requestUpload);
      const payload = { title: String(form.get('title') || ''), description: String(form.get('description') || ''), category: String(form.get('category') || ''), tools: listValue(String(form.get('tools') || '')), skills: listValue(String(form.get('skills') || '')), tags: listValue(String(form.get('tags') || '')), imageUrl };
      if (editing) update.mutate({ id: editing, data: payload }, { onSuccess: () => { client.invalidateQueries({ queryKey: getListPortfolioProjectsQueryKey() }); setEditing(null); setShowForm(false); }, onError: () => setError('Could not update this project.') });
      else create.mutate({ data: payload }, { onSuccess: () => { client.invalidateQueries({ queryKey: getListPortfolioProjectsQueryKey() }); setShowForm(false); }, onError: () => setError('Could not add this project.') });
    } catch { setError('The project image could not be uploaded. Please try again.'); }
  };
  const editProject = (id: number) => { setEditing(id); setShowForm(true); };
  const deleteProject = (id: number) => {
    if (!window.confirm('Delete this portfolio project? This cannot be undone.')) return;
    remove.mutate({ id }, { onSuccess: () => client.invalidateQueries({ queryKey: getListPortfolioProjectsQueryKey() }), onError: () => setError('Could not delete this project.') });
  };
  return <>
    <PageTitle eyebrow="Creator / portfolio" title="Show the work behind the words." copy="Keep a focused collection of projects that says how you think and make." action={<Button onClick={() => { setEditing(null); setError(''); setShowForm((state) => !state); }}>{showForm ? <X size={14} /> : <Plus size={15} />}{showForm ? 'Close form' : 'Add project'}</Button>} />
    {showForm && <form key={editing ?? 'new'} className="panel panel-pad" onSubmit={onSubmit} style={{ marginBottom: 20 }}><div className="section-head"><div><h2>{selected ? 'Edit project' : 'Add a portfolio project'}</h2><p>Make the story behind the work easy to understand.</p></div></div><AiUnavailableNotice feature="AI portfolio copy generation" /><div className="form-grid"><div className="field"><label htmlFor="project-title">Project title</label><input id="project-title" name="title" required defaultValue={selected?.title || ''} /></div><div className="field"><label htmlFor="project-category">Category</label><input id="project-category" name="category" defaultValue={selected?.category || ''} placeholder="Brand film, campaign…" /></div><div className="field full"><label htmlFor="project-description">Description</label><textarea id="project-description" name="description" defaultValue={selected?.description || ''} placeholder="What was the challenge, your role, and the outcome?" /></div><div className="field"><label htmlFor="project-tools">Tools</label><input id="project-tools" name="tools" defaultValue={selected?.tools.join(', ') || ''} placeholder="Premiere Pro, Figma" /></div><div className="field"><label htmlFor="project-skills">Skills</label><input id="project-skills" name="skills" defaultValue={selected?.skills.join(', ') || ''} placeholder="Creative direction, editing" /></div><div className="field"><label htmlFor="project-tags">Tags</label><input id="project-tags" name="tags" defaultValue={selected?.tags.join(', ') || ''} placeholder="Lifestyle, social" /></div><div className="field"><label htmlFor="project-image">Project image</label><input id="project-image" name="image" type="file" accept="image/png,image/jpeg,image/webp" /></div></div>{error && <div className="error-box" style={{ marginTop: 15 }}>{error}</div>}<div className="form-actions"><Button type="submit" disabled={create.isPending || update.isPending || requestUpload.isPending}>{create.isPending || update.isPending ? 'Saving…' : 'Save project'} <Check size={14} /></Button><Button type="button" variant="plain" onClick={() => { setShowForm(false); setEditing(null); }}>Cancel</Button></div></form>}
    {projects.isLoading ? <LoadingGrid /> : projects.isError ? <ErrorState retry={() => projects.refetch()} /> : items.length ? <div className="project-grid">{items.map((project) => <PortfolioCard project={project} key={project.id} onEdit={() => editProject(project.id)} onDelete={() => deleteProject(project.id)} />)}</div> : <EmptyState title="A portfolio of one can start here" detail="Add a project to show brands what you make and how you think." action={<Button onClick={() => setShowForm(true)}><Plus size={14} /> Add your first project</Button>} />}
  </>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function MissingRoute() {
  return <div className="app-shell"><main className="main-area" style={{ maxWidth: 720, paddingTop: 100 }}><div className="panel panel-pad"><span className="eyebrow">404 / Not found</span><h1>That page isn’t in this brief.</h1><p className="subheading">The link may have moved. Head back to your workspace to keep going.</p><Link href="/dashboard" className="button button-primary" style={{ marginTop: 19 }}>Back to dashboard <ArrowRight size={15} /></Link></div></main></div>;
}
function Router() {
  const auth = useAuth();
  if (auth.isLoading) return <div className="app-shell" style={{ minHeight: '100dvh', display: 'grid', placeItems: 'center' }}><div style={{ width: 280 }}><div className="skeleton" style={{ height: 22, width: '55%', marginBottom: 14 }} /><div className="skeleton" style={{ height: 13, width: '85%' }} /></div></div>;
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={Landing} />
    <Route path="/dashboard">{auth.isAuthenticated ? <Shell><Dashboard /></Shell> : <Landing />}</Route>
    <Route path="/creator/profile">{auth.isAuthenticated ? <Shell><ProfilePage /></Shell> : <Landing />}</Route>
    <Route path="/creator/portfolio">{auth.isAuthenticated ? <Shell><PortfolioPage /></Shell> : <Landing />}</Route>
    <Route path="/campaigns">{auth.isAuthenticated ? <Shell><CampaignsPage /></Shell> : <Landing />}</Route>
    <Route path="/campaigns/new">{auth.isAuthenticated ? <Shell><CampaignForm /></Shell> : <Landing />}</Route>
    <Route path="/campaigns/:id">{(params) => auth.isAuthenticated ? <Shell><CampaignDetail id={params.id} /></Shell> : <Landing />}</Route>
    <Route path="/creators">{auth.isAuthenticated ? <Shell><DiscoverCreators /></Shell> : <Landing />}</Route>
    <Route path="/creators/:id">{(params) => auth.isAuthenticated ? <Shell><CreatorDetailPage id={params.id} /></Shell> : <Landing />}</Route>
    <Route path="/matches">{auth.isAuthenticated ? <Shell><MatchesPage /></Shell> : <Landing />}</Route>
    <Route path="/requests">{auth.isAuthenticated ? <Shell><RequestsPage /></Shell> : <Landing />}</Route>
    <Route path="/messages">{auth.isAuthenticated ? <Shell><MessagesPage /></Shell> : <Landing />}</Route>
    <Route component={MissingRoute} />
  </Switch></RoutedErrorBoundary>;
}
function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><Router /><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;
