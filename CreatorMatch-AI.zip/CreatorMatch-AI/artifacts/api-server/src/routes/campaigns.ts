import {
  CreateCampaignBody,
  CreateCampaignResponse,
  FindCampaignMatchesParams,
  FindCampaignMatchesResponse,
  GetCampaignParams,
  GetCampaignResponse,
  ListCampaignsResponse,
  ListRecentMatchesResponse,
} from "@workspace/api-zod";
import {
  brandProfilesTable,
  campaignsTable,
  creatorProfilesTable,
  db,
  matchesTable,
  portfolioProjectsTable,
} from "@workspace/db";
import { and, desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { requireUser } from "../lib/require-user";

const router: IRouter = Router();

const normalize = (value: string) => value.trim().toLocaleLowerCase();
const tokens = (value: string) =>
  new Set(
    value
      .toLocaleLowerCase()
      .match(/[a-z0-9+#-]{2,}/g)
      ?.filter((word) => !["with", "for", "and", "the", "from", "that"].includes(word)) ??
      [],
  );

function calculateMatch(
  campaign: typeof campaignsTable.$inferSelect,
  creator: typeof creatorProfilesTable.$inferSelect,
  projects: (typeof portfolioProjectsTable.$inferSelect)[],
) {
  const matchingSkills = campaign.skills.filter((required) =>
    creator.skills.some((skill) => normalize(skill) === normalize(required)),
  );
  const matchingTools = campaign.tools.filter((required) =>
    creator.tools.some((tool) => normalize(tool) === normalize(required)),
  );
  const campaignTerms = tokens(
    [
      campaign.title,
      campaign.description,
      campaign.contentType,
      campaign.audience,
      ...campaign.skills,
      ...campaign.tools,
      ...campaign.deliverables,
    ].join(" "),
  );
  const category = creator.categories.find((candidate) => {
    const categoryTerms = tokens(candidate);
    return (
      normalize(candidate) === normalize(campaign.contentType) ||
      [...categoryTerms].some((term) => campaignTerms.has(term))
    );
  });
  const portfolioTerms = tokens(
    projects
      .map((project) =>
        [
          project.title,
          project.description,
          project.category,
          ...project.tags,
          ...project.skills,
          ...project.tools,
        ].join(" "),
      )
      .join(" "),
  );
  const portfolioOverlap = [...campaignTerms].filter((term) =>
    portfolioTerms.has(term),
  ).length;
  const portfolioScore =
    campaignTerms.size === 0
      ? 0
      : Math.min(20, Math.round((portfolioOverlap / campaignTerms.size) * 50));
  const skillScore =
    campaign.skills.length === 0
      ? 12
      : Math.round((matchingSkills.length / campaign.skills.length) * 30);
  const toolScore =
    campaign.tools.length === 0
      ? 8
      : Math.round((matchingTools.length / campaign.tools.length) * 20);
  const categoryScore = category ? 15 : creator.categories.length === 0 ? 4 : 0;
  const experienceScore = Math.min(5, creator.yearsExperience);
  const budgetScore =
    campaign.budget <= 0
      ? 0
      : creator.startingPrice <= campaign.budget
        ? 10
        : Math.max(
            0,
            Math.round((campaign.budget / creator.startingPrice) * 10),
          );
  const score = Math.min(
    100,
    Math.max(
      0,
      skillScore + toolScore + categoryScore + portfolioScore + experienceScore + budgetScore,
    ),
  );
  const reasonParts = [
    matchingSkills.length
      ? `matches ${matchingSkills.slice(0, 2).join(" and ")}`
      : "",
    matchingTools.length ? `works with ${matchingTools.slice(0, 2).join(" and ")}` : "",
    category ? `creates ${category} content` : "",
    creator.startingPrice <= campaign.budget
      ? "fits the campaign budget"
      : campaign.budget > 0
        ? "may need a budget adjustment"
        : "",
    creator.yearsExperience
      ? `${creator.yearsExperience} year${creator.yearsExperience === 1 ? "" : "s"} of experience`
      : "",
  ].filter(Boolean);
  return {
    matchingSkills,
    matchingTools,
    matchingCategory: category ?? null,
    score,
    reason: reasonParts.length
      ? `Strong fit: ${reasonParts.join(", ")}.`
      : "Profile and campaign details are available for direct review.",
  };
}

router.get("/campaigns", async (_req, res): Promise<void> => {
  const rows = await db
    .select({ campaign: campaignsTable, brandName: brandProfilesTable.companyName })
    .from(campaignsTable)
    .innerJoin(brandProfilesTable, eq(campaignsTable.brandId, brandProfilesTable.id))
    .where(eq(campaignsTable.status, "open"))
    .orderBy(desc(campaignsTable.createdAt));
  res.json(
    ListCampaignsResponse.parse(
      rows.map(({ campaign, brandName }) => ({ ...campaign, brandName })),
    ),
  );
});

router.post("/campaigns", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const parsed = CreateCampaignBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [brand] = await db
    .select()
    .from(brandProfilesTable)
    .where(eq(brandProfilesTable.userId, req.user.id))
    .limit(1);
  if (!brand) {
    res.status(409).json({ error: "Create a brand profile before publishing a campaign" });
    return;
  }
  const [campaign] = await db
    .insert(campaignsTable)
    .values({
      ...parsed.data,
      deadline: parsed.data.deadline.toISOString().slice(0, 10),
      brandId: brand.id,
    })
    .returning();
  res
    .status(201)
    .json(CreateCampaignResponse.parse({ ...campaign, brandName: brand.companyName }));
});

router.get("/campaigns/:id", async (req, res): Promise<void> => {
  const params = GetCampaignParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .select({ campaign: campaignsTable, brandName: brandProfilesTable.companyName })
    .from(campaignsTable)
    .innerJoin(brandProfilesTable, eq(campaignsTable.brandId, brandProfilesTable.id))
    .where(eq(campaignsTable.id, params.data.id))
    .limit(1);
  if (!row) {
    res.status(404).json({ error: "Campaign not found" });
    return;
  }
  res.json(GetCampaignResponse.parse({ ...row.campaign, brandName: row.brandName }));
});

router.post("/campaigns/:id/matches", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const params = FindCampaignMatchesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [campaign] = await db
    .select()
    .from(campaignsTable)
    .innerJoin(brandProfilesTable, eq(campaignsTable.brandId, brandProfilesTable.id))
    .where(
      and(
        eq(campaignsTable.id, params.data.id),
        eq(brandProfilesTable.userId, req.user.id),
      ),
    )
    .limit(1);
  if (!campaign) {
    res.status(404).json({ error: "Campaign not found" });
    return;
  }
  const profiles = await db.select().from(creatorProfilesTable);
  const projects = await db.select().from(portfolioProjectsTable);
  const ranked = profiles
    .filter((profile) => profile.userId !== req.user.id)
    .map((creator) => {
      const detail = calculateMatch(
        campaign.campaigns,
        creator,
        projects.filter((project) => project.userId === creator.userId),
      );
      return { creator, detail };
    })
    .sort((a, b) => b.detail.score - a.detail.score);
  const results = [];
  for (const { creator, detail } of ranked) {
    const [match] = await db
      .insert(matchesTable)
      .values({
        campaignId: campaign.campaigns.id,
        creatorId: creator.id,
        score: detail.score,
        matchingSkills: detail.matchingSkills,
        matchingTools: detail.matchingTools,
        matchingCategory: detail.matchingCategory,
        reason: detail.reason,
      })
      .onConflictDoUpdate({
        target: [matchesTable.campaignId, matchesTable.creatorId],
        set: {
          score: detail.score,
          matchingSkills: detail.matchingSkills,
          matchingTools: detail.matchingTools,
          matchingCategory: detail.matchingCategory,
          reason: detail.reason,
          createdAt: new Date(),
        },
      })
      .returning({ id: matchesTable.id });
    results.push({
      id: match.id,
      campaignId: campaign.campaigns.id,
      creatorId: creator.id,
      creatorName: creator.name,
      title: creator.title,
      avatarUrl: creator.avatarUrl,
      score: detail.score,
      matchingSkills: detail.matchingSkills,
      matchingTools: detail.matchingTools,
      matchingCategory: detail.matchingCategory,
      reason: detail.reason,
      startingPrice: creator.startingPrice,
    });
  }
  res.json(FindCampaignMatchesResponse.parse(results));
});

router.get("/matches", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const rows = await db
    .select({ match: matchesTable, creator: creatorProfilesTable })
    .from(matchesTable)
    .innerJoin(campaignsTable, eq(matchesTable.campaignId, campaignsTable.id))
    .innerJoin(brandProfilesTable, eq(campaignsTable.brandId, brandProfilesTable.id))
    .innerJoin(creatorProfilesTable, eq(matchesTable.creatorId, creatorProfilesTable.id))
    .where(eq(brandProfilesTable.userId, req.user.id))
    .orderBy(desc(matchesTable.createdAt), desc(matchesTable.score));
  const matches = rows.map(({ match, creator }) => ({
    id: match.id,
    campaignId: match.campaignId,
    creatorId: creator.id,
    creatorName: creator.name,
    title: creator.title,
    avatarUrl: creator.avatarUrl,
    score: match.score,
    matchingSkills: match.matchingSkills,
    matchingTools: match.matchingTools,
    matchingCategory: match.matchingCategory,
    reason: match.reason,
    startingPrice: creator.startingPrice,
  }));
  res.json(ListRecentMatchesResponse.parse(matches));
});

export default router;
