import {
  GenerateCampaignBriefBody,
  GeneratePortfolioCopyBody,
} from "@workspace/api-zod";
import { Router, type IRouter } from "express";
import { requireUser } from "../lib/require-user";

const router: IRouter = Router();

function aiUnavailable(res: Parameters<Parameters<IRouter["post"]>[1]>[1]) {
  res.status(503).json({
    error:
      "AI copy generation is unavailable until an AI provider is configured. Your profile and campaign tools are still available.",
  });
}

router.post("/ai/campaign", (req, res): void => {
  if (!requireUser(req, res)) return;
  const parsed = GenerateCampaignBriefBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  aiUnavailable(res);
});

router.post("/ai/portfolio", (req, res): void => {
  if (!requireUser(req, res)) return;
  const parsed = GeneratePortfolioCopyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  aiUnavailable(res);
});

export default router;
