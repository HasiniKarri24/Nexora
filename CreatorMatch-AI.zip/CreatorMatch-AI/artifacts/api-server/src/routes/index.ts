import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import storageRouter from "./storage";
import profilesRouter from "./profiles";
import portfolioRouter from "./portfolio";
import campaignsRouter from "./campaigns";
import collaborationRouter from "./collaboration";
import dashboardRouter from "./dashboard";
import aiRouter from "./ai";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(storageRouter);
router.use(profilesRouter);
router.use(portfolioRouter);
router.use(campaignsRouter);
router.use(collaborationRouter);
router.use(dashboardRouter);
router.use(aiRouter);

export default router;
