import { GetDashboardSummaryResponse } from "@workspace/api-zod";
import {
  brandProfilesTable,
  campaignsTable,
  collaborationRequestsTable,
  creatorProfilesTable,
  db,
  messagesTable,
} from "@workspace/db";
import { and, desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { requireUser } from "../lib/require-user";

const router: IRouter = Router();

router.get("/dashboard", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const [creator] = await db
    .select()
    .from(creatorProfilesTable)
    .where(eq(creatorProfilesTable.userId, req.user.id))
    .limit(1);
  const [brand] = await db
    .select()
    .from(brandProfilesTable)
    .where(eq(brandProfilesTable.userId, req.user.id))
    .limit(1);
  const role = brand ? "brand" : creator ? "creator" : "unset";
  const [openCampaigns, creators] = await Promise.all([
    db
      .select()
      .from(campaignsTable)
      .where(eq(campaignsTable.status, "open")),
    db.select({ id: creatorProfilesTable.id }).from(creatorProfilesTable),
  ]);
  const requests = brand
    ? await db
        .select()
        .from(collaborationRequestsTable)
        .where(
          and(
            eq(collaborationRequestsTable.brandId, brand.id),
            eq(collaborationRequestsTable.status, "pending"),
          ),
        )
    : creator
      ? await db
          .select()
          .from(collaborationRequestsTable)
          .where(
            and(
              eq(collaborationRequestsTable.creatorId, creator.id),
              eq(collaborationRequestsTable.status, "pending"),
            ),
          )
      : [];
  const incomingMessages = await db
    .select({ id: messagesTable.id })
    .from(messagesTable)
    .where(eq(messagesTable.recipientId, req.user.id));
  const recentCampaigns = brand
    ? await db
        .select()
        .from(campaignsTable)
        .where(eq(campaignsTable.brandId, brand.id))
        .orderBy(desc(campaignsTable.createdAt))
        .limit(3)
    : [];
  const recentRequests = await db
    .select({
      id: collaborationRequestsTable.id,
      status: collaborationRequestsTable.status,
      createdAt: collaborationRequestsTable.createdAt,
      creatorName: creatorProfilesTable.name,
      brandName: brandProfilesTable.companyName,
      campaignTitle: campaignsTable.title,
    })
    .from(collaborationRequestsTable)
    .innerJoin(creatorProfilesTable, eq(collaborationRequestsTable.creatorId, creatorProfilesTable.id))
    .innerJoin(brandProfilesTable, eq(collaborationRequestsTable.brandId, brandProfilesTable.id))
    .innerJoin(campaignsTable, eq(collaborationRequestsTable.campaignId, campaignsTable.id))
    .where(
      role === "brand"
        ? eq(brandProfilesTable.userId, req.user.id)
        : eq(creatorProfilesTable.userId, req.user.id),
    )
    .orderBy(desc(collaborationRequestsTable.createdAt))
    .limit(4);
  const recentActivity = [
    ...recentCampaigns.map((campaign) => ({
      id: `campaign-${campaign.id}`,
      kind: "campaign",
      title: campaign.title,
      detail: "Campaign published",
      createdAt: campaign.createdAt.toISOString(),
    })),
    ...recentRequests.map((request) => ({
      id: `request-${request.id}`,
      kind: "request",
      title: request.campaignTitle,
      detail: `${request.creatorName} · ${request.brandName} · ${request.status}`,
      createdAt: request.createdAt.toISOString(),
    })),
  ]
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .slice(0, 5);
  res.json(
    GetDashboardSummaryResponse.parse({
      role,
      campaignsOpen: openCampaigns.length,
      creatorCount: creators.length,
      pendingRequests: requests.length,
      inboxMessages: incomingMessages.length,
      recentActivity,
    }),
  );
});

export default router;
