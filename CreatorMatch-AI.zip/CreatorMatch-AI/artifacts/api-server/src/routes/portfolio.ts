import {
  CreatePortfolioProjectBody,
  CreatePortfolioProjectResponse,
  DeletePortfolioProjectParams,
  ListPortfolioProjectsResponse,
  UpdatePortfolioProjectBody,
  UpdatePortfolioProjectParams,
  UpdatePortfolioProjectResponse,
} from "@workspace/api-zod";
import { db, portfolioProjectsTable } from "@workspace/db";
import { and, asc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { requireUser } from "../lib/require-user";

const router: IRouter = Router();

router.get("/portfolio", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const projects = await db
    .select()
    .from(portfolioProjectsTable)
    .where(eq(portfolioProjectsTable.userId, req.user.id))
    .orderBy(asc(portfolioProjectsTable.createdAt));
  res.json(ListPortfolioProjectsResponse.parse(projects));
});

router.post("/portfolio", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const parsed = CreatePortfolioProjectBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [project] = await db
    .insert(portfolioProjectsTable)
    .values({ ...parsed.data, userId: req.user.id })
    .returning();
  res.status(201).json(CreatePortfolioProjectResponse.parse(project));
});

router.patch("/portfolio/:id", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const params = UpdatePortfolioProjectParams.safeParse(req.params);
  const parsed = UpdatePortfolioProjectBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res
      .status(400)
      .json({ error: params.error?.message ?? parsed.error?.message });
    return;
  }
  const [project] = await db
    .update(portfolioProjectsTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(
      and(
        eq(portfolioProjectsTable.id, params.data.id),
        eq(portfolioProjectsTable.userId, req.user.id),
      ),
    )
    .returning();
  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }
  res.json(UpdatePortfolioProjectResponse.parse(project));
});

router.delete("/portfolio/:id", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const params = DeletePortfolioProjectParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [project] = await db
    .delete(portfolioProjectsTable)
    .where(
      and(
        eq(portfolioProjectsTable.id, params.data.id),
        eq(portfolioProjectsTable.userId, req.user.id),
      ),
    )
    .returning({ id: portfolioProjectsTable.id });
  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
