import {
  CreateCollaborationRequestBody,
  CreateCollaborationRequestResponse,
  ListCollaborationRequestsResponse,
  ListMessagesResponse,
  SendMessageBody,
  SendMessageResponse,
  UpdateCollaborationRequestBody,
  UpdateCollaborationRequestParams,
  UpdateCollaborationRequestResponse,
} from "@workspace/api-zod";
import {
  brandProfilesTable,
  campaignsTable,
  collaborationRequestsTable,
  creatorProfilesTable,
  db,
  messagesTable,
} from "@workspace/db";
import { and, desc, eq, or } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { requireUser } from "../lib/require-user";

const router: IRouter = Router();

const requestDetails = () =>
  db
    .select({
      request: collaborationRequestsTable,
      campaignTitle: campaignsTable.title,
      creatorName: creatorProfilesTable.name,
      brandName: brandProfilesTable.companyName,
    })
    .from(collaborationRequestsTable)
    .innerJoin(campaignsTable, eq(collaborationRequestsTable.campaignId, campaignsTable.id))
    .innerJoin(creatorProfilesTable, eq(collaborationRequestsTable.creatorId, creatorProfilesTable.id))
    .innerJoin(brandProfilesTable, eq(collaborationRequestsTable.brandId, brandProfilesTable.id));

router.get("/requests", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const requests = await requestDetails()
    .where(
      or(
        eq(creatorProfilesTable.userId, req.user.id),
        eq(brandProfilesTable.userId, req.user.id),
      ),
    )
    .orderBy(desc(collaborationRequestsTable.createdAt));
  res.json(
    ListCollaborationRequestsResponse.parse(
      requests.map(({ request, campaignTitle, creatorName, brandName }) => ({
        ...request,
        campaignTitle,
        creatorName,
        brandName,
      })),
    ),
  );
});

router.post("/requests", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const parsed = CreateCollaborationRequestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [campaign] = await db
    .select({
      campaign: campaignsTable,
      brand: brandProfilesTable,
    })
    .from(campaignsTable)
    .innerJoin(brandProfilesTable, eq(campaignsTable.brandId, brandProfilesTable.id))
    .where(
      and(
        eq(campaignsTable.id, parsed.data.campaignId),
        eq(brandProfilesTable.userId, req.user.id),
        eq(campaignsTable.status, "open"),
      ),
    )
    .limit(1);
  if (!campaign) {
    res.status(404).json({ error: "Open campaign not found for this brand" });
    return;
  }
  const [creator] = await db
    .select()
    .from(creatorProfilesTable)
    .where(eq(creatorProfilesTable.id, parsed.data.creatorId))
    .limit(1);
  if (!creator) {
    res.status(404).json({ error: "Creator not found" });
    return;
  }
  if (creator.userId === req.user.id) {
    res.status(400).json({ error: "You cannot invite your own creator profile" });
    return;
  }
  const [request] = await db
    .insert(collaborationRequestsTable)
    .values({
      campaignId: campaign.campaign.id,
      creatorId: creator.id,
      brandId: campaign.brand.id,
      message: parsed.data.message,
    })
    .returning();
  res.status(201).json(
    CreateCollaborationRequestResponse.parse({
      ...request,
      campaignTitle: campaign.campaign.title,
      creatorName: creator.name,
      brandName: campaign.brand.companyName,
    }),
  );
});

router.patch("/requests/:id", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const params = UpdateCollaborationRequestParams.safeParse(req.params);
  const parsed = UpdateCollaborationRequestBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({
      error: params.error?.message ?? parsed.error?.message,
    });
    return;
  }
  const [existing] = await db
    .select({
      request: collaborationRequestsTable,
      creatorUserId: creatorProfilesTable.userId,
    })
    .from(collaborationRequestsTable)
    .innerJoin(creatorProfilesTable, eq(collaborationRequestsTable.creatorId, creatorProfilesTable.id))
    .where(eq(collaborationRequestsTable.id, params.data.id))
    .limit(1);
  if (!existing || existing.creatorUserId !== req.user.id) {
    res.status(404).json({ error: "Incoming request not found" });
    return;
  }
  if (existing.request.status !== "pending") {
    res.status(409).json({ error: "This request has already been answered" });
    return;
  }
  const [updated] = await db
    .update(collaborationRequestsTable)
    .set({ status: parsed.data.status, updatedAt: new Date() })
    .where(eq(collaborationRequestsTable.id, params.data.id))
    .returning();
  const [details] = await requestDetails()
    .where(eq(collaborationRequestsTable.id, params.data.id))
    .limit(1);
  res.json(
    UpdateCollaborationRequestResponse.parse({
      ...updated,
      campaignTitle: details.campaignTitle,
      creatorName: details.creatorName,
      brandName: details.brandName,
    }),
  );
});

router.get("/messages", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const messages = await db
    .select()
    .from(messagesTable)
    .where(
      or(
        eq(messagesTable.senderId, req.user.id),
        eq(messagesTable.recipientId, req.user.id),
      ),
    )
    .orderBy(messagesTable.createdAt);
  res.json(ListMessagesResponse.parse(messages));
});

router.post("/messages", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const parsed = SendMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [participants] = await db
    .select({
      request: collaborationRequestsTable,
      creatorUserId: creatorProfilesTable.userId,
      brandUserId: brandProfilesTable.userId,
    })
    .from(collaborationRequestsTable)
    .innerJoin(creatorProfilesTable, eq(collaborationRequestsTable.creatorId, creatorProfilesTable.id))
    .innerJoin(brandProfilesTable, eq(collaborationRequestsTable.brandId, brandProfilesTable.id))
    .where(eq(collaborationRequestsTable.id, parsed.data.requestId))
    .limit(1);
  if (!participants || participants.request.status === "declined") {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  const senderIsCreator = participants.creatorUserId === req.user.id;
  const senderIsBrand = participants.brandUserId === req.user.id;
  const expectedRecipient = senderIsCreator
    ? participants.brandUserId
    : senderIsBrand
      ? participants.creatorUserId
      : null;
  if (!expectedRecipient) {
    res.status(403).json({ error: "You are not a participant in this conversation" });
    return;
  }
  const [profileName] = senderIsCreator
    ? await db
        .select({ name: creatorProfilesTable.name })
        .from(creatorProfilesTable)
        .where(eq(creatorProfilesTable.userId, req.user.id))
        .limit(1)
    : await db
        .select({ name: brandProfilesTable.companyName })
        .from(brandProfilesTable)
        .where(eq(brandProfilesTable.userId, req.user.id))
        .limit(1);
  const senderName =
    profileName?.name ??
    [req.user.firstName, req.user.lastName].filter(Boolean).join(" ") ??
    req.user.email ??
    "Member";
  const [message] = await db
    .insert(messagesTable)
    .values({
      requestId: parsed.data.requestId,
      senderId: req.user.id,
      senderName,
      recipientId: expectedRecipient,
      content: parsed.data.content,
    })
    .returning();
  res.status(201).json(SendMessageResponse.parse(message));
});

export default router;
