import {
  GetBrandProfileResponse,
  GetCreatorParams,
  GetCreatorResponse,
  GetCreatorProfileResponse,
  ListCreatorsQueryParams,
  ListCreatorsResponse,
  SaveBrandProfileBody,
  SaveBrandProfileResponse,
  SaveCreatorProfileBody,
  SaveCreatorProfileResponse,
} from "@workspace/api-zod";
import {
  brandProfilesTable,
  creatorProfilesTable,
  db,
  portfolioProjectsTable,
} from "@workspace/db";
import { and, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { requireUser } from "../lib/require-user";

const router: IRouter = Router();

router.get("/creator-profile", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const [profile] = await db
    .select()
    .from(creatorProfilesTable)
    .where(eq(creatorProfilesTable.userId, req.user.id))
    .limit(1);
  res.json(GetCreatorProfileResponse.parse({ profile: profile ?? null }));
});

router.post("/creator-profile", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const parsed = SaveCreatorProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [profile] = await db
    .insert(creatorProfilesTable)
    .values({ ...parsed.data, userId: req.user.id })
    .onConflictDoUpdate({
      target: creatorProfilesTable.userId,
      set: { ...parsed.data, updatedAt: new Date() },
    })
    .returning();
  res.json(SaveCreatorProfileResponse.parse(profile));
});

router.get("/brand-profile", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const [profile] = await db
    .select()
    .from(brandProfilesTable)
    .where(eq(brandProfilesTable.userId, req.user.id))
    .limit(1);
  res.json(GetBrandProfileResponse.parse({ profile: profile ?? null }));
});

router.post("/brand-profile", async (req, res): Promise<void> => {
  if (!requireUser(req, res)) return;
  const parsed = SaveBrandProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [profile] = await db
    .insert(brandProfilesTable)
    .values({ ...parsed.data, userId: req.user.id })
    .onConflictDoUpdate({
      target: brandProfilesTable.userId,
      set: { ...parsed.data, updatedAt: new Date() },
    })
    .returning();
  res.json(SaveBrandProfileResponse.parse(profile));
});

router.get("/creators", async (req, res): Promise<void> => {
  const query = ListCreatorsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const profiles = await db
    .select()
    .from(creatorProfilesTable)
    .orderBy(creatorProfilesTable.createdAt);
  const q = query.data.q?.trim().toLowerCase();
  const category = query.data.category?.trim().toLowerCase();
  const filtered = profiles.filter((profile) => {
    const haystack = [
      profile.name,
      profile.title,
      profile.bio,
      ...profile.skills,
      ...profile.tools,
      ...profile.categories,
    ]
      .join(" ")
      .toLowerCase();
    const matchesQuery = !q || haystack.includes(q);
    const matchesCategory =
      !category ||
      profile.categories.some((value) => value.toLowerCase() === category);
    return matchesQuery && matchesCategory;
  });
  res.json(ListCreatorsResponse.parse(filtered));
});

router.get("/creators/:id", async (req, res): Promise<void> => {
  const params = GetCreatorParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [profile] = await db
    .select()
    .from(creatorProfilesTable)
    .where(eq(creatorProfilesTable.id, params.data.id))
    .limit(1);
  if (!profile) {
    res.status(404).json({ error: "Creator not found" });
    return;
  }
  const portfolio = await db
    .select()
    .from(portfolioProjectsTable)
    .where(eq(portfolioProjectsTable.userId, profile.userId))
    .orderBy(portfolioProjectsTable.createdAt);
  res.json(GetCreatorResponse.parse({ profile, portfolio }));
});

export default router;
